package com.example.gestion.iservicio;

import com.example.gestion.modelo.Permisos;
import java.util.List;
import java.util.Optional;


public interface IpermisosService {
public List<Permisos>listar();
 public Optional<Permisos>listarId(int id);
 public int save(Permisos p);
 public void delete(int id); 
}
