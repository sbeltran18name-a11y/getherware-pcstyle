package com.example.gestion.iservicio;
import com.example.gestion.modelo.Auditoria;

import java.util.List;

public interface IAuditoriaService {

    List<Auditoria> listar();
}