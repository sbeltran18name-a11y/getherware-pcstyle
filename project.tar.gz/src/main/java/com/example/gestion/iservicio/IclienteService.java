package com.example.gestion.iservicio;
import java.util.List;
import java.util.Optional;

import com.example.gestion.modelo.Cliente;

public interface IclienteService {

    public List<Cliente> listar();

    public Optional<Cliente> listarId(int id);

    public int save(Cliente cliente);

    public void delete(int id);
}
