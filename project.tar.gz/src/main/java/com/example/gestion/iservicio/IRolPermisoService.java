package com.example.gestion.iservicio;

import com.example.gestion.modelo.RolPermiso;

import java.util.List;
import java.util.Optional;

public interface IRolPermisoService {

    List<RolPermiso> listar();

    Optional<RolPermiso> listarId(int id);

    int save(RolPermiso rolPermiso);

    void delete(int id);
}
