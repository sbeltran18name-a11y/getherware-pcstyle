package com.example.gestion.iservicio;

import java.util.List;
import java.util.Optional;
import com.example.gestion.modelo.Rol;

public interface Irolservice {
 public List<Rol>listar();
 public Optional<Rol>listarId(int id);
 public int save(Rol r);
 public void delete(int id); 
}
