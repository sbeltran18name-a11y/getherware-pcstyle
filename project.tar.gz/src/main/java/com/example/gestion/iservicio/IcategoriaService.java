package com.example.gestion.iservicio;
import java.util.List;
import java.util.Optional;

import com.example.gestion.modelo.Categoriaproducto;

public interface IcategoriaService {

    public List<Categoriaproducto> listar();

    public Optional<Categoriaproducto> listarId(int id);

    public int save(Categoriaproducto categoria);

    public void delete(int id);
}
