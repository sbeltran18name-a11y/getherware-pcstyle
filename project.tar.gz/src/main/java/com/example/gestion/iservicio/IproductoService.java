package com.example.gestion.iservicio;

import com.example.gestion.modelo.Producto;

import java.util.List;
import java.util.Optional;

public interface IproductoService {

    List<Producto> listar();

    Optional<Producto> listarId(int id);

    int save(Producto producto);

    void delete(int id);

    List<Producto> filtrar(
            String busqueda,
            Integer categoriaId,
            String estado
    );
}