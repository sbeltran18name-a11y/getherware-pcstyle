package com.example.gestion.iservicio;

import com.example.gestion.modelo.CuentaContable;

import java.util.List;
import java.util.Optional;

public interface ICuentaContableService {

    List<CuentaContable> listar();

    Optional<CuentaContable> listarId(int id);

    int save(CuentaContable cuenta);

    void delete(int id);
}