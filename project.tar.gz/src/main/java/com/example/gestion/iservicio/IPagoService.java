package com.example.gestion.iservicio;
import com.example.gestion.modelo.Pago;

import java.util.List;
import java.util.Optional;

public interface IPagoService {

    List<Pago> listar();

    Optional<Pago> listarId(int id);

    int save(Pago pago);

    void delete(int id);
}
