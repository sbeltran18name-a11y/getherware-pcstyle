package com.example.gestion.iservicio;
import com.example.gestion.modelo.DetalleCompra;

import java.util.List;
import java.util.Optional;

public interface IDetalleCompraService {

    List<DetalleCompra> listar();

    Optional<DetalleCompra> listarId(int id);

    int save(DetalleCompra detalle);

    void delete(int id);
}
