package com.example.gestion.iservicio;
import com.example.gestion.modelo.DetalleFactura;

import java.util.List;
import java.util.Optional;

public interface IDetalleFacturaService {

    List<DetalleFactura> listar();

    Optional<DetalleFactura> listarId(int id);

    int save(DetalleFactura detalle);

    void delete(int id);
}
