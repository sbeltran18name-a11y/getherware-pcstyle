package com.example.gestion.iservicio;

import com.example.gestion.modelo.DetalleOperacionContable;

import java.util.List;
import java.util.Optional;

public interface IDetalleOperacionContableService {

    List<DetalleOperacionContable> listar();

    Optional<DetalleOperacionContable> listarId(int id);

    int save(DetalleOperacionContable detalle);

    void delete(int id);
}
