package com.example.gestion.iservicio;

import com.example.gestion.modelo.Compra;

import java.util.List;
import java.util.Optional;

public interface ICompraService {

    List<Compra> listar();

    Optional<Compra> listarId(int id);

    int save(Compra compra);

    void delete(int id);
}
