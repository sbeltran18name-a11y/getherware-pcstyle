package com.example.gestion.iservicio;
import com.example.gestion.modelo.AlertaInventario;

import java.util.List;
import java.util.Optional;

public interface IAlertaInventarioService {

    List<AlertaInventario> listar();

    Optional<AlertaInventario> listarId(int id);

    int save(AlertaInventario alerta);

    void delete(int id);
}
