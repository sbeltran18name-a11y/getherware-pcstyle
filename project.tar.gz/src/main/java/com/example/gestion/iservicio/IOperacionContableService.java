package com.example.gestion.iservicio;
import com.example.gestion.modelo.OperacionContable;

import java.util.List;
import java.util.Optional;

public interface IOperacionContableService {

    List<OperacionContable> listar();

    Optional<OperacionContable> listarId(int id);

    int save(OperacionContable operacion);

    void delete(int id);
}