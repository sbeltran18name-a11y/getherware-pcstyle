package com.example.gestion.iservicio;

import java.util.List;
import java.util.Optional;

import com.example.gestion.modelo.Proveedor;

public interface IproveedorService {

    public List<Proveedor> listar();

    public Optional<Proveedor> listarId(int id);

    public int save(Proveedor proveedor);

    public void delete(int id);
}
