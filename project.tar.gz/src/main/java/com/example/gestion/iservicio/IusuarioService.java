package com.example.gestion.iservicio;
import java.util.List;
import java.util.Optional;

import com.example.gestion.modelo.Usuario;

public interface IusuarioService {

    public List<Usuario> listar();

    public Optional<Usuario> listarId(int id);

    public int save(Usuario usuario);

    public void delete(int id);
}
