package com.example.gestion.iservicio;

import com.example.gestion.modelo.FacturaVenta;

import java.util.List;
import java.util.Optional;

public interface IFacturaVentaService {

    List<FacturaVenta> listar();

    Optional<FacturaVenta> listarId(int id);

    int save(FacturaVenta factura);

    void delete(int id);
}
