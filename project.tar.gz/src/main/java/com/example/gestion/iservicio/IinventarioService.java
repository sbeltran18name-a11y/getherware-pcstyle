package com.example.gestion.iservicio;
import com.example.gestion.modelo.Inventario;

import java.util.List;
import java.util.Optional;

public interface IinventarioService {

    List<Inventario> listar();

    Optional<Inventario> listarId(int id);

    int save(Inventario inventario);

    void delete(int id);
}
