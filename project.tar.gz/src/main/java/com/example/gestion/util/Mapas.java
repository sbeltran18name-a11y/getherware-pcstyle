package com.example.gestion.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.ToIntFunction;

/**
 * Utilidad para construir mapas "id -> texto" a partir de una lista.
 *
 * Se usa en los controladores para que las vistas muestren nombres
 * (por ejemplo, el nombre del cliente) en lugar de solo el ID.
 *
 * Ejemplo en un controlador:
 *   model.addAttribute("nombresClientes",
 *       Mapas.porId(clienteService.listar(), Cliente::getId, Cliente::getNombreRazonSocial));
 *
 * Ejemplo en Thymeleaf:
 *   th:text="${nombresClientes[factura.clienteId] ?: factura.clienteId}"
 */
public final class Mapas {

    private Mapas() {
    }

    public static <T> Map<Integer, String> porId(
            List<T> lista,
            ToIntFunction<T> obtenerId,
            Function<T, String> obtenerTexto) {

        Map<Integer, String> mapa = new HashMap<>();

        if (lista == null) {
            return mapa;
        }

        for (T elemento : lista) {
            String texto = obtenerTexto.apply(elemento);
            mapa.put(obtenerId.applyAsInt(elemento), texto != null ? texto : "");
        }

        return mapa;
    }
}
