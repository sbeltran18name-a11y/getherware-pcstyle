package com.example.gestion.interfaces;

import com.example.gestion.modelo.RolPermiso;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IrolPermiso extends CrudRepository<RolPermiso, Integer> {

    boolean existsByRolIdAndPermisoId(int rolId, int permisoId);

    List<RolPermiso> findByRolId(int rolId);
}
