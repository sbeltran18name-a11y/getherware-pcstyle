package com.example.gestion.interfaces;

import com.example.gestion.modelo.Pago;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Ipago extends CrudRepository<Pago, Integer> {

    List<Pago> findByFacturaId(int facturaId);
}
