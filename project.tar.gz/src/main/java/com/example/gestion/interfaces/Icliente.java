package com.example.gestion.interfaces;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.gestion.modelo.Cliente;

@Repository
public interface Icliente extends CrudRepository<Cliente, Integer> {

}
