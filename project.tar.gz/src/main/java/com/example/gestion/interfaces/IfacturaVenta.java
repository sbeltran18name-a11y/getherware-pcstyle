package com.example.gestion.interfaces;
import com.example.gestion.modelo.FacturaVenta;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IfacturaVenta extends CrudRepository<FacturaVenta, Integer> {
}
