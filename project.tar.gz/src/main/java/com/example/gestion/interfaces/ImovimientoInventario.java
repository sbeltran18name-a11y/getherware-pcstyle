package com.example.gestion.interfaces;

import com.example.gestion.modelo.MovimientoInventario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ImovimientoInventario
        extends CrudRepository<MovimientoInventario, Integer> {

    Optional<MovimientoInventario>
    findByReferenciaTipoAndReferenciaIdAndProductoIdAndTipo(
            String referenciaTipo,
            Integer referenciaId,
            Integer productoId,
            String tipo
    );
}