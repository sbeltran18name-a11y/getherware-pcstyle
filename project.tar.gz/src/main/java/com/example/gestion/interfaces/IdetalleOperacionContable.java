package com.example.gestion.interfaces;
import com.example.gestion.modelo.DetalleOperacionContable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IdetalleOperacionContable
        extends CrudRepository<DetalleOperacionContable, Integer> {
}