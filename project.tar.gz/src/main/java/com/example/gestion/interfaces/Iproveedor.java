package com.example.gestion.interfaces;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.gestion.modelo.Proveedor;

@Repository
public interface Iproveedor extends CrudRepository<Proveedor, Integer> {

}
