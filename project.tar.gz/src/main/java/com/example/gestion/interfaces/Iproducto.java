package com.example.gestion.interfaces;

import com.example.gestion.modelo.Producto;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Iproducto extends CrudRepository<Producto, Integer> {
}
