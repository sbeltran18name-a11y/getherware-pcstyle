package com.example.gestion.interfaces;

import com.example.gestion.modelo.DetalleFactura;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IdetalleFactura extends CrudRepository<DetalleFactura, Integer> {

    List<DetalleFactura> findByFacturaId(int facturaId);
}
