package com.example.gestion.interfaces;
import com.example.gestion.modelo.Auditoria;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Iauditoria extends CrudRepository<Auditoria, Long> {
}
