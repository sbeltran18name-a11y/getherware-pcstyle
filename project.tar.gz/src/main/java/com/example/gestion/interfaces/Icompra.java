package com.example.gestion.interfaces;
import com.example.gestion.modelo.Compra;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Icompra extends CrudRepository<Compra, Integer> {
}