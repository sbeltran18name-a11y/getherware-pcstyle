package com.example.gestion.interfaces;
import com.example.gestion.modelo.AlertaInventario;
import com.example.gestion.modelo.EstadoAlerta;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IalertaInventario extends CrudRepository<AlertaInventario, Integer> {

    List<AlertaInventario> findByProductoIdAndEstado(int productoId, EstadoAlerta estado);
}