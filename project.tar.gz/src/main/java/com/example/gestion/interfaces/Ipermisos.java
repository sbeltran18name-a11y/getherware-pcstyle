package com.example.gestion.interfaces;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.gestion.modelo.Permisos;
import com.example.gestion.modelo.Rol;
@Repository 

public interface Ipermisos extends CrudRepository<Permisos,Integer> {

}
