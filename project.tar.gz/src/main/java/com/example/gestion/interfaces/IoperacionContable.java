package com.example.gestion.interfaces;

import com.example.gestion.modelo.OperacionContable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IoperacionContable extends CrudRepository<OperacionContable, Integer> {
}
