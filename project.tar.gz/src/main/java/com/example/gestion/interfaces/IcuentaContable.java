package com.example.gestion.interfaces;
import com.example.gestion.modelo.CuentaContable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IcuentaContable extends CrudRepository<CuentaContable, Integer> {
}