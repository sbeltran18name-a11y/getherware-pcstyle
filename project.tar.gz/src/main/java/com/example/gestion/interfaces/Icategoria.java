package com.example.gestion.interfaces;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.gestion.modelo.Categoriaproducto;

@Repository
public interface Icategoria extends CrudRepository<Categoriaproducto, Integer> {

}
