package com.example.gestion.interfaces;

import com.example.gestion.modelo.DetalleCompra;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IdetalleCompra extends CrudRepository<DetalleCompra, Integer> {

    List<DetalleCompra> findByCompraId(int compraId);
}