package com.example.gestion.interfaces;

import com.example.gestion.modelo.Inventario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface Iinventario extends CrudRepository<Inventario, Integer> {

    Optional<Inventario> findByProductoId(int productoId);
}