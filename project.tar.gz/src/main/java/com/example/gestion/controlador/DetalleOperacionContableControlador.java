package com.example.gestion.controlador;
import com.example.gestion.modelo.CuentaContable;
import com.example.gestion.modelo.DetalleOperacionContable;
import com.example.gestion.modelo.OperacionContable;
import com.example.gestion.servicios.CuentaContableService;
import com.example.gestion.servicios.DetalleOperacionContableService;
import com.example.gestion.servicios.OperacionContableService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class DetalleOperacionContableControlador {

    @Autowired
    private DetalleOperacionContableService service;

    @Autowired
    private OperacionContableService operacionService;

    @Autowired
    private CuentaContableService cuentaService;

    @GetMapping("/DetalleOperacionContable")
    public String listar(Model model) {

        List<DetalleOperacionContable> detalles = service.listar();

        model.addAttribute("Detalles", detalles);
        model.addAttribute("conceptosOperaciones",
                Mapas.porId(operacionService.listar(), OperacionContable::getId, o -> "#" + o.getId() + " - " + o.getConcepto()));
        model.addAttribute("nombresCuentas",
                Mapas.porId(cuentaService.listar(), CuentaContable::getId, c -> c.getCodigo() + " - " + c.getNombre()));

        return "DetalleOperacionContable";
    }

    @GetMapping("/newDetalleOperacionContable")
    public String agregar(Model model) {

        model.addAttribute("detalles", new DetalleOperacionContable());

        model.addAttribute("operaciones", operacionService.listar());

        model.addAttribute("cuentas", cuentaService.listar());

        return "formDetalleOperacionContable";
    }

    @PostMapping("/saveDetalleOperacionContable")
    public String save(@ModelAttribute DetalleOperacionContable detalle) {

        service.save(detalle);

        return "redirect:/DetalleOperacionContable";
    }

    @GetMapping("/editDetalleOperacionContable/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<DetalleOperacionContable> detalle =
                service.listarId(id);

        if (detalle.isPresent()) {

            model.addAttribute("detalles", detalle.get());

            model.addAttribute("operaciones", operacionService.listar());

            model.addAttribute("cuentas", cuentaService.listar());

            return "formDetalleOperacionContable";
        }

        return "redirect:/DetalleOperacionContable";
    }

    @PostMapping("/deleteDetalleOperacionContable/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/DetalleOperacionContable";
    }
}
