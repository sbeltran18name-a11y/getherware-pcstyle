package com.example.gestion.controlador;
import com.example.gestion.modelo.EstadoPago;
import com.example.gestion.modelo.FacturaVenta;
import com.example.gestion.modelo.MetodoPago;
import com.example.gestion.modelo.Pago;
import com.example.gestion.servicios.FacturaVentaService;
import com.example.gestion.servicios.PagoService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class PagoControlador {

    @Autowired
    private PagoService service;

    @Autowired
    private FacturaVentaService facturaService;

    @GetMapping("/Pago")
    public String listar(Model model) {

        List<Pago> pagos = service.listar();

        model.addAttribute("Pagos", pagos);
        model.addAttribute("numerosFacturas",
                Mapas.porId(facturaService.listar(), FacturaVenta::getId, FacturaVenta::getNumeroFactura));

        return "Pago";
    }

    @GetMapping("/newPago")
    public String agregar(Model model) {

        model.addAttribute("pagos", new Pago());

        model.addAttribute("facturas", facturaService.listar());

        model.addAttribute("metodos", MetodoPago.values());

        model.addAttribute("estados", EstadoPago.values());

        return "formPago";
    }

    @PostMapping("/savePago")
    public String save(@ModelAttribute Pago pago) {

        service.save(pago);

        return "redirect:/Pago";
    }

    @GetMapping("/editPago/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Pago> pago = service.listarId(id);

        if (pago.isPresent()) {

            model.addAttribute("pagos", pago.get());

            model.addAttribute("facturas", facturaService.listar());

            model.addAttribute("metodos", MetodoPago.values());

            model.addAttribute("estados", EstadoPago.values());

            return "formPago";
        }

        return "redirect:/Pago";
    }

    @PostMapping("/deletePago/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Pago";
    }
}