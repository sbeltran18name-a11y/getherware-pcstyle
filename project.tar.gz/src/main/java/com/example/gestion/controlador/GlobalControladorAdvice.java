package com.example.gestion.controlador;

import com.example.gestion.interfaces.Irol;
import com.example.gestion.interfaces.Iusuario;
import com.example.gestion.modelo.Rol;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.LicenciaService;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.support.RequestContextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@ControllerAdvice
public class GlobalControladorAdvice {

    private static final Logger log = LoggerFactory.getLogger(GlobalControladorAdvice.class);

    private static final String[] PREFIJOS = {"new", "save", "edit", "delete"};
    private static final Pattern PATRON_DELETE_ID = Pattern.compile("/delete([A-Za-z]+)/(\\d+)");

    private static final Map<String, String> MENU_PADRE = Map.of(
            "DetalleCompra", "Compra",
            "DetalleFactura", "FacturaVenta",
            "DetalleOperacionContable", "OperacionContable"
    );

    @Autowired
    private Iusuario usuarioRepo;

    @Autowired
    private Irol rolRepo;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private LicenciaService licenciaService;

    @ModelAttribute("paginaActual")
    public String paginaActual(HttpServletRequest request) {
        String modulo = obtenerModulo(request);
        return MENU_PADRE.getOrDefault(modulo, modulo);
    }

    @ModelAttribute
    public void cargarUsuarioAutenticado(Model model) {
        model.addAttribute("licenciaEmpresa", licenciaService.getNombreEmpresaCliente());
        model.addAttribute("licenciaNit", licenciaService.getNitEmpresaCliente());
        model.addAttribute("licenciaPlan", licenciaService.getPlanContratado());
        model.addAttribute("licenciaEstado", licenciaService.getEstadoMembresia());
        model.addAttribute("licenciaVencimiento", licenciaService.getFechaVencimiento());
        model.addAttribute("modulosActivos", licenciaService.getModulosActivos());

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            model.addAttribute("esSuperAdmin", false);
            return;
        }
        Optional<Usuario> uOpt = usuarioRepo.findByEmailIgnoreCase(auth.getName());
        if (uOpt.isPresent()) {
            Usuario u = uOpt.get();
            String nombreCompleto = ((u.getNombres() != null ? u.getNombres() : "") + " "
                    + (u.getApellidos() != null ? u.getApellidos() : "")).trim();
            String inicial = !nombreCompleto.isEmpty()
                    ? String.valueOf(Character.toUpperCase(nombreCompleto.charAt(0)))
                    : "U";
            String nombreRol = rolRepo.findById(u.getRolId()).map(Rol::getNombre).orElse("Usuario");
            boolean esSuper = licenciaService.esSuperAdmin(u.getEmail(), nombreRol);

            model.addAttribute("usuarioActualNombre", nombreCompleto);
            model.addAttribute("usuarioActualEmail", u.getEmail());
            model.addAttribute("usuarioActualInicial", inicial);
            model.addAttribute("usuarioActualRol", esSuper ? "Super Admin · Getherware" : nombreRol);
            model.addAttribute("esSuperAdmin", esSuper);
            model.addAttribute("permisosPorRol", licenciaService.obtenerModulosPermitidosPorRol(u.getRolId(), u.getEmail(), nombreRol));
            model.addAttribute("listaPermisosActuales", licenciaService.listarNombresPermisosDeRol(u.getRolId()));
        } else {
            model.addAttribute("esSuperAdmin", false);
        }
    }

    @ExceptionHandler({DataIntegrityViolationException.class, DataAccessException.class})
    public String errorIntegridad(DataAccessException ex, HttpServletRequest request) {

        String detalle = ex.getMostSpecificCause() != null ? ex.getMostSpecificCause().getMessage() : ex.getMessage();
        log.warn("Error de base de datos en {}: {}", request.getRequestURI(), detalle);

        String mensaje;

        if (detalle != null && detalle.toLowerCase().contains("inmutables")) {
            mensaje = "Los registros de auditoría son inmutables por seguridad de la base de datos y no pueden modificarse ni eliminarse.";
        } else if (request.getRequestURI().contains("/delete")) {
            mensaje = explicarDependenciasEliminacion(request, detalle);
        } else {
            mensaje = "No se pudo guardar: ya existe un registro con ese dato único "
                    + "(código, documento, NIT, email, número...) o falta un campo obligatorio.";
        }

        RequestContextUtils.getOutputFlashMap(request).put("mensajeError", mensaje);

        return "redirect:/" + obtenerModulo(request);
    }

    private String explicarDependenciasEliminacion(HttpServletRequest request, String detalleSql) {
        String uri = request.getRequestURI();
        Matcher matcher = PATRON_DELETE_ID.matcher(uri);
        if (matcher.find()) {
            String modulo = matcher.group(1);
            int id = Integer.parseInt(matcher.group(2));
            List<String> usos = new ArrayList<>();
            List<String> dondeIr = new ArrayList<>();

            try {
                switch (modulo) {
                    case "Categoria" -> {
                        List<String> prods = jdbcTemplate.queryForList(
                                "SELECT CONCAT(codigo, ' (', nombre, ')') FROM productos WHERE categoria_id = ? LIMIT 4",
                                String.class, id);
                        Integer total = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM productos WHERE categoria_id = ?", Integer.class, id);
                        if (total != null && total > 0) {
                            usos.add(total + " producto(s) en el módulo de Productos: " + String.join(", ", prods));
                            dondeIr.add("Ve al menú izquierdo → «Productos» y elimina o cámbiales la categoría a esos productos.");
                        }
                    }
                    case "Producto" -> {
                        List<String> facturas = jdbcTemplate.queryForList(
                                "SELECT DISTINCT f.numero_factura FROM detalle_factura df JOIN facturas_venta f ON f.id = df.factura_id WHERE df.producto_id = ? LIMIT 5",
                                String.class, id);
                        if (!facturas.isEmpty()) {
                            usos.add("Facturación de Ventas (Facturas: " + String.join(", ", facturas) + ")");
                            dondeIr.add("«Facturación» → botón «Items / Detalles» de esas facturas para quitar el producto");
                        }
                        List<String> compras = jdbcTemplate.queryForList(
                                "SELECT DISTINCT c.numero_compra FROM detalle_compra dc JOIN compras c ON c.id = dc.compra_id WHERE dc.producto_id = ? LIMIT 5",
                                String.class, id);
                        if (!compras.isEmpty()) {
                            usos.add("Órdenes de Compra (Compras: " + String.join(", ", compras) + ")");
                            dondeIr.add("«Compras» → botón «Items / Detalles» de esas órdenes para quitar el producto");
                        }
                        Integer movs = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM movimientos_inventario WHERE producto_id = ?", Integer.class, id);
                        if (movs != null && movs > 0) {
                            usos.add(movs + " movimiento(s) de kárdex en «Inventario → Ver movimientos»");
                            dondeIr.add("«Inventario → Ver movimientos» para eliminar sus movimientos de entrada/salida");
                        }
                        Integer alertas = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM alertas_inventario WHERE producto_id = ?", Integer.class, id);
                        if (alertas != null && alertas > 0) {
                            usos.add(alertas + " alerta(s) en «Alertas de stock»");
                            dondeIr.add("«Alertas de stock» para eliminar la alerta del producto");
                        }
                        Integer inv = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM inventario WHERE producto_id = ?", Integer.class, id);
                        if (inv != null && inv > 0) {
                            usos.add("un registro de existencias en «Inventario»");
                            dondeIr.add("«Inventario» para eliminar su fila de stock actual");
                        }
                    }
                    case "Proveedor" -> {
                        List<String> compras = jdbcTemplate.queryForList(
                                "SELECT numero_compra FROM compras WHERE proveedor_id = ? LIMIT 5",
                                String.class, id);
                        Integer total = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM compras WHERE proveedor_id = ?", Integer.class, id);
                        if (total != null && total > 0) {
                            usos.add(total + " orden(es) de compra en el módulo de Compras (" + String.join(", ", compras) + ")");
                            dondeIr.add("Ve al menú izquierdo → «Compras» y elimina primero esas órdenes de compra.");
                        }
                    }
                    case "Compra" -> {
                        Integer detalles = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM detalle_compra WHERE compra_id = ?", Integer.class, id);
                        if (detalles != null && detalles > 0) {
                            usos.add(detalles + " línea(s) de productos dentro del Detalle de esta Compra");
                            dondeIr.add("En la tabla de «Compras», haz clic en el botón «Items / Detalles» de esta compra y elimina primero sus productos asociados.");
                        }
                    }
                    case "Cliente" -> {
                        List<String> facturas = jdbcTemplate.queryForList(
                                "SELECT numero_factura FROM facturas_venta WHERE cliente_id = ? LIMIT 5",
                                String.class, id);
                        Integer total = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM facturas_venta WHERE cliente_id = ?", Integer.class, id);
                        if (total != null && total > 0) {
                            usos.add(total + " factura(s) de venta en el módulo de Facturación (" + String.join(", ", facturas) + ")");
                            dondeIr.add("Ve al menú izquierdo → «Facturación» y elimina primero esas facturas asociadas al cliente.");
                        }
                    }
                    case "FacturaVenta" -> {
                        Integer pagos = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM pagos WHERE factura_id = ?", Integer.class, id);
                        if (pagos != null && pagos > 0) {
                            usos.add(pagos + " pago(s) registrado(s) en «Pagos y recaudos»");
                            dondeIr.add("«Pagos y recaudos» para eliminar los pagos asociados a esta factura");
                        }
                        Integer detalles = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM detalle_factura WHERE factura_id = ?", Integer.class, id);
                        if (detalles != null && detalles > 0) {
                            usos.add(detalles + " línea(s) de productos dentro del Detalle de esta Factura");
                            dondeIr.add("el botón «Items / Detalles» de esta misma factura en «Facturación» para eliminar sus productos");
                        }
                    }
                    case "CuentaContable" -> {
                        Integer detOp = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM detalle_operacion_contable WHERE cuenta_id = ?", Integer.class, id);
                        if (detOp != null && detOp > 0) {
                            usos.add(detOp + " asiento(s) contable(s) en «Operaciones contables»");
                            dondeIr.add("«Operaciones contables → Ver detalles» para eliminar los movimientos que usan esta cuenta");
                        }
                        List<String> subcuentas = jdbcTemplate.queryForList(
                                "SELECT CONCAT(codigo, ' - ', nombre) FROM cuentas_contables WHERE cuenta_padre_id = ? LIMIT 4",
                                String.class, id);
                        if (!subcuentas.isEmpty()) {
                            usos.add("Subcuentas hijas en «Plan de cuentas» (" + String.join(", ", subcuentas) + ")");
                            dondeIr.add("«Plan de cuentas» para eliminar o desvincular primero esas subcuentas hijas");
                        }
                    }
                    case "OperacionContable" -> {
                        Integer asientos = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM detalle_operacion_contable WHERE operacion_id = ?", Integer.class, id);
                        if (asientos != null && asientos > 0) {
                            usos.add(asientos + " movimiento(s) débito/crédito registrados dentro de esta operación");
                            dondeIr.add("En «Operaciones contables», entra a «Ver detalles» y elimina primero los asientos asociados a esta operación.");
                        }
                    }
                    case "Rol" -> {
                        List<String> usuarios = jdbcTemplate.queryForList(
                                "SELECT CONCAT(nombres, ' ', apellidos) FROM usuarios WHERE rol_id = ? LIMIT 4",
                                String.class, id);
                        if (!usuarios.isEmpty()) {
                            usos.add("Usuarios con este rol asignado (" + String.join(", ", usuarios) + ")");
                            dondeIr.add("«Usuarios» para cambiarles el rol o eliminar esos usuarios");
                        }
                        Integer permisos = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM rol_permiso WHERE rol_id = ?", Integer.class, id);
                        if (permisos != null && permisos > 0) {
                            usos.add(permisos + " permiso(s) vinculado(s) en «Roles y permisos»");
                            dondeIr.add("«Roles y permisos» para quitar las asignaciones de este rol");
                        }
                    }
                    case "Permiso" -> {
                        Integer asig = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM rol_permiso WHERE permiso_id = ?", Integer.class, id);
                        if (asig != null && asig > 0) {
                            usos.add(asig + " asignación(es) activa(s) en el módulo «Roles y permisos»");
                            dondeIr.add("Ve al menú izquierdo → «Roles y permisos» y elimina primero las filas donde esté asignado este permiso.");
                        }
                    }
                    case "Usuario" -> {
                        List<String> facturas = jdbcTemplate.queryForList(
                                "SELECT numero_factura FROM facturas_venta WHERE usuario_id = ? LIMIT 4",
                                String.class, id);
                        if (!facturas.isEmpty()) {
                            usos.add("Facturas emitidas por este usuario (" + String.join(", ", facturas) + ")");
                            dondeIr.add("«Facturación»");
                        }
                        List<String> compras = jdbcTemplate.queryForList(
                                "SELECT numero_compra FROM compras WHERE usuario_id = ? LIMIT 4",
                                String.class, id);
                        if (!compras.isEmpty()) {
                            usos.add("Órdenes de compra registradas (" + String.join(", ", compras) + ")");
                            dondeIr.add("«Compras»");
                        }
                        Integer movs = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM movimientos_inventario WHERE usuario_id = ?", Integer.class, id);
                        if (movs != null && movs > 0) {
                            usos.add(movs + " movimiento(s) en «Inventario → Movimientos»");
                            dondeIr.add("«Inventario → Ver movimientos»");
                        }
                        Integer ops = jdbcTemplate.queryForObject(
                                "SELECT COUNT(*) FROM operaciones_contables WHERE usuario_id = ?", Integer.class, id);
                        if (ops != null && ops > 0) {
                            usos.add(ops + " operación(es) en «Operaciones contables»");
                            dondeIr.add("«Operaciones contables»");
                        }
                    }
                    default -> {
                    }
                }
            } catch (Exception ignored) {
            }

            if (!usos.isEmpty()) {
                String instruccion = dondeIr.size() == 1 && dondeIr.get(0).startsWith("Ve ") || (dondeIr.size() == 1 && dondeIr.get(0).startsWith("En "))
                        ? dondeIr.get(0)
                        : "Para poder eliminarlo, primero debes ir a: " + String.join(" y ", dondeIr) + ".";
                return "No se puede eliminar porque actualmente se está usando en: "
                        + String.join("; además de ", usos) + ". " + instruccion;
            }
        }

        return "No se puede eliminar este registro porque está vinculado a otros datos activos del sistema. "
                + "Elimina primero los registros dependientes asociados a él.";
    }

    /**
     * Convierte una URL en el nombre del módulo.
     * Ejemplos: /Cliente -> Cliente, /editCliente/3 -> Cliente,
     *           /deleteFacturaVenta/5 -> FacturaVenta, / -> Dashboard
     */
    static String obtenerModulo(HttpServletRequest request) {

        String ruta = request.getRequestURI().substring(request.getContextPath().length());

        if (ruta.startsWith("/")) {
            ruta = ruta.substring(1);
        }

        int barra = ruta.indexOf('/');
        if (barra >= 0) {
            ruta = ruta.substring(0, barra);
        }

        for (String prefijo : PREFIJOS) {
            if (ruta.length() > prefijo.length()
                    && ruta.startsWith(prefijo)
                    && Character.isUpperCase(ruta.charAt(prefijo.length()))) {
                ruta = ruta.substring(prefijo.length());
                break;
            }
        }

        return ruta.isEmpty() ? "Dashboard" : ruta;
    }
}
