package com.example.gestion.controlador;

import com.example.gestion.interfaces.Iauditoria;
import com.example.gestion.modelo.AccionAuditoria;
import com.example.gestion.modelo.Auditoria;
import com.example.gestion.modelo.Estado;
import com.example.gestion.modelo.EstadoUsuario;
import com.example.gestion.modelo.Rol;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.EmailVerificacionService;
import com.example.gestion.servicios.Rolservice;
import com.example.gestion.servicios.UsuarioService;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class AuthControlador {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private Rolservice rolService;

    @Autowired
    private EmailVerificacionService emailVerificacionService;

    @Autowired
    private Iauditoria auditoriaRepo;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        model.addAttribute("roles", obtenerRolesDisponibles());
        return "registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(
            @ModelAttribute("usuario") Usuario usuario,
            @RequestParam("confirmarPassword") String confirmarPassword,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (usuario.getEmail() == null || usuario.getEmail().isBlank()) {
            model.addAttribute("error", "El correo electrónico es obligatorio.");
            model.addAttribute("roles", obtenerRolesDisponibles());
            return "registro";
        }

        String emailLimpio = usuario.getEmail().trim().toLowerCase();
        usuario.setEmail(emailLimpio);

        if (usuario.getPasswordHash() == null || usuario.getPasswordHash().length() < 6) {
            model.addAttribute("error", "La contraseña debe tener al menos 6 caracteres.");
            model.addAttribute("roles", obtenerRolesDisponibles());
            return "registro";
        }

        if (!usuario.getPasswordHash().equals(confirmarPassword)) {
            model.addAttribute("error", "Las contraseñas no coinciden.");
            model.addAttribute("roles", obtenerRolesDisponibles());
            return "registro";
        }

        Optional<Usuario> existente = usuarioService.buscarPorEmail(emailLimpio);
        if (existente.isPresent()) {
            Usuario u = existente.get();
            if (u.getEstado() == EstadoUsuario.INACTIVO) {
                boolean enviado = emailVerificacionService.generarYEnviarCodigo(emailLimpio, u.getNombres());
                redirectAttributes.addAttribute("email", emailLimpio);
                redirectAttributes.addFlashAttribute("enviadoPorCorreo", enviado);
                return "redirect:/verificar-codigo";
            }
            model.addAttribute("error", "Ya existe una cuenta registrada con ese correo electrónico.");
            model.addAttribute("roles", obtenerRolesDisponibles());
            return "registro";
        }

        if (usuario.getRolId() <= 0) {
            List<Rol> roles = rolService.listar();
            if (!roles.isEmpty()) {
                usuario.setRolId(roles.get(0).getId());
            } else {
                Rol nuevoRol = new Rol(0, "Usuario", "Rol por defecto", Estado.ACTIVO, LocalDateTime.now());
                rolService.save(nuevoRol);
                usuario.setRolId(rolService.listar().get(0).getId());
            }
        }

        if (usuario.getCargo() == null || usuario.getCargo().isBlank()) {
            usuario.setCargo("Usuario del sistema");
        }

        // Queda INACTIVO hasta que ingrese el código enviado a su correo
        usuario.setEstado(EstadoUsuario.INACTIVO);
        usuarioService.save(usuario);

        boolean enviado = emailVerificacionService.generarYEnviarCodigo(emailLimpio, usuario.getNombres());

        redirectAttributes.addAttribute("email", emailLimpio);
        redirectAttributes.addFlashAttribute("enviadoPorCorreo", enviado);

        return "redirect:/verificar-codigo";
    }

    @GetMapping("/verificar-codigo")
    public String mostrarVerificarCodigo(
            @RequestParam("email") String email,
            @RequestParam(value = "pendiente", required = false) Boolean pendiente,
            Model model) {

        String emailLimpio = email.trim().toLowerCase();

        // Si vino desde el login porque su cuenta estaba pendiente y aún no tenía código activo, generamos uno nuevo
        if (Boolean.TRUE.equals(pendiente) && emailVerificacionService.obtenerCodigoActual(emailLimpio) == null) {
            Optional<Usuario> uOpt = usuarioService.buscarPorEmail(emailLimpio);
            String nombre = uOpt.map(Usuario::getNombres).orElse("Usuario");
            boolean enviado = emailVerificacionService.generarYEnviarCodigo(emailLimpio, nombre);
            model.addAttribute("enviadoPorCorreo", enviado);
            model.addAttribute("aviso", "Tu cuenta aún no ha sido verificada. Te enviamos un nuevo código de 6 dígitos.");
        }

        model.addAttribute("email", emailLimpio);

        return "verificarCodigo";
    }

    @PostMapping("/verificar-codigo")
    public String confirmarCodigo(
            @RequestParam("email") String email,
            @RequestParam("codigo") String codigo,
            HttpServletRequest request,
            Model model,
            RedirectAttributes redirectAttributes) {

        String emailLimpio = email.trim().toLowerCase();
        Optional<Usuario> usuarioOpt = usuarioService.buscarPorEmail(emailLimpio);

        if (usuarioOpt.isEmpty()) {
            model.addAttribute("email", emailLimpio);
            model.addAttribute("error", "No se encontró ninguna cuenta asociada a este correo.");
            return "verificarCodigo";
        }

        if (!emailVerificacionService.validarCodigo(emailLimpio, codigo)) {
            model.addAttribute("email", emailLimpio);
            model.addAttribute("error", "El código ingresado es incorrecto o ha expirado. Verifica tu correo e intenta de nuevo.");
            return "verificarCodigo";
        }

        Usuario usuario = usuarioOpt.get();
        usuario.setEstado(EstadoUsuario.ACTIVO);
        usuarioService.save(usuario);

        try {
            Auditoria a = new Auditoria();
            a.setUsuarioId((long) usuario.getId());
            a.setModulo("Usuarios");
            a.setAccion(AccionAuditoria.CREAR);
            a.setRegistroId((long) usuario.getId());
            a.setDescripcion("Cuenta creada y verificada por correo: " + usuario.getEmail());
            a.setIp(request.getRemoteAddr());
            a.setFechaExacta(LocalDateTime.now());
            auditoriaRepo.save(a);
        } catch (Exception ignored) {
        }

        redirectAttributes.addFlashAttribute("verificado", true);
        redirectAttributes.addFlashAttribute("emailVerificado", emailLimpio);

        return "redirect:/login";
    }

    @PostMapping("/reenviar-codigo")
    public String reenviarCodigo(
            @RequestParam("email") String email,
            RedirectAttributes redirectAttributes) {

        String emailLimpio = email.trim().toLowerCase();
        Optional<Usuario> usuarioOpt = usuarioService.buscarPorEmail(emailLimpio);

        if (usuarioOpt.isPresent()) {
            boolean enviado = emailVerificacionService.generarYEnviarCodigo(emailLimpio, usuarioOpt.get().getNombres());
            redirectAttributes.addFlashAttribute("enviadoPorCorreo", enviado);
            redirectAttributes.addFlashAttribute("aviso", "Se ha generado y enviado un nuevo código de 6 dígitos.");
        }

        redirectAttributes.addAttribute("email", emailLimpio);
        return "redirect:/verificar-codigo";
    }

    private List<Rol> obtenerRolesDisponibles() {
        return rolService.listar();
    }
}
