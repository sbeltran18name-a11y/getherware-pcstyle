package com.example.gestion.controlador;
import com.example.gestion.modelo.Cliente;
import com.example.gestion.modelo.DetalleFactura;
import com.example.gestion.modelo.EstadoFactura;
import com.example.gestion.modelo.FacturaVenta;
import com.example.gestion.modelo.Producto;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.ClienteService;
import com.example.gestion.servicios.DetalleFacturaService;
import com.example.gestion.servicios.FacturaVentaService;
import com.example.gestion.servicios.ProductoService;
import com.example.gestion.servicios.UsuarioService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class FacturaVentaControlador {

    @Autowired
    private FacturaVentaService service;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private DetalleFacturaService detalleFacturaService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/FacturaVenta")
    public String listar(Model model) {

        List<FacturaVenta> facturas = service.listar();

        model.addAttribute("Facturas", facturas);
        model.addAttribute("nombresClientes",
                Mapas.porId(clienteService.listar(), Cliente::getId, Cliente::getNombreRazonSocial));
        model.addAttribute("nombresUsuarios",
                Mapas.porId(usuarioService.listar(), Usuario::getId, u -> u.getNombres() + " " + u.getApellidos()));

        return "FacturaVenta";
    }

    @GetMapping("/verFacturaVenta/{id}")
    public String verComprobante(@PathVariable int id, Model model) {

        Optional<FacturaVenta> facturaOpt = service.listarId(id);
        if (facturaOpt.isEmpty()) {
            return "redirect:/FacturaVenta";
        }

        FacturaVenta factura = facturaOpt.get();
        List<DetalleFactura> detalles = detalleFacturaService.listarPorFactura(id);
        List<Producto> productos = productoService.listar();

        model.addAttribute("factura", factura);
        model.addAttribute("cliente", clienteService.listarId(factura.getClienteId()).orElse(null));
        model.addAttribute("vendedor", usuarioService.listarId(factura.getUsuarioId()).orElse(null));
        model.addAttribute("detalles", detalles);
        model.addAttribute("codigosProductos", Mapas.porId(productos, Producto::getId, Producto::getCodigo));
        model.addAttribute("nombresProductos", Mapas.porId(productos, Producto::getId, Producto::getNombre));

        return "comprobanteFactura";
    }

    @GetMapping("/newFacturaVenta")
    public String agregar(Model model) {

        FacturaVenta nueva = new FacturaVenta();
        nueva.setFechaEmision(LocalDateTime.now().withSecond(0).withNano(0));
        nueva.setSubtotal(BigDecimal.ZERO);
        nueva.setImpuesto(BigDecimal.ZERO);
        nueva.setTotal(BigDecimal.ZERO);
        nueva.setEstado(EstadoFactura.EMITIDA);
        nueva.setNumeroFactura(String.format("FV-%04d", service.listar().size() + 1));

        List<Usuario> listaUsuarios = usuarioService.listar();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated()) {
            listaUsuarios.stream()
                    .filter(u -> u.getEmail() != null && u.getEmail().equalsIgnoreCase(auth.getName()))
                    .findFirst()
                    .ifPresent(u -> nueva.setUsuarioId(u.getId()));
        }

        model.addAttribute("facturas", nueva);

        model.addAttribute("clientes", clienteService.listar());

        model.addAttribute("usuarios", listaUsuarios);

        model.addAttribute("estados", EstadoFactura.values());

        return "formFacturaVenta";
    }

    @PostMapping("/saveFacturaVenta")
    public String save(@ModelAttribute FacturaVenta factura, RedirectAttributes redirectAttrs) {

        boolean eraNueva = (factura.getId() == 0);
        service.save(factura);

        if (eraNueva && factura.getId() > 0) {
            redirectAttrs.addFlashAttribute("mensajeExito",
                    "Factura " + factura.getNumeroFactura() + " creada. Ahora puedes agregar los productos vendidos.");
            return "redirect:/DetalleFactura?facturaId=" + factura.getId();
        }

        return "redirect:/FacturaVenta";
    }

    @GetMapping("/editFacturaVenta/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<FacturaVenta> factura = service.listarId(id);

        if (factura.isPresent()) {

            model.addAttribute("facturas", factura.get());

            model.addAttribute("clientes", clienteService.listar());

            model.addAttribute("usuarios", usuarioService.listar());

            model.addAttribute("estados", EstadoFactura.values());

            return "formFacturaVenta";
        }

        return "redirect:/FacturaVenta";
    }

    @PostMapping("/deleteFacturaVenta/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/FacturaVenta";
    }
}