package com.example.gestion.controlador;
import com.example.gestion.modelo.CuentaContable;
import com.example.gestion.modelo.EstadoCuenta;
import com.example.gestion.modelo.NaturalezaCuenta;
import com.example.gestion.modelo.TipoCuenta;
import com.example.gestion.servicios.CuentaContableService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class CuentaContableControlador {

    @Autowired
    private CuentaContableService service;

    @GetMapping("/CuentaContable")
    public String listar(Model model) {

        List<CuentaContable> cuentas = service.listar();

        model.addAttribute("Cuentas", cuentas);
        model.addAttribute("nombresCuentas",
                Mapas.porId(cuentas, CuentaContable::getId, c -> c.getCodigo() + " - " + c.getNombre()));

        return "CuentaContable";
    }

    @GetMapping("/newCuentaContable")
    public String agregar(Model model) {

        model.addAttribute("cuentas", new CuentaContable());

        model.addAttribute("cuentasPadre", service.listar());

        model.addAttribute("tipos", TipoCuenta.values());

        model.addAttribute("naturalezas", NaturalezaCuenta.values());

        model.addAttribute("estados", EstadoCuenta.values());

        return "formCuentaContable";
    }

    @PostMapping("/saveCuentaContable")
    public String save(@ModelAttribute CuentaContable cuenta) {

        service.save(cuenta);

        return "redirect:/CuentaContable";
    }

    @GetMapping("/editCuentaContable/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<CuentaContable> cuenta = service.listarId(id);

        if (cuenta.isPresent()) {

            model.addAttribute("cuentas", cuenta.get());

            model.addAttribute("cuentasPadre", service.listar());

            model.addAttribute("tipos", TipoCuenta.values());

            model.addAttribute("naturalezas", NaturalezaCuenta.values());

            model.addAttribute("estados", EstadoCuenta.values());

            return "formCuentaContable";
        }

        return "redirect:/CuentaContable";
    }

    @PostMapping("/deleteCuentaContable/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/CuentaContable";
    }
}
