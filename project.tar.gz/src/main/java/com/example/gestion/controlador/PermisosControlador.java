package com.example.gestion.controlador;
import java.util.List;
import java.util.Optional;

import com.example.gestion.modelo.Permisos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.gestion.servicios.PermisosService;

import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;

@Controller
@RequestMapping
public class PermisosControlador {
 @Autowired
    private PermisosService service;

    // LISTAR PERMISOS
    @GetMapping("/Permiso")
    public String listar(Model model) {

        List<Permisos> permisos = service.listar();

        model.addAttribute("Permiso", permisos);

        return "Permiso";
    }

    // FORMULARIO NUEVO
    @GetMapping("/newPermiso")
    public String agregar(Model model) {

        model.addAttribute("permisos", new Permisos());

        return "formPermiso";
    }

    // GUARDAR
    @PostMapping("/savePermiso")
    public String save(@Validated Permisos permiso) {

        service.save(permiso);

        return "redirect:/Permiso";
    }

    // EDITAR
    @GetMapping("/editPermiso/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Permisos> permiso = service.listarId(id);

        if (permiso.isPresent()) {
            model.addAttribute("permisos", permiso.get());
            return "formPermiso";
        }

        return "redirect:/Permiso";
    }

    // ELIMINAR
    @PostMapping("/deletePermiso/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Permiso";
    }
}