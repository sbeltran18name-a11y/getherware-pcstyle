package com.example.gestion.controlador;
import com.example.gestion.modelo.Compra;
import com.example.gestion.modelo.DetalleCompra;
import com.example.gestion.modelo.Producto;
import com.example.gestion.servicios.CompraService;
import com.example.gestion.servicios.DetalleCompraService;
import com.example.gestion.servicios.ProductoService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class DetalleCompraControlador {

    @Autowired
    private DetalleCompraService service;

    @Autowired
    private CompraService compraService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/DetalleCompra")
    public String listar(
            @RequestParam(value = "compraId", required = false) Integer compraId,
            Model model) {

        List<DetalleCompra> detalles = (compraId != null && compraId > 0)
                ? service.listarPorCompra(compraId)
                : service.listar();

        model.addAttribute("Detalles", detalles);
        model.addAttribute("compraIdFiltro", compraId);
        if (compraId != null && compraId > 0) {
            compraService.listarId(compraId).ifPresent(c -> model.addAttribute("compraSeleccionada", c));
        }
        model.addAttribute("numerosCompras",
                Mapas.porId(compraService.listar(), Compra::getId, Compra::getNumeroCompra));
        model.addAttribute("nombresProductos",
                Mapas.porId(productoService.listar(), Producto::getId, p -> p.getCodigo() + " - " + p.getNombre()));

        return "DetalleCompra";
    }

    @GetMapping("/newDetalleCompra")
    public String agregar(
            @RequestParam(value = "compraId", required = false) Integer compraId,
            Model model) {

        DetalleCompra nuevo = new DetalleCompra();
        if (compraId != null && compraId > 0) {
            nuevo.setCompraId(compraId);
        }

        model.addAttribute("detalles", nuevo);
        model.addAttribute("compras", compraService.listar());
        model.addAttribute("productos", productoService.listar());

        return "formDetalleCompra";
    }

    @PostMapping("/saveDetalleCompra")
    public String save(@ModelAttribute DetalleCompra detalle) {

        service.save(detalle);

        if (detalle.getCompraId() > 0) {
            return "redirect:/DetalleCompra?compraId=" + detalle.getCompraId();
        }
        return "redirect:/DetalleCompra";
    }

    @GetMapping("/editDetalleCompra/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<DetalleCompra> detalle = service.listarId(id);

        if (detalle.isPresent()) {

            model.addAttribute("detalles", detalle.get());
            model.addAttribute("compras", compraService.listar());
            model.addAttribute("productos", productoService.listar());

            return "formDetalleCompra";
        }

        return "redirect:/DetalleCompra";
    }

    @PostMapping("/deleteDetalleCompra/{id}")
    public String delete(@PathVariable int id) {

        Optional<DetalleCompra> existente = service.listarId(id);
        Integer compraId = existente.map(DetalleCompra::getCompraId).orElse(null);

        service.delete(id);

        if (compraId != null && compraId > 0) {
            return "redirect:/DetalleCompra?compraId=" + compraId;
        }
        return "redirect:/DetalleCompra";
    }
}
