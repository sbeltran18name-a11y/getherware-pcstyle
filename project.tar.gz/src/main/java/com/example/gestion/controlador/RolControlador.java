package com.example.gestion.controlador;
import java.util.List;
import java.util.Optional;

import com.example.gestion.modelo.Rol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.gestion.servicios.Rolservice;

import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
@Controller 
@RequestMapping 
public class RolControlador{

      @Autowired
    private Rolservice service;

    // LISTAR ROLES
    @GetMapping("/Rol")
    public String listar(Model model) {

        List<Rol> roles = service.listar();

        model.addAttribute("Rol", roles);

        return "Rol";
    }

    // FORMULARIO NUEVO
    @GetMapping("/newRol")
    public String agregar(Model model) {

        model.addAttribute("roles", new Rol());

        return "formRol";
    }

    // GUARDAR
    @PostMapping("/saveRol")
    public String save(@Validated Rol rol) {

        service.save(rol);

        return "redirect:/Rol";
    }

    // EDITAR
    @GetMapping("/editRol/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Rol> rol = service.listarId(id);

        if (rol.isPresent()) {
            model.addAttribute("roles", rol.get());
            return "formRol";
        }

        return "redirect:/Rol";
    }

    // ELIMINAR
    @PostMapping("/deleteRol/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Rol";
    }
}