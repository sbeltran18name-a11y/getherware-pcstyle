package com.example.gestion.controlador;

import com.example.gestion.modelo.AlertaInventario;
import com.example.gestion.modelo.Cliente;
import com.example.gestion.modelo.Compra;
import com.example.gestion.modelo.EstadoAlerta;
import com.example.gestion.modelo.EstadoCompra;
import com.example.gestion.modelo.EstadoFactura;
import com.example.gestion.modelo.EstadoPago;
import com.example.gestion.modelo.FacturaVenta;
import com.example.gestion.modelo.Inventario;
import com.example.gestion.modelo.Pago;
import com.example.gestion.modelo.Producto;
import com.example.gestion.modelo.Proveedor;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.AlertaInventarioService;
import com.example.gestion.servicios.ClienteService;
import com.example.gestion.servicios.CompraService;
import com.example.gestion.servicios.FacturaVentaService;
import com.example.gestion.servicios.InventarioService;
import com.example.gestion.servicios.OperacionContableService;
import com.example.gestion.servicios.PagoService;
import com.example.gestion.servicios.ProductoService;
import com.example.gestion.servicios.ProveedorService;
import com.example.gestion.servicios.UsuarioService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class DashboardControlador {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private InventarioService inventarioService;

    @Autowired
    private AlertaInventarioService alertaService;

    @Autowired
    private CompraService compraService;

    @Autowired
    private FacturaVentaService facturaService;

    @Autowired
    private PagoService pagoService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ProveedorService proveedorService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private OperacionContableService operacionContableService;

    @GetMapping({"/", "/Dashboard"})
    public String dashboard(Model model) {
        model.addAttribute("paginaActual", "Dashboard");

        List<Producto> productos = productoService.listar();
        List<Inventario> inventarios = inventarioService.listar();
        List<AlertaInventario> alertas = alertaService.listar();
        List<Compra> compras = compraService.listar();
        List<FacturaVenta> facturas = facturaService.listar();
        List<Pago> pagos = pagoService.listar();
        List<Cliente> clientes = clienteService.listar();
        List<Proveedor> proveedores = proveedorService.listar();
        List<Usuario> usuarios = usuarioService.listar();

        // 1. Ventas totales (excluyendo anuladas)
        BigDecimal totalVentas = facturas.stream()
                .filter(f -> f.getEstado() != EstadoFactura.ANULADA && f.getTotal() != null)
                .map(FacturaVenta::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 2. Compras totales (excluyendo anuladas)
        BigDecimal totalCompras = compras.stream()
                .filter(c -> c.getEstado() != EstadoCompra.ANULADA && c.getTotal() != null)
                .map(Compra::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 3. Pagos aprobados recaudados
        BigDecimal totalRecaudado = pagos.stream()
                .filter(p -> p.getEstado() == EstadoPago.APROBADO && p.getMonto() != null)
                .map(Pago::getMonto)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 4. Unidades totales en stock
        BigDecimal unidadesStockTotal = inventarios.stream()
                .filter(i -> i.getStockActual() != null)
                .map(Inventario::getStockActual)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 5. Productos activos y alertas pendientes
        long productosActivos = productos.stream().filter(Producto::isActivo).count();
        List<AlertaInventario> alertasPendientesLista = alertas.stream()
                .filter(a -> a.getEstado() == EstadoAlerta.PENDIENTE)
                .sorted(Comparator.comparingInt(AlertaInventario::getId).reversed())
                .collect(Collectors.toList());

        // 6. Últimas 5 facturas de venta
        List<FacturaVenta> ultimasFacturas = facturas.stream()
                .sorted(Comparator.comparingInt(FacturaVenta::getId).reversed())
                .limit(5)
                .collect(Collectors.toList());

        // 7. Últimas 5 compras
        List<Compra> ultimasCompras = compras.stream()
                .sorted(Comparator.comparingInt(Compra::getId).reversed())
                .limit(5)
                .collect(Collectors.toList());

        model.addAttribute("totalVentas", totalVentas);
        model.addAttribute("cantidadFacturas", facturas.size());
        model.addAttribute("totalCompras", totalCompras);
        model.addAttribute("cantidadCompras", compras.size());
        model.addAttribute("totalRecaudado", totalRecaudado);
        model.addAttribute("cantidadPagos", pagos.size());
        model.addAttribute("totalProductos", productos.size());
        model.addAttribute("productosActivos", productosActivos);
        model.addAttribute("unidadesStockTotal", unidadesStockTotal);
        model.addAttribute("alertasPendientes", alertasPendientesLista.size());
        model.addAttribute("totalClientes", clientes.size());
        model.addAttribute("totalProveedores", proveedores.size());
        model.addAttribute("totalUsuarios", usuarios.size());
        model.addAttribute("totalOperacionesContables", operacionContableService.listar().size());

        model.addAttribute("ultimasFacturas", ultimasFacturas);
        model.addAttribute("ultimasCompras", ultimasCompras);
        model.addAttribute("alertasActivas", alertasPendientesLista.stream().limit(5).collect(Collectors.toList()));

        model.addAttribute("nombresClientes",
                Mapas.porId(clientes, Cliente::getId, Cliente::getNombreRazonSocial));
        model.addAttribute("nombresProveedores",
                Mapas.porId(proveedores, Proveedor::getId, Proveedor::getRazonSocial));
        model.addAttribute("nombresProductos",
                Mapas.porId(productos, Producto::getId, p -> p.getCodigo() + " - " + p.getNombre()));

        return "Dashboard";
    }
}