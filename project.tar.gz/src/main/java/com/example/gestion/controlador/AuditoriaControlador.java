package com.example.gestion.controlador;
import com.example.gestion.modelo.Auditoria;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.AuditoriaService;
import com.example.gestion.servicios.UsuarioService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AuditoriaControlador {

    @Autowired
    private AuditoriaService service;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/Auditoria")
    public String listar(Model model) {

        List<Auditoria> auditorias = service.listar();
        auditorias.sort((a, b) -> Long.compare(
                b.getId() != null ? b.getId() : 0L,
                a.getId() != null ? a.getId() : 0L));

        model.addAttribute("Auditorias", auditorias);
        model.addAttribute("nombresUsuarios",
                Mapas.porId(usuarioService.listar(), Usuario::getId, u -> u.getNombres() + " " + u.getApellidos()));

        return "Auditoria";
    }
}
