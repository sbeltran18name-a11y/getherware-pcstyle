package com.example.gestion.controlador;
import com.example.gestion.modelo.Inventario;
import com.example.gestion.modelo.Producto;
import com.example.gestion.servicios.InventarioService;
import com.example.gestion.servicios.ProductoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class InventarioControlador {

    @Autowired
    private InventarioService service;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/Inventario")
    public String listar(
            @RequestParam(required = false) String busqueda,
            @RequestParam(required = false) String estado,
            Model model) {

        List<Inventario> todosLosInventarios = service.listar();
        List<Producto> productos = productoService.listar();

        Map<Integer, String> nombresProductos = new HashMap<>();
        Map<Integer, String> codigosProductos = new HashMap<>();
        Map<Integer, BigDecimal> stocksMinimos = new HashMap<>();

        for (Producto producto : productos) {
            nombresProductos.put(producto.getId(), producto.getNombre());
            codigosProductos.put(producto.getId(), producto.getCodigo());
            stocksMinimos.put(
                    producto.getId(),
                    producto.getStockMinimo() != null
                            ? producto.getStockMinimo()
                            : BigDecimal.ZERO
            );
        }

        // Calcular indicadores sobre todos los registros.
        int totalInventarios = todosLosInventarios.size();
        int totalAgotados = 0;
        int totalStockBajo = 0;

        for (Inventario inventario : todosLosInventarios) {

            BigDecimal stock = inventario.getStockActual() != null
                    ? inventario.getStockActual()
                    : BigDecimal.ZERO;

            BigDecimal minimo = stocksMinimos.getOrDefault(
                    inventario.getProductoId(),
                    BigDecimal.ZERO
            );

            if (stock.compareTo(BigDecimal.ZERO) <= 0) {
                totalAgotados++;
            } else if (stock.compareTo(minimo) <= 0) {
                totalStockBajo++;
            }
        }

        // Filtrar los registros que se mostrarán en la tabla.
        List<Inventario> inventariosFiltrados =
                new ArrayList<>(todosLosInventarios);

        if (busqueda != null && !busqueda.trim().isEmpty()) {
            String termino = busqueda.trim().toLowerCase();

            inventariosFiltrados = inventariosFiltrados.stream()
                    .filter(inventario -> {
                        String nombre = nombresProductos.get(
                                inventario.getProductoId()
                        );
                        String codigo = codigosProductos.get(
                                inventario.getProductoId()
                        );

                        return (nombre != null
                                && nombre.toLowerCase().contains(termino))
                                || (codigo != null
                                && codigo.toLowerCase().contains(termino));
                    })
                    .collect(Collectors.toList());
        }

        if (estado != null && !estado.trim().isEmpty()) {

            inventariosFiltrados = inventariosFiltrados.stream()
                    .filter(inventario -> {

                        BigDecimal stock = inventario.getStockActual() != null
                                ? inventario.getStockActual()
                                : BigDecimal.ZERO;

                        BigDecimal minimo = stocksMinimos.getOrDefault(
                                inventario.getProductoId(),
                                BigDecimal.ZERO
                        );

                        switch (estado.toUpperCase()) {
                            case "AGOTADO":
                                return stock.compareTo(BigDecimal.ZERO) <= 0;

                            case "BAJO":
                                return stock.compareTo(BigDecimal.ZERO) > 0
                                        && stock.compareTo(minimo) <= 0;

                            case "NORMAL":
                                return stock.compareTo(BigDecimal.ZERO) > 0
                                        && stock.compareTo(minimo) > 0;

                            default:
                                return true;
                        }
                    })
                    .collect(Collectors.toList());
        }

        model.addAttribute("Inventario", inventariosFiltrados);
        model.addAttribute("nombresProductos", nombresProductos);
        model.addAttribute("codigosProductos", codigosProductos);
        model.addAttribute("stocksMinimos", stocksMinimos);

        model.addAttribute("totalInventarios", totalInventarios);
        model.addAttribute("totalStockBajo", totalStockBajo);
        model.addAttribute("totalAgotados", totalAgotados);

        model.addAttribute("busqueda", busqueda == null ? "" : busqueda);
        model.addAttribute(
                "estadoSeleccionado",
                estado == null ? "" : estado.toUpperCase()
        );

        model.addAttribute("paginaActual", "Inventario");

        return "Inventario";
    }

    @GetMapping("/newInventario")
public String agregar(Model model) {
    model.addAttribute("inventarios", new Inventario());
    model.addAttribute("productos", productoService.listar());
    model.addAttribute("paginaActual", "Inventario");

    return "formInventario";
}

    @PostMapping("/saveInventario")
    public String save(@ModelAttribute Inventario inventario) {

        service.save(inventario);

        return "redirect:/Inventario";
    }

    @GetMapping("/editInventario/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Inventario> inventario = service.listarId(id);

        if (inventario.isPresent()) {

            model.addAttribute("inventarios", inventario.get());
            model.addAttribute("productos", productoService.listar());
            model.addAttribute("paginaActual", "Inventario");

            return "formInventario";
        }

        return "redirect:/Inventario";
    }

    @PostMapping("/deleteInventario/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Inventario";
    }
}