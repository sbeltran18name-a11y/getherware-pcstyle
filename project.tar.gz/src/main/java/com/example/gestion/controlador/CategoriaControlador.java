package com.example.gestion.controlador;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.gestion.modelo.Categoriaproducto;
import com.example.gestion.servicios.CategoriaService;

@Controller
public class CategoriaControlador {

    @Autowired
    private CategoriaService service;

    @GetMapping("/Categoria")
    public String listar(Model model) {

        List<Categoriaproducto> categorias = service.listar();

        model.addAttribute("Categoria", categorias);

        return "Categoria";
    }

    @GetMapping("/newCategoria")
    public String agregar(Model model) {

        model.addAttribute("categorias", new Categoriaproducto());

        return "formCategoria";
    }

    @PostMapping("/saveCategoria")
    public String save(@Validated Categoriaproducto categoria) {

        service.save(categoria);

        return "redirect:/Categoria";
    }

    @GetMapping("/editCategoria/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Categoriaproducto> categoria = service.listarId(id);

        if (categoria.isPresent()) {

            model.addAttribute("categorias", categoria.get());

            return "formCategoria";
        }

        return "redirect:/Categoria";
    }

    @PostMapping("/deleteCategoria/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Categoria";
    }
}