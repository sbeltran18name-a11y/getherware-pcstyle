package com.example.gestion.controlador;

import com.example.gestion.servicios.LicenciaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
public class SuperAdminControlador {

    @Autowired
    private LicenciaService licenciaService;

    @GetMapping("/SuperAdmin")
    public String panelSuperAdmin(Model model) {
        Map<String, Integer> conteos = licenciaService.obtenerConteoRegistrosProtegidos();
        int totalRegistros = conteos.values().stream().mapToInt(Integer::intValue).sum();

        model.addAttribute("catalogoModulos", LicenciaService.CATALOGO_MODULOS);
        model.addAttribute("conteosProtegidos", conteos);
        model.addAttribute("totalRegistrosProtegidos", totalRegistros);
        model.addAttribute("cantidadModulosActivos", licenciaService.contarModulosActivos());
        model.addAttribute("totalModulosSistema", LicenciaService.CATALOGO_MODULOS.size());
        model.addAttribute("mensajeSuspension", licenciaService.getMensajeSuspension());
        model.addAttribute("paginaActual", "SuperAdmin");

        return "SuperAdmin";
    }

    @PostMapping("/SuperAdmin/guardar")
    public String guardarConfiguracion(
            @RequestParam(required = false) String nombreEmpresa,
            @RequestParam(required = false) String nitEmpresa,
            @RequestParam(required = false) String planContratado,
            @RequestParam(required = false) String estadoMembresia,
            @RequestParam(required = false) String fechaVencimiento,
            @RequestParam(required = false) String mensajeSuspension,
            @RequestParam(value = "modulosHabilitados", required = false) List<String> modulosHabilitados,
            RedirectAttributes redirectAttrs) {

        licenciaService.actualizarLicencia(
                nombreEmpresa,
                nitEmpresa,
                planContratado,
                estadoMembresia,
                fechaVencimiento,
                mensajeSuspension,
                modulosHabilitados
        );

        redirectAttrs.addFlashAttribute("mensajeExito",
                "Licencia y módulos de «" + licenciaService.getNombreEmpresaCliente()
                + "» actualizados correctamente. El 100% de los datos en la base de datos permanece intacto.");
        return "redirect:/SuperAdmin";
    }

    @PostMapping("/SuperAdmin/preset")
    public String aplicarPreset(
            @RequestParam String tipo,
            RedirectAttributes redirectAttrs) {

        licenciaService.aplicarPreset(tipo);

        String resumen = switch (tipo.toUpperCase()) {
            case "FULL" -> "Membresía ACTIVADA con el Plan Enterprise Full (todos los 16 módulos habilitados).";
            case "COMERCIAL" -> "Plan Comercial Pyme aplicado: se desactivaron temporalmente Contabilidad y Auditoría sin borrar ningún dato.";
            case "MORA" -> "Membresía puesta en MODO SOLO LECTURA (Mora): la empresa puede consultar sus datos, pero no registrar ni editar.";
            case "SUSPENDER" -> "Membresía SUSPENDIDA por falta de pago: acceso operativo pausado conservando toda la base de datos intacta.";
            default -> "Configuración de membresía actualizada.";
        };

        redirectAttrs.addFlashAttribute("mensajeExito", resumen);
        return "redirect:/SuperAdmin";
    }

    @GetMapping("/MembresiaSuspendida")
    public String membresiaSuspendida(
            @RequestParam(required = false, defaultValue = "MODULO") String motivo,
            @RequestParam(required = false, defaultValue = "Sistema") String modulo,
            Model model) {

        Map<String, Integer> conteos = licenciaService.obtenerConteoRegistrosProtegidos();
        String claveNormalizada = licenciaService.normalizarModulo(modulo);
        int registrosDelModulo = conteos.getOrDefault(claveNormalizada, 0);
        int totalRegistros = conteos.values().stream().mapToInt(Integer::intValue).sum();

        model.addAttribute("motivoBloqueo", motivo);
        model.addAttribute("codigoModuloBloqueado", claveNormalizada);
        model.addAttribute("nombreModuloBloqueado",
                "SuperAdmin".equalsIgnoreCase(modulo) ? "Panel de Super Administrador (Licencia SaaS)" : licenciaService.obtenerNombreAmigableModulo(modulo));
        model.addAttribute("permisoRequeridoModulo",
                "SuperAdmin".equalsIgnoreCase(modulo) ? "PROVEEDOR_SUPER_ADMIN" : licenciaService.obtenerPermisoRequerido(modulo));
        model.addAttribute("registrosProtegidosModulo", registrosDelModulo);
        model.addAttribute("totalRegistrosProtegidos", totalRegistros);
        model.addAttribute("mensajeSuspension", licenciaService.getMensajeSuspension());
        model.addAttribute("paginaActual", claveNormalizada);

        return "membresiaSuspendida";
    }
}
