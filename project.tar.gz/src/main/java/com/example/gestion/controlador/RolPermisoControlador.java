package com.example.gestion.controlador;

import com.example.gestion.modelo.Permisos;
import com.example.gestion.modelo.Rol;
import com.example.gestion.modelo.RolPermiso;
import com.example.gestion.servicios.PermisosService;
import com.example.gestion.servicios.RolPermisoService;
import com.example.gestion.servicios.Rolservice;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class RolPermisoControlador {

    @Autowired
    private RolPermisoService service;

    @Autowired
    private Rolservice rolService;

    @Autowired
    private PermisosService permisoService;

    @GetMapping("/RolPermiso")
    public String listar(Model model) {

        List<RolPermiso> relaciones = service.listar();

        model.addAttribute("RolPermisos", relaciones);
        model.addAttribute("nombresRoles",
                Mapas.porId(rolService.listar(), Rol::getId, Rol::getNombre));
        model.addAttribute("nombresPermisos",
                Mapas.porId(permisoService.listar(), Permisos::getId, Permisos::getNombre));

        return "RolPermiso";
    }

    @GetMapping("/newRolPermiso")
    public String agregar(Model model) {

        model.addAttribute("rolPermisos", new RolPermiso());

        model.addAttribute("roles", rolService.listar());

        model.addAttribute("permisos", permisoService.listar());

        return "formRolPermiso";
    }

    @PostMapping("/saveRolPermiso")
    public String save(@ModelAttribute RolPermiso rolPermiso) {

        service.save(rolPermiso);

        return "redirect:/RolPermiso";
    }

    @GetMapping("/editRolPermiso/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<RolPermiso> relacion = service.listarId(id);

        if (relacion.isPresent()) {

            model.addAttribute("rolPermisos", relacion.get());

            model.addAttribute("roles", rolService.listar());

            model.addAttribute("permisos", permisoService.listar());

            return "formRolPermiso";
        }

        return "redirect:/RolPermiso";
    }

    @PostMapping("/deleteRolPermiso/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/RolPermiso";
    }
}