package com.example.gestion.controlador;
import com.example.gestion.modelo.AlertaInventario;
import com.example.gestion.modelo.EstadoAlerta;
import com.example.gestion.modelo.Producto;
import com.example.gestion.servicios.AlertaInventarioService;
import com.example.gestion.servicios.ProductoService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class AlertaInventarioControlador {

    @Autowired
    private AlertaInventarioService service;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/AlertaInventario")
    public String listar(Model model) {

        List<AlertaInventario> alertas = service.listar();

        model.addAttribute("Alertas", alertas);
        model.addAttribute("nombresProductos",
                Mapas.porId(productoService.listar(), Producto::getId, p -> p.getCodigo() + " - " + p.getNombre()));

        return "AlertaInventario";
    }

    @GetMapping("/newAlertaInventario")
    public String agregar(Model model) {

        model.addAttribute("alertas", new AlertaInventario());

        model.addAttribute("productos", productoService.listar());

        model.addAttribute("estados", EstadoAlerta.values());

        return "formAlertaInventario";
    }

    @PostMapping("/saveAlertaInventario")
    public String save(@ModelAttribute AlertaInventario alerta) {

        service.save(alerta);

        return "redirect:/AlertaInventario";
    }

    @GetMapping("/editAlertaInventario/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<AlertaInventario> alerta = service.listarId(id);

        if (alerta.isPresent()) {

            model.addAttribute("alertas", alerta.get());

            model.addAttribute("productos", productoService.listar());

            model.addAttribute("estados", EstadoAlerta.values());

            return "formAlertaInventario";
        }

        return "redirect:/AlertaInventario";
    }

    @PostMapping("/deleteAlertaInventario/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/AlertaInventario";
    }
}