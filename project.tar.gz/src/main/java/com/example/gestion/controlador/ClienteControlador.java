package com.example.gestion.controlador;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.gestion.modelo.Cliente;
import com.example.gestion.servicios.ClienteService;

@Controller
public class ClienteControlador {

    @Autowired
    private ClienteService service;

    @GetMapping("/Cliente")
    public String listar(Model model) {

        List<Cliente> clientes = service.listar();

        model.addAttribute("Cliente", clientes);

        return "Cliente";
    }

    @GetMapping("/newCliente")
    public String agregar(Model model) {

        model.addAttribute("clientes", new Cliente());

        return "formCliente";
    }

    @PostMapping("/saveCliente")
    public String save(@Validated Cliente cliente) {

        service.save(cliente);

        return "redirect:/Cliente";
    }

    @GetMapping("/editCliente/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Cliente> cliente = service.listarId(id);

        if (cliente.isPresent()) {

            model.addAttribute("clientes", cliente.get());

            return "formCliente";
        }

        return "redirect:/Cliente";
    }

    @PostMapping("/deleteCliente/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Cliente";
    }
}