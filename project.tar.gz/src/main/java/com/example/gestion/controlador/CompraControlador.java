package com.example.gestion.controlador;
import com.example.gestion.modelo.Compra;
import com.example.gestion.modelo.DetalleCompra;
import com.example.gestion.modelo.EstadoCompra;
import com.example.gestion.modelo.Producto;
import com.example.gestion.modelo.Proveedor;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.CompraService;
import com.example.gestion.servicios.DetalleCompraService;
import com.example.gestion.servicios.ProductoService;
import com.example.gestion.servicios.ProveedorService;
import com.example.gestion.servicios.UsuarioService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class CompraControlador {

    @Autowired
    private CompraService service;

    @Autowired
    private ProveedorService proveedorService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private DetalleCompraService detalleCompraService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/Compra")
    public String listar(Model model) {

        List<Compra> compras = service.listar();

        model.addAttribute("Compras", compras);
        model.addAttribute("nombresProveedores",
                Mapas.porId(proveedorService.listar(), Proveedor::getId, Proveedor::getRazonSocial));
        model.addAttribute("nombresUsuarios",
                Mapas.porId(usuarioService.listar(), Usuario::getId, u -> u.getNombres() + " " + u.getApellidos()));

        return "Compra";
    }

    @GetMapping("/verCompra/{id}")
    public String verComprobante(@PathVariable int id, Model model) {

        Optional<Compra> compraOpt = service.listarId(id);
        if (compraOpt.isEmpty()) {
            return "redirect:/Compra";
        }

        Compra compra = compraOpt.get();
        List<DetalleCompra> detalles = detalleCompraService.listarPorCompra(id);
        List<Producto> productos = productoService.listar();

        model.addAttribute("compra", compra);
        model.addAttribute("proveedor", proveedorService.listarId(compra.getProveedorId()).orElse(null));
        model.addAttribute("responsable", usuarioService.listarId(compra.getUsuarioId()).orElse(null));
        model.addAttribute("detalles", detalles);
        model.addAttribute("codigosProductos", Mapas.porId(productos, Producto::getId, Producto::getCodigo));
        model.addAttribute("nombresProductos", Mapas.porId(productos, Producto::getId, Producto::getNombre));

        return "comprobanteCompra";
    }

    @GetMapping("/newCompra")
    public String agregar(Model model) {

        Compra nueva = new Compra();
        nueva.setFecha(LocalDateTime.now().withSecond(0).withNano(0));
        nueva.setSubtotal(BigDecimal.ZERO);
        nueva.setImpuesto(BigDecimal.ZERO);
        nueva.setTotal(BigDecimal.ZERO);
        nueva.setEstado(EstadoCompra.CONFIRMADA);
        nueva.setNumeroCompra(String.format("CMP-%03d", service.listar().size() + 1));

        List<Usuario> listaUsuarios = usuarioService.listar();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated()) {
            listaUsuarios.stream()
                    .filter(u -> u.getEmail() != null && u.getEmail().equalsIgnoreCase(auth.getName()))
                    .findFirst()
                    .ifPresent(u -> nueva.setUsuarioId(u.getId()));
        }

        model.addAttribute("compras", nueva);

        model.addAttribute("proveedores", proveedorService.listar());

        model.addAttribute("usuarios", listaUsuarios);

        model.addAttribute("estados", EstadoCompra.values());

        return "formCompra";
    }

    @PostMapping("/saveCompra")
    public String save(@ModelAttribute Compra compra, RedirectAttributes redirectAttrs) {

        boolean eraNueva = (compra.getId() == 0);
        service.save(compra);

        if (eraNueva && compra.getId() > 0) {
            redirectAttrs.addFlashAttribute("mensajeExito",
                    "Orden de compra " + compra.getNumeroCompra() + " creada. Ahora puedes agregar los productos comprados.");
            return "redirect:/DetalleCompra?compraId=" + compra.getId();
        }

        return "redirect:/Compra";
    }

    @GetMapping("/editCompra/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Compra> compra = service.listarId(id);

        if (compra.isPresent()) {

            model.addAttribute("compras", compra.get());

            model.addAttribute("proveedores", proveedorService.listar());

            model.addAttribute("usuarios", usuarioService.listar());

            model.addAttribute("estados", EstadoCompra.values());

            return "formCompra";
        }

        return "redirect:/Compra";
    }

    @PostMapping("/deleteCompra/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Compra";
    }
}