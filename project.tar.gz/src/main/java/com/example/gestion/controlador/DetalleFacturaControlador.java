package com.example.gestion.controlador;

import com.example.gestion.modelo.DetalleFactura;
import com.example.gestion.modelo.FacturaVenta;
import com.example.gestion.modelo.Producto;
import com.example.gestion.servicios.DetalleFacturaService;
import com.example.gestion.servicios.FacturaVentaService;
import com.example.gestion.servicios.ProductoService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class DetalleFacturaControlador {

    @Autowired
    private DetalleFacturaService service;

    @Autowired
    private FacturaVentaService facturaService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/DetalleFactura")
    public String listar(
            @RequestParam(value = "facturaId", required = false) Integer facturaId,
            Model model) {

        List<DetalleFactura> detalles = (facturaId != null && facturaId > 0)
                ? service.listarPorFactura(facturaId)
                : service.listar();

        model.addAttribute("Detalles", detalles);
        model.addAttribute("facturaIdFiltro", facturaId);
        if (facturaId != null && facturaId > 0) {
            facturaService.listarId(facturaId).ifPresent(f -> model.addAttribute("facturaSeleccionada", f));
        }
        model.addAttribute("numerosFacturas",
                Mapas.porId(facturaService.listar(), FacturaVenta::getId, FacturaVenta::getNumeroFactura));
        model.addAttribute("nombresProductos",
                Mapas.porId(productoService.listar(), Producto::getId, p -> p.getCodigo() + " - " + p.getNombre()));

        return "DetalleFactura";
    }

    @GetMapping("/newDetalleFactura")
    public String agregar(
            @RequestParam(value = "facturaId", required = false) Integer facturaId,
            Model model) {

        DetalleFactura nuevo = new DetalleFactura();
        if (facturaId != null && facturaId > 0) {
            nuevo.setFacturaId(facturaId);
        }

        model.addAttribute("detalles", nuevo);
        model.addAttribute("facturas", facturaService.listar());
        model.addAttribute("productos", productoService.listar());

        return "formDetalleFactura";
    }

    @PostMapping("/saveDetalleFactura")
    public String save(@ModelAttribute DetalleFactura detalle) {

        service.save(detalle);

        if (detalle.getFacturaId() > 0) {
            return "redirect:/DetalleFactura?facturaId=" + detalle.getFacturaId();
        }
        return "redirect:/DetalleFactura";
    }

    @GetMapping("/editDetalleFactura/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<DetalleFactura> detalle = service.listarId(id);

        if (detalle.isPresent()) {

            model.addAttribute("detalles", detalle.get());
            model.addAttribute("facturas", facturaService.listar());
            model.addAttribute("productos", productoService.listar());

            return "formDetalleFactura";
        }

        return "redirect:/DetalleFactura";
    }

    @PostMapping("/deleteDetalleFactura/{id}")
    public String delete(@PathVariable int id) {

        Optional<DetalleFactura> existente = service.listarId(id);
        Integer facturaId = existente.map(DetalleFactura::getFacturaId).orElse(null);

        service.delete(id);

        if (facturaId != null && facturaId > 0) {
            return "redirect:/DetalleFactura?facturaId=" + facturaId;
        }
        return "redirect:/DetalleFactura";
    }
}