package com.example.gestion.controlador;
import com.example.gestion.modelo.Categoriaproducto;
import com.example.gestion.modelo.Producto;
import com.example.gestion.servicios.CategoriaService;
import com.example.gestion.servicios.ProductoImagenService;
import com.example.gestion.servicios.ProductoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class ProductoControlador {

    @Autowired
    private ProductoService service;

    @Autowired
    private CategoriaService categoriaService;

    @Autowired
    private ProductoImagenService productoImagenService;

    // LISTAR Y FILTRAR PRODUCTOS
    @GetMapping("/Producto")
    public String listar(
            @RequestParam(required = false) String busqueda,
            @RequestParam(required = false) Integer categoriaId,
            @RequestParam(required = false) String estado,
            Model model) {

        List<Producto> productos = service.filtrar(
                busqueda,
                categoriaId,
                estado
        );

        List<Categoriaproducto> categorias = categoriaService.listar();

        Map<Integer, String> nombresCategorias = categorias.stream()
                .collect(Collectors.toMap(
                        Categoriaproducto::getId,
                        Categoriaproducto::getNombre,
                        (nombreAnterior, nombreNuevo) -> nombreAnterior
                ));

        Map<Integer, Boolean> tieneFotoPorProducto = productos.stream()
                .collect(Collectors.toMap(
                        Producto::getId,
                        p -> productoImagenService.tieneImagen(p.getId()),
                        (a, b) -> a
                ));

        model.addAttribute("Producto", productos);
        model.addAttribute("categorias", categorias);
        model.addAttribute("nombresCategorias", nombresCategorias);
        model.addAttribute("tieneFotoPorProducto", tieneFotoPorProducto);

        model.addAttribute("busqueda",
                busqueda == null ? "" : busqueda);

        model.addAttribute("categoriaSeleccionada",
                categoriaId == null ? "" : categoriaId);

        model.addAttribute("estadoSeleccionado",
                estado == null ? "" : estado);

        model.addAttribute("paginaActual", "Producto");

        return "Producto";
    }

    // SERVIR IMAGEN O MINIATURA CORPORATIVA DEL PRODUCTO
    @GetMapping("/producto-imagen/{id}")
    @ResponseBody
    public ResponseEntity<byte[]> verImagenProducto(@PathVariable int id) {
        Optional<Path> rutaOpt = productoImagenService.obtenerRutaImagen(id);
        if (rutaOpt.isPresent()) {
            try {
                Path archivo = rutaOpt.get();
                byte[] bytes = Files.readAllBytes(archivo);
                MediaType mediaType = productoImagenService.detectarMediaType(archivo);
                return ResponseEntity.ok()
                        .header(HttpHeaders.CACHE_CONTROL, CacheControl.noCache().getHeaderValue())
                        .contentType(mediaType)
                        .body(bytes);
            } catch (IOException ignored) {
            }
        }

        String etiqueta = service.listarId(id)
                .map(p -> (p.getCodigo() != null && !p.getCodigo().isBlank()) ? p.getCodigo() : p.getNombre())
                .orElse("PC");
        byte[] svg = productoImagenService.generarPlaceholderSvg(etiqueta);
        return ResponseEntity.ok()
                .header(HttpHeaders.CACHE_CONTROL, CacheControl.noCache().getHeaderValue())
                .contentType(MediaType.valueOf("image/svg+xml"))
                .body(svg);
    }

    // ABRIR FORMULARIO PARA CREAR
    @GetMapping("/newProducto")
    public String agregar(Model model) {

        model.addAttribute("productos", new Producto());
        model.addAttribute("categorias", categoriaService.listar());
        model.addAttribute("tieneImagen", false);
        model.addAttribute("paginaActual", "Producto");

        return "formProducto";
    }

    // GUARDAR PRODUCTO + FOTO
    @PostMapping("/saveProducto")
    public String save(
            @ModelAttribute Producto producto,
            @RequestParam(value = "imagenArchivo", required = false) MultipartFile imagenArchivo,
            @RequestParam(value = "eliminarImagenActual", required = false, defaultValue = "false") boolean eliminarImagenActual) {

        service.save(producto);

        if (producto.getId() > 0) {
            if (eliminarImagenActual) {
                productoImagenService.eliminarImagen(producto.getId());
            }
            if (imagenArchivo != null && !imagenArchivo.isEmpty()) {
                productoImagenService.guardarImagen(producto.getId(), imagenArchivo);
            }
        }

        return "redirect:/Producto";
    }

    // ABRIR FORMULARIO PARA EDITAR
    @GetMapping("/editProducto/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Producto> producto = service.listarId(id);

        if (producto.isPresent()) {

            model.addAttribute("productos", producto.get());
            model.addAttribute("categorias", categoriaService.listar());
            model.addAttribute("tieneImagen", productoImagenService.tieneImagen(id));
            model.addAttribute("paginaActual", "Producto");

            return "formProducto";
        }

        return "redirect:/Producto";
    }

    // ELIMINAR PRODUCTO
    @PostMapping("/deleteProducto/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Producto";
    }
}