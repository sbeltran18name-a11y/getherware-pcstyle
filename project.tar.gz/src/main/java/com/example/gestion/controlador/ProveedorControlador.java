package com.example.gestion.controlador;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.gestion.modelo.Proveedor;
import com.example.gestion.servicios.ProveedorService;

@Controller
public class ProveedorControlador {

    @Autowired
    private ProveedorService service;

    @GetMapping("/Proveedor")
    public String listar(Model model) {

        List<Proveedor> proveedores = service.listar();

        model.addAttribute("Proveedor", proveedores);

        return "Proveedor";
    }

    @GetMapping("/newProveedor")
    public String agregar(Model model) {

        model.addAttribute("proveedores", new Proveedor());

        return "formProveedor";
    }

    @PostMapping("/saveProveedor")
    public String save(@Validated Proveedor proveedor) {

        service.save(proveedor);

        return "redirect:/Proveedor";
    }

    @GetMapping("/editProveedor/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<Proveedor> proveedor = service.listarId(id);

        if (proveedor.isPresent()) {

            model.addAttribute("proveedores", proveedor.get());

            return "formProveedor";
        }

        return "redirect:/Proveedor";
    }

    @PostMapping("/deleteProveedor/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Proveedor";
    }
}