package com.example.gestion.controlador;
import java.util.List;
import java.util.Optional;
import com.example.gestion.servicios.Rolservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.gestion.modelo.Rol;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.UsuarioService;
import com.example.gestion.util.Mapas;

@Controller
public class UsuarioControlador {

    @Autowired
    private UsuarioService service;

    @Autowired
private Rolservice rolService;

    @GetMapping("/Usuario")
    public String listar(Model model) {

        List<Usuario> usuarios = service.listar();

        model.addAttribute("Usuario", usuarios);
        model.addAttribute("nombresRoles",
                Mapas.porId(rolService.listar(), Rol::getId, Rol::getNombre));

        return "Usuario";
    }

@GetMapping("/newUsuario")
public String agregar(Model model) {
    model.addAttribute("usuarios", new Usuario());
    model.addAttribute("roles", rolService.listar());
    return "formUsuario";
}

    @PostMapping("/saveUsuario")
    public String save(@Validated Usuario usuario) {

        service.save(usuario);

        return "redirect:/Usuario";
    }

@GetMapping("/editUsuario/{id}")
public String edit(@PathVariable int id, Model model) {

    Optional<Usuario> usuario = service.listarId(id);

    if (usuario.isPresent()) {
        model.addAttribute("usuarios", usuario.get());
        model.addAttribute("roles", rolService.listar());
        return "formUsuario";
    }

    return "redirect:/Usuario";
}
    @PostMapping("/deleteUsuario/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/Usuario";
    }
}
