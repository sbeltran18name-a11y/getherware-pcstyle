package com.example.gestion.controlador;
import com.example.gestion.modelo.EstadoOperacion;
import com.example.gestion.modelo.OperacionContable;
import com.example.gestion.modelo.TipoOperacion;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.OperacionContableService;
import com.example.gestion.servicios.UsuarioService;
import com.example.gestion.util.Mapas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class OperacionContableControlador {

    @Autowired
    private OperacionContableService service;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/OperacionContable")
    public String listar(Model model) {

        List<OperacionContable> operaciones = service.listar();

        model.addAttribute("Operaciones", operaciones);
        model.addAttribute("nombresUsuarios",
                Mapas.porId(usuarioService.listar(), Usuario::getId, u -> u.getNombres() + " " + u.getApellidos()));

        return "OperacionContable";
    }

    @GetMapping("/newOperacionContable")
    public String agregar(Model model) {

        model.addAttribute("operaciones", new OperacionContable());

        model.addAttribute("usuarios", usuarioService.listar());

        model.addAttribute("tipos", TipoOperacion.values());

        model.addAttribute("estados", EstadoOperacion.values());

        return "formOperacionContable";
    }

    @PostMapping("/saveOperacionContable")
    public String save(@ModelAttribute OperacionContable operacion) {

        service.save(operacion);

        return "redirect:/OperacionContable";
    }

    @GetMapping("/editOperacionContable/{id}")
    public String edit(@PathVariable int id, Model model) {

        Optional<OperacionContable> operacion = service.listarId(id);

        if (operacion.isPresent()) {

            model.addAttribute("operaciones", operacion.get());

            model.addAttribute("usuarios", usuarioService.listar());

            model.addAttribute("tipos", TipoOperacion.values());

            model.addAttribute("estados", EstadoOperacion.values());

            return "formOperacionContable";
        }

        return "redirect:/OperacionContable";
    }

    @PostMapping("/deleteOperacionContable/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/OperacionContable";
    }
}