package com.example.gestion.servicios;

import com.example.gestion.interfaces.IfacturaVenta;
import com.example.gestion.interfaces.Ipago;
import com.example.gestion.iservicio.IPagoService;
import com.example.gestion.modelo.EstadoFactura;
import com.example.gestion.modelo.EstadoPago;
import com.example.gestion.modelo.FacturaVenta;
import com.example.gestion.modelo.MetodoPago;
import com.example.gestion.modelo.Pago;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PagoService implements IPagoService {

    @Autowired
    private Ipago data;

    @Autowired
    private IfacturaVenta facturaRepo;

    @Override
    public List<Pago> listar() {
        return (List<Pago>) data.findAll();
    }

    @Override
    public Optional<Pago> listarId(int id) {
        return data.findById(id);
    }

    @Override
    @Transactional
    public int save(Pago pago) {

        if (pago.getMetodoPago() == null) {
            pago.setMetodoPago(MetodoPago.EFECTIVO);
        }

        if (pago.getEstado() == null) {
            pago.setEstado(EstadoPago.PENDIENTE);
        }

        if (pago.getMonto() == null) {
            pago.setMonto(BigDecimal.ZERO);
        }

        if (pago.getFechaPago() == null) {
            pago.setFechaPago(LocalDateTime.now());
        }

        Pago pagoGuardado = data.save(pago);

        if (pagoGuardado != null) {
            actualizarEstadoFacturaPorPagos(pagoGuardado.getFacturaId());
            return 1;
        }

        return 0;
    }

    @Override
    @Transactional
    public void delete(int id) {
        Optional<Pago> existente = data.findById(id);
        data.deleteById(id);
        existente.ifPresent(p -> actualizarEstadoFacturaPorPagos(p.getFacturaId()));
    }

    private void actualizarEstadoFacturaPorPagos(int facturaId) {
        Optional<FacturaVenta> facturaOpt = facturaRepo.findById(facturaId);
        if (facturaOpt.isEmpty()) {
            return;
        }
        FacturaVenta factura = facturaOpt.get();
        if (factura.getEstado() == EstadoFactura.ANULADA) {
            return;
        }

        BigDecimal pagadoAprobado = data.findByFacturaId(facturaId).stream()
                .filter(p -> p.getEstado() == EstadoPago.APROBADO && p.getMonto() != null)
                .map(Pago::getMonto)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalFactura = factura.getTotal() != null ? factura.getTotal() : BigDecimal.ZERO;

        if (pagadoAprobado.compareTo(BigDecimal.ZERO) > 0 && pagadoAprobado.compareTo(totalFactura) >= 0) {
            factura.setEstado(EstadoFactura.PAGADA);
            facturaRepo.save(factura);
        }
    }
}