package com.example.gestion.servicios;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.gestion.modelo.Estado;
import com.example.gestion.interfaces.Irol;
import com.example.gestion.iservicio.Irolservice;
import com.example.gestion.modelo.Rol;

@Service 
public class Rolservice implements Irolservice{

  
    @Autowired
    private Irol data;

    @Override
    public List<Rol> listar() {
        return (List<Rol>) data.findAll();
    }

    @Override
    public Optional<Rol> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Rol rol) {

        if (rol.getCreadoEn() == null) {
            rol.setCreadoEn(LocalDateTime.now());
        }

        if (rol.getEstado() == null) {
            rol.setEstado(Estado.ACTIVO);
        }

        Rol roles = data.save(rol);

        if (roles != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}