package com.example.gestion.servicios;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

@Service
public class ProductoImagenService {

    private final Path directorioBase = Paths.get("uploads", "productos").toAbsolutePath().normalize();

    public ProductoImagenService() {
        try {
            Files.createDirectories(directorioBase);
        } catch (IOException ignored) {
        }
    }

    public void guardarImagen(int productoId, MultipartFile archivo) {
        if (productoId <= 0 || archivo == null || archivo.isEmpty()) {
            return;
        }

        String extension = obtenerExtensionSegura(archivo.getOriginalFilename(), archivo.getContentType());
        try {
            Files.createDirectories(directorioBase);
            eliminarImagen(productoId);
            Path destino = directorioBase.resolve("producto_" + productoId + "." + extension);
            Files.copy(archivo.getInputStream(), destino, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("No se pudo guardar la imagen del producto.", e);
        }
    }

    public Optional<Path> obtenerRutaImagen(int productoId) {
        if (productoId <= 0 || !Files.exists(directorioBase)) {
            return Optional.empty();
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directorioBase, "producto_" + productoId + ".*")) {
            for (Path path : stream) {
                if (Files.isRegularFile(path)) {
                    return Optional.of(path);
                }
            }
        } catch (IOException ignored) {
        }
        return Optional.empty();
    }

    public boolean tieneImagen(int productoId) {
        return obtenerRutaImagen(productoId).isPresent();
    }

    public void eliminarImagen(int productoId) {
        if (productoId <= 0 || !Files.exists(directorioBase)) {
            return;
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directorioBase, "producto_" + productoId + ".*")) {
            for (Path path : stream) {
                Files.deleteIfExists(path);
            }
        } catch (IOException ignored) {
        }
    }

    public MediaType detectarMediaType(Path archivo) {
        String nombre = archivo.getFileName().toString().toLowerCase();
        if (nombre.endsWith(".svg")) {
            return MediaType.valueOf("image/svg+xml");
        }
        if (nombre.endsWith(".png")) {
            return MediaType.IMAGE_PNG;
        }
        if (nombre.endsWith(".webp")) {
            return MediaType.parseMediaType("image/webp");
        }
        if (nombre.endsWith(".gif")) {
            return MediaType.IMAGE_GIF;
        }
        return MediaType.IMAGE_JPEG;
    }

    public byte[] generarPlaceholderSvg(String texto) {
        String codigo = (texto != null && !texto.isBlank()) ? texto.trim().toUpperCase() : "PCSTYLE";
        if (codigo.length() > 14) {
            codigo = codigo.substring(0, 14);
        }
        String svg = "<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240' viewBox='0 0 240 240'>"
                + "<defs>"
                + "<linearGradient id='bg' x1='0%' y1='0%' x2='100%' y2='100%'>"
                + "<stop offset='0%' stop-color='#0f1c2e'/>"
                + "<stop offset='55%' stop-color='#182f4f'/>"
                + "<stop offset='100%' stop-color='#274b82'/>"
                + "</linearGradient>"
                + "<linearGradient id='chip' x1='0%' y1='0%' x2='100%' y2='100%'>"
                + "<stop offset='0%' stop-color='#4f81f7'/>"
                + "<stop offset='100%' stop-color='#2855c5'/>"
                + "</linearGradient>"
                + "</defs>"
                + "<rect width='240' height='240' rx='32' fill='url(#bg)'/>"
                + "<rect x='66' y='46' width='108' height='92' rx='18' fill='url(#chip)' stroke='rgba(255,255,255,0.28)' stroke-width='2'/>"
                + "<rect x='84' y='64' width='72' height='56' rx='10' fill='rgba(11,21,38,0.55)'/>"
                + "<text x='120' y='98' text-anchor='middle' fill='#ffffff' font-family='Segoe UI, Arial, sans-serif' font-size='20' font-weight='800'>PCStyle</text>"
                + "<text x='120' y='174' text-anchor='middle' fill='#ffffff' font-family='Segoe UI, Arial, sans-serif' font-size='15' font-weight='800'>"
                + codigo
                + "</text>"
                + "<text x='120' y='198' text-anchor='middle' fill='#9ec0ff' font-family='Segoe UI, Arial, sans-serif' font-size='11' font-weight='700'>HARDWARE OFICIAL</text>"
                + "</svg>";
        return svg.getBytes(StandardCharsets.UTF_8);
    }

    private String obtenerExtensionSegura(String nombreOriginal, String contentType) {
        if (nombreOriginal != null && nombreOriginal.contains(".")) {
            String ext = nombreOriginal.substring(nombreOriginal.lastIndexOf('.') + 1).toLowerCase();
            if (ext.equals("png") || ext.equals("jpg") || ext.equals("jpeg") || ext.equals("webp") || ext.equals("gif")) {
                return ext;
            }
        }
        if (contentType != null) {
            String ct = contentType.toLowerCase();
            if (ct.contains("png")) return "png";
            if (ct.contains("webp")) return "webp";
            if (ct.contains("gif")) return "gif";
        }
        return "jpg";
    }
}
