package com.example.gestion.servicios;
import com.example.gestion.interfaces.IcuentaContable;
import com.example.gestion.iservicio.ICuentaContableService;
import com.example.gestion.modelo.CuentaContable;
import com.example.gestion.modelo.EstadoCuenta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CuentaContableService implements ICuentaContableService {

    @Autowired
    private IcuentaContable data;

    @Override
    public List<CuentaContable> listar() {
        return (List<CuentaContable>) data.findAll();
    }

    @Override
    public Optional<CuentaContable> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(CuentaContable cuenta) {

        if (cuenta.getEstado() == null) {
            cuenta.setEstado(EstadoCuenta.ACTIVA);
        }

        CuentaContable cuentaGuardada = data.save(cuenta);

        if (cuentaGuardada != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}
