package com.example.gestion.servicios;
import com.example.gestion.interfaces.IoperacionContable;
import com.example.gestion.iservicio.IOperacionContableService;
import com.example.gestion.modelo.EstadoOperacion;
import com.example.gestion.modelo.OperacionContable;
import com.example.gestion.modelo.TipoOperacion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class OperacionContableService implements IOperacionContableService {

    @Autowired
    private IoperacionContable data;

    @Override
    public List<OperacionContable> listar() {
        return (List<OperacionContable>) data.findAll();
    }

    @Override
    public Optional<OperacionContable> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(OperacionContable operacion) {

        if (operacion.getFecha() == null) {
            operacion.setFecha(LocalDateTime.now());
        }

        if (operacion.getTipoOperacion() == null) {
            operacion.setTipoOperacion(TipoOperacion.OTRA);
        }

        if (operacion.getEstado() == null) {
            operacion.setEstado(EstadoOperacion.REGISTRADA);
        }

        OperacionContable operacionGuardada = data.save(operacion);

        if (operacionGuardada != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}
