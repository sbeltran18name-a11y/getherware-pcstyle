package com.example.gestion.servicios;

import com.example.gestion.interfaces.IalertaInventario;
import com.example.gestion.interfaces.Iinventario;
import com.example.gestion.interfaces.ImovimientoInventario;
import com.example.gestion.interfaces.Iproducto;
import com.example.gestion.interfaces.Iusuario;
import com.example.gestion.iservicio.IinventarioService;
import com.example.gestion.modelo.AlertaInventario;
import com.example.gestion.modelo.EstadoAlerta;
import com.example.gestion.modelo.Inventario;
import com.example.gestion.modelo.MovimientoInventario;
import com.example.gestion.modelo.Producto;
import com.example.gestion.modelo.Usuario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class InventarioService implements IinventarioService {

    @Autowired
    private Iinventario data;

    @Autowired
    private ImovimientoInventario movimientoRepo;

    @Autowired
    private IalertaInventario alertaRepo;

    @Autowired
    private Iproducto productoRepo;

    @Autowired
    private Iusuario usuarioRepo;

    @Override
    public List<Inventario> listar() {
        return (List<Inventario>) data.findAll();
    }

    @Override
    public Optional<Inventario> listarId(int id) {
        return data.findById(id);
    }

    @Override
    @Transactional
    public int save(Inventario inventario) {

        BigDecimal stockAnterior = BigDecimal.ZERO;

        if (inventario.getId() > 0) {
            Optional<Inventario> existente = data.findById(inventario.getId());
            if (existente.isPresent()) {
                stockAnterior = existente.get().getStockActual() != null
                        ? existente.get().getStockActual()
                        : BigDecimal.ZERO;
            }
        } else {
            // Si ya existe registro de inventario para ese producto, lo reutilizamos para no violar UNIQUE(producto_id)
            Optional<Inventario> porProducto = data.findByProductoId(inventario.getProductoId());
            if (porProducto.isPresent()) {
                inventario.setId(porProducto.get().getId());
                stockAnterior = porProducto.get().getStockActual() != null
                        ? porProducto.get().getStockActual()
                        : BigDecimal.ZERO;
            }
        }

        if (inventario.getStockActual() == null || inventario.getStockActual().compareTo(BigDecimal.ZERO) < 0) {
            inventario.setStockActual(BigDecimal.ZERO);
        }

        inventario.setActualizadoEn(LocalDateTime.now());

        Inventario inventarioGuardado = data.save(inventario);

        BigDecimal diferencia = inventarioGuardado.getStockActual().subtract(stockAnterior);
        if (diferencia.compareTo(BigDecimal.ZERO) != 0) {
            registrarMovimiento(
                    inventarioGuardado.getProductoId(),
                    obtenerUsuarioActualId(null),
                    "AJUSTE",
                    diferencia.abs(),
                    stockAnterior,
                    inventarioGuardado.getStockActual(),
                    "AJUSTE_MANUAL",
                    inventarioGuardado.getId(),
                    "Ajuste manual desde el módulo de Inventario"
            );
        }

        evaluarAlertaStock(inventarioGuardado.getProductoId(), inventarioGuardado.getStockActual());

        return inventarioGuardado != null ? 1 : 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }

    /**
     * Ajusta el stock de un producto sumando o restando una cantidad (por compra, factura o edición),
     * registra el movimiento en movimientos_inventario y actualiza las alertas de bajo stock.
     */
    @Transactional
    public void ajustarStockPorDelta(
            int productoId,
            BigDecimal deltaCantidad,
            String referenciaTipo,
            Integer referenciaId,
            Integer usuarioIdSugerido,
            String observacion) {

        if (productoId <= 0 || deltaCantidad == null || deltaCantidad.compareTo(BigDecimal.ZERO) == 0) {
            return;
        }

        Inventario inv = data.findByProductoId(productoId).orElseGet(() -> {
            Inventario nuevo = new Inventario();
            nuevo.setProductoId(productoId);
            nuevo.setStockActual(BigDecimal.ZERO);
            nuevo.setActualizadoEn(LocalDateTime.now());
            return nuevo;
        });

        BigDecimal stockAnterior = inv.getStockActual() != null ? inv.getStockActual() : BigDecimal.ZERO;
        BigDecimal stockNuevo = stockAnterior.add(deltaCantidad);
        if (stockNuevo.compareTo(BigDecimal.ZERO) < 0) {
            stockNuevo = BigDecimal.ZERO;
        }

        inv.setStockActual(stockNuevo);
        inv.setActualizadoEn(LocalDateTime.now());
        data.save(inv);

        String tipoMovimiento = deltaCantidad.compareTo(BigDecimal.ZERO) > 0 ? "ENTRADA" : "SALIDA";

        registrarMovimiento(
                productoId,
                obtenerUsuarioActualId(usuarioIdSugerido),
                tipoMovimiento,
                deltaCantidad.abs(),
                stockAnterior,
                stockNuevo,
                referenciaTipo,
                referenciaId,
                observacion
        );

        evaluarAlertaStock(productoId, stockNuevo);
    }

    /**
     * Garantiza que todo producto tenga su fila en inventario y evalúa si requiere alerta de stock mínimo.
     */
    @Transactional
    public void asegurarInventarioYAlerta(Producto producto) {
        if (producto == null || producto.getId() <= 0) {
            return;
        }
        Inventario inv = data.findByProductoId(producto.getId()).orElseGet(() -> {
            Inventario nuevo = new Inventario();
            nuevo.setProductoId(producto.getId());
            nuevo.setStockActual(BigDecimal.ZERO);
            nuevo.setActualizadoEn(LocalDateTime.now());
            return data.save(nuevo);
        });
        evaluarAlertaStock(producto.getId(), inv.getStockActual());
    }

    /**
     * Verifica si el stock actual está en o por debajo del stock mínimo del producto.
     * - Si está bajo, crea o actualiza una alerta PENDIENTE.
     * - Si ya superó el stock mínimo, marca como ATENDIDA cualquier alerta pendiente de ese producto.
     */
    @Transactional
    public void evaluarAlertaStock(int productoId, BigDecimal stockActual) {
        Optional<Producto> prodOpt = productoRepo.findById(productoId);
        if (prodOpt.isEmpty()) {
            return;
        }

        Producto producto = prodOpt.get();
        BigDecimal stockMin = producto.getStockMinimo() != null ? producto.getStockMinimo() : BigDecimal.ZERO;
        BigDecimal stock = stockActual != null ? stockActual : BigDecimal.ZERO;

        List<AlertaInventario> pendientes = alertaRepo.findByProductoIdAndEstado(productoId, EstadoAlerta.PENDIENTE);

        if (stock.compareTo(stockMin) <= 0) {
            if (pendientes.isEmpty()) {
                AlertaInventario nuevaAlerta = new AlertaInventario();
                nuevaAlerta.setProductoId(productoId);
                nuevaAlerta.setStockDetectado(stock);
                nuevaAlerta.setStockMinimo(stockMin);
                nuevaAlerta.setEstado(EstadoAlerta.PENDIENTE);
                nuevaAlerta.setGeneradaEn(LocalDateTime.now());
                alertaRepo.save(nuevaAlerta);
            } else {
                for (AlertaInventario alerta : pendientes) {
                    alerta.setStockDetectado(stock);
                    alerta.setStockMinimo(stockMin);
                    alertaRepo.save(alerta);
                }
            }
        } else if (!pendientes.isEmpty()) {
            for (AlertaInventario alerta : pendientes) {
                alerta.setStockDetectado(stock);
                alerta.setEstado(EstadoAlerta.ATENDIDA);
                alerta.setAtendidaEn(LocalDateTime.now());
                alertaRepo.save(alerta);
            }
        }
    }

    private void registrarMovimiento(
            int productoId,
            int usuarioId,
            String tipo,
            BigDecimal cantidad,
            BigDecimal stockAnterior,
            BigDecimal stockNuevo,
            String referenciaTipo,
            Integer referenciaId,
            String observacion) {

        if (usuarioId <= 0) {
            return;
        }

        MovimientoInventario mov = new MovimientoInventario();
        mov.setProductoId(productoId);
        mov.setUsuarioId(usuarioId);
        mov.setTipo(tipo);
        mov.setCantidad(cantidad);
        mov.setStockAnterior(stockAnterior);
        mov.setStockNuevo(stockNuevo);
        mov.setReferenciaTipo(referenciaTipo);
        mov.setReferenciaId(referenciaId);
        mov.setObservacion(observacion);
        mov.setFecha(LocalDateTime.now());
        movimientoRepo.save(mov);
    }

    private int obtenerUsuarioActualId(Integer sugerido) {
        if (sugerido != null && sugerido > 0 && usuarioRepo.existsById(sugerido)) {
            return sugerido;
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken)) {
            Optional<Usuario> uOpt = usuarioRepo.findByEmailIgnoreCase(auth.getName());
            if (uOpt.isPresent()) {
                return uOpt.get().getId();
            }
        }
        Iterable<Usuario> todos = usuarioRepo.findAll();
        for (Usuario u : todos) {
            return u.getId();
        }
        return 0;
    }
}