package com.example.gestion.servicios;
import com.example.gestion.interfaces.IalertaInventario;
import com.example.gestion.iservicio.IAlertaInventarioService;
import com.example.gestion.modelo.AlertaInventario;
import com.example.gestion.modelo.EstadoAlerta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class AlertaInventarioService implements IAlertaInventarioService {

    @Autowired
    private IalertaInventario data;

    @Override
    public List<AlertaInventario> listar() {
        return (List<AlertaInventario>) data.findAll();
    }

    @Override
    public Optional<AlertaInventario> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(AlertaInventario alerta) {

        if (alerta.getStockDetectado() == null) {
            alerta.setStockDetectado(BigDecimal.ZERO);
        }

        if (alerta.getStockMinimo() == null) {
            alerta.setStockMinimo(BigDecimal.ZERO);
        }

        if (alerta.getEstado() == null) {
            alerta.setEstado(EstadoAlerta.PENDIENTE);
        }

        if (alerta.getGeneradaEn() == null) {
            alerta.setGeneradaEn(LocalDateTime.now());
        }

        if (alerta.getEstado() == EstadoAlerta.ATENDIDA
                && alerta.getAtendidaEn() == null) {

            alerta.setAtendidaEn(LocalDateTime.now());
        }

        if (alerta.getEstado() == EstadoAlerta.PENDIENTE) {
            alerta.setAtendidaEn(null);
        }

        AlertaInventario guardada = data.save(alerta);

        if (guardada != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}
