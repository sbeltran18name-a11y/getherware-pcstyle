package com.example.gestion.servicios;

import jakarta.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Servicio que genera códigos de verificación de 6 dígitos y los envía
 * al correo electrónico del usuario cuando crea una cuenta.
 */
@Service
public class EmailVerificacionService {

    private static final Logger log = LoggerFactory.getLogger(EmailVerificacionService.class);
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int MINUTOS_EXPIRACION = 10;

    private record CodigoTemporal(String codigo, LocalDateTime expiraEn) {
    }

    private final Map<String, CodigoTemporal> codigosPorCorreo = new ConcurrentHashMap<>();

    @Autowired(required = false)
    private JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String remitente;

    @Value("${spring.mail.password:}")
    private String passwordSmtp;

    /**
     * Genera un código de 6 dígitos para el correo indicado e intenta enviarlo por SMTP.
     *
     * @return true si el correo fue enviado por SMTP; false si se usó el modo de respaldo
     *         (por ejemplo, cuando aún no se ha configurado la clave de aplicación de Gmail).
     */
    public boolean generarYEnviarCodigo(String emailDestino, String nombreUsuario) {

        String clave = normalizar(emailDestino);
        String codigo = String.format("%06d", RANDOM.nextInt(1_000_000));

        codigosPorCorreo.put(clave, new CodigoTemporal(
                codigo,
                LocalDateTime.now().plusMinutes(MINUTOS_EXPIRACION)
        ));

        log.info("============================================================");
        log.info(" CÓDIGO DE VERIFICACIÓN PARA {}: {}", emailDestino, codigo);
        log.info("============================================================");

        if (mailSender == null || passwordSmtp == null || passwordSmtp.isBlank()) {
            log.warn("SMTP sin contraseña configurada en application.properties (spring.mail.password). "
                    + "Se muestra el código en consola y en pantalla para pruebas.");
            return false;
        }

        try {
            MimeMessage mensaje = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mensaje, true, "UTF-8");

            if (remitente != null && !remitente.isBlank()) {
                helper.setFrom(remitente, "Getherware · PCStyle");
            }
            helper.setTo(emailDestino);
            helper.setSubject("Código de verificación de tu cuenta - Getherware");
            helper.setText(construirHtmlCorreo(nombreUsuario, codigo), true);

            mailSender.send(mensaje);
            return true;

        } catch (Exception ex) {
            log.warn("No se pudo enviar el correo por SMTP a {}: {}", emailDestino, ex.getMessage());
            return false;
        }
    }

    /**
     * Valida si el código ingresado coincide y no ha vencido.
     */
    public boolean validarCodigo(String emailDestino, String codigoIngresado) {
        if (emailDestino == null || codigoIngresado == null) {
            return false;
        }

        String clave = normalizar(emailDestino);
        CodigoTemporal guardado = codigosPorCorreo.get(clave);

        if (guardado == null) {
            return false;
        }

        if (LocalDateTime.now().isAfter(guardado.expiraEn())) {
            codigosPorCorreo.remove(clave);
            return false;
        }

        if (guardado.codigo().equals(codigoIngresado.trim())) {
            codigosPorCorreo.remove(clave);
            return true;
        }

        return false;
    }

    public String obtenerCodigoActual(String emailDestino) {
        if (emailDestino == null) {
            return null;
        }
        CodigoTemporal guardado = codigosPorCorreo.get(normalizar(emailDestino));
        return guardado != null ? guardado.codigo() : null;
    }

    private String normalizar(String email) {
        return email.trim().toLowerCase();
    }

    private String construirHtmlCorreo(String nombreUsuario, String codigo) {
        String nombre = (nombreUsuario != null && !nombreUsuario.isBlank()) ? nombreUsuario : "Usuario";
        return """
                <div style="font-family:'Segoe UI',Arial,sans-serif;max-width:520px;margin:0 auto;padding:28px;border:1px solid #e2e8f0;border-radius:14px;background:#ffffff;color:#172338;">
                    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
                        <div style="width:40px;height:40px;line-height:40px;text-align:center;border-radius:10px;background:#3768df;color:#ffffff;font-weight:800;font-size:20px;">G</div>
                        <div>
                            <strong style="font-size:18px;color:#14243a;">Getherware</strong><br>
                            <small style="color:#64748b;">Sistema de gestión · PCStyle</small>
                        </div>
                    </div>
                    <h2 style="margin:0 0 12px;font-size:20px;color:#172338;">Verifica tu correo electrónico</h2>
                    <p style="margin:0 0 18px;font-size:14px;line-height:1.6;color:#475569;">
                        Hola <strong>%s</strong>, gracias por registrarte en Getherware. Ingresa el siguiente código de 6 dígitos para activar tu cuenta:
                    </p>
                    <div style="margin:22px 0;padding:18px;border-radius:12px;background:#f0f5ff;border:1px dashed #3768df;text-align:center;">
                        <span style="font-size:32px;font-weight:800;letter-spacing:8px;color:#1d4ed8;">%s</span>
                    </div>
                    <p style="margin:0;font-size:12px;color:#64748b;">
                        Este código vence en %d minutos. Si no solicitaste esta cuenta, puedes ignorar este mensaje.
                    </p>
                </div>
                """.formatted(nombre, codigo, MINUTOS_EXPIRACION);
    }
}
