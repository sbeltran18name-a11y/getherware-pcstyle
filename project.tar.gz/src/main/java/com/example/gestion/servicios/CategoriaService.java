package com.example.gestion.servicios;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.gestion.interfaces.Icategoria;
import com.example.gestion.iservicio.IcategoriaService;
import com.example.gestion.modelo.Categoriaproducto;
import com.example.gestion.modelo.Estado;

@Service
public class CategoriaService implements IcategoriaService {

    @Autowired
    private Icategoria data;

    @Override
    public List<Categoriaproducto> listar() {
        return (List<Categoriaproducto>) data.findAll();
    }

    @Override
    public Optional<Categoriaproducto> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Categoriaproducto categoria) {

        if (categoria.getEstado() == null) {
            categoria.setEstado(Estado.ACTIVO);
        }

        Categoriaproducto categorias = data.save(categoria);

        if (categorias != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}
