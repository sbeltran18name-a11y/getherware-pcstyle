package com.example.gestion.servicios;
import com.example.gestion.interfaces.IrolPermiso;
import com.example.gestion.iservicio.IRolPermisoService;
import com.example.gestion.modelo.RolPermiso;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RolPermisoService implements IRolPermisoService {

    @Autowired
    private IrolPermiso data;

    @Override
    public List<RolPermiso> listar() {
        return (List<RolPermiso>) data.findAll();
    }

    @Override
    public Optional<RolPermiso> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(RolPermiso rolPermiso) {

        if (data.existsByRolIdAndPermisoId(
                rolPermiso.getRolId(),
                rolPermiso.getPermisoId())) {

            return 0;
        }

        if (rolPermiso.getAsignadoEn() == null) {
            rolPermiso.setAsignadoEn(LocalDateTime.now());
        }

        RolPermiso guardado = data.save(rolPermiso);

        if (guardado != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}