package com.example.gestion.servicios;

import com.example.gestion.interfaces.Icompra;
import com.example.gestion.iservicio.ICompraService;
import com.example.gestion.modelo.Compra;
import com.example.gestion.modelo.EstadoCompra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CompraService implements ICompraService {

    @Autowired
    private Icompra data;

    @Override
    public List<Compra> listar() {
        return (List<Compra>) data.findAll();
    }

    @Override
    public Optional<Compra> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Compra compra) {

        if (compra.getFecha() == null) {
            compra.setFecha(LocalDateTime.now());
        }

        if (compra.getEstado() == null) {
            compra.setEstado(EstadoCompra.BORRADOR);
        }

        if (compra.getSubtotal() == null) {
            compra.setSubtotal(java.math.BigDecimal.ZERO);
        }

        if (compra.getImpuesto() == null) {
            compra.setImpuesto(java.math.BigDecimal.ZERO);
        }

        if (compra.getTotal() == null) {
            compra.setTotal(java.math.BigDecimal.ZERO);
        }

        Compra compraGuardada = data.save(compra);

        if (compraGuardada != null) {
            compra.setId(compraGuardada.getId());
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}
