package com.example.gestion.servicios;

import com.example.gestion.interfaces.IdetalleOperacionContable;
import com.example.gestion.iservicio.IDetalleOperacionContableService;
import com.example.gestion.modelo.DetalleOperacionContable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class DetalleOperacionContableService
        implements IDetalleOperacionContableService {

    @Autowired
    private IdetalleOperacionContable data;

    @Override
    public List<DetalleOperacionContable> listar() {
        return (List<DetalleOperacionContable>) data.findAll();
    }

    @Override
    public Optional<DetalleOperacionContable> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(DetalleOperacionContable detalle) {

        if (detalle.getDebito() == null) {
            detalle.setDebito(BigDecimal.ZERO);
        }

        if (detalle.getCredito() == null) {
            detalle.setCredito(BigDecimal.ZERO);
        }

        DetalleOperacionContable detalleGuardado = data.save(detalle);

        if (detalleGuardado != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}
