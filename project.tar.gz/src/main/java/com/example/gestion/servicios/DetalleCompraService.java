package com.example.gestion.servicios;

import com.example.gestion.interfaces.Icompra;
import com.example.gestion.interfaces.IdetalleCompra;
import com.example.gestion.iservicio.IDetalleCompraService;
import com.example.gestion.modelo.Compra;
import com.example.gestion.modelo.DetalleCompra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class DetalleCompraService implements IDetalleCompraService {

    @Autowired
    private IdetalleCompra data;

    @Autowired
    private Icompra compraRepo;

    @Autowired
    private InventarioService inventarioService;

    @Override
    public List<DetalleCompra> listar() {
        return (List<DetalleCompra>) data.findAll();
    }

    public List<DetalleCompra> listarPorCompra(int compraId) {
        return data.findByCompraId(compraId);
    }

    @Override
    public Optional<DetalleCompra> listarId(int id) {
        return data.findById(id);
    }

    @Override
    @Transactional
    public int save(DetalleCompra detalle) {

        BigDecimal cantidad = detalle.getCantidad() != null ? detalle.getCantidad() : BigDecimal.ZERO;
        BigDecimal costo = detalle.getCostoUnitario() != null ? detalle.getCostoUnitario() : BigDecimal.ZERO;
        BigDecimal impuesto = detalle.getImpuesto() != null ? detalle.getImpuesto() : BigDecimal.ZERO;

        detalle.setCantidad(cantidad);
        detalle.setCostoUnitario(costo);
        detalle.setImpuesto(impuesto);

        Integer usuarioCompra = compraRepo.findById(detalle.getCompraId())
                .map(Compra::getUsuarioId)
                .orElse(null);

        if (detalle.getId() == 0) {
            // Si ya existe ese producto en la misma compra, acumulamos la cantidad para no romper uq_compra_producto
            Optional<DetalleCompra> lineaMismoProducto = data.findByCompraId(detalle.getCompraId())
                    .stream()
                    .filter(d -> d.getProductoId() == detalle.getProductoId())
                    .findFirst();

            if (lineaMismoProducto.isPresent()) {
                DetalleCompra existente = lineaMismoProducto.get();
                BigDecimal cantidadAcumulada = existente.getCantidad().add(cantidad);
                BigDecimal impuestoAcumulado = (existente.getImpuesto() != null ? existente.getImpuesto() : BigDecimal.ZERO).add(impuesto);

                detalle.setId(existente.getId());
                detalle.setCantidad(cantidadAcumulada);
                detalle.setImpuesto(impuestoAcumulado);
                detalle.setTotalLinea(cantidadAcumulada.multiply(costo).add(impuestoAcumulado));

                DetalleCompra guardado = data.save(detalle);
                inventarioService.ajustarStockPorDelta(
                        detalle.getProductoId(),
                        cantidad,
                        "COMPRA",
                        detalle.getCompraId(),
                        usuarioCompra,
                        "Entrada por compra #" + detalle.getCompraId()
                );
                recalcularTotalesCompra(detalle.getCompraId());
                return guardado != null ? 1 : 0;
            }

            detalle.setTotalLinea(cantidad.multiply(costo).add(impuesto));
            DetalleCompra guardado = data.save(detalle);

            inventarioService.ajustarStockPorDelta(
                    detalle.getProductoId(),
                    cantidad,
                    "COMPRA",
                    detalle.getCompraId(),
                    usuarioCompra,
                    "Entrada por compra #" + detalle.getCompraId()
            );
            recalcularTotalesCompra(detalle.getCompraId());
            return guardado != null ? 1 : 0;
        }

        // Edición de una línea existente
        Optional<DetalleCompra> anteriorOpt = data.findById(detalle.getId());
        int prodAnterior = anteriorOpt.map(DetalleCompra::getProductoId).orElse(detalle.getProductoId());
        int compraAnterior = anteriorOpt.map(DetalleCompra::getCompraId).orElse(detalle.getCompraId());
        BigDecimal cantAnterior = anteriorOpt.map(DetalleCompra::getCantidad).orElse(BigDecimal.ZERO);

        detalle.setTotalLinea(cantidad.multiply(costo).add(impuesto));
        DetalleCompra detalleGuardado = data.save(detalle);

        if (prodAnterior == detalle.getProductoId()) {
            BigDecimal delta = cantidad.subtract(cantAnterior);
            if (delta.compareTo(BigDecimal.ZERO) != 0) {
                inventarioService.ajustarStockPorDelta(
                        detalle.getProductoId(),
                        delta,
                        "COMPRA",
                        detalle.getCompraId(),
                        usuarioCompra,
                        "Ajuste en detalle de compra #" + detalle.getCompraId()
                );
            }
        } else {
            inventarioService.ajustarStockPorDelta(
                    prodAnterior,
                    cantAnterior.negate(),
                    "COMPRA",
                    compraAnterior,
                    usuarioCompra,
                    "Cambio de producto en compra #" + compraAnterior
            );
            inventarioService.ajustarStockPorDelta(
                    detalle.getProductoId(),
                    cantidad,
                    "COMPRA",
                    detalle.getCompraId(),
                    usuarioCompra,
                    "Entrada por compra #" + detalle.getCompraId()
            );
        }

        if (compraAnterior != detalle.getCompraId()) {
            recalcularTotalesCompra(compraAnterior);
        }
        recalcularTotalesCompra(detalle.getCompraId());

        return detalleGuardado != null ? 1 : 0;
    }

    @Override
    @Transactional
    public void delete(int id) {
        Optional<DetalleCompra> existenteOpt = data.findById(id);
        data.deleteById(id);

        if (existenteOpt.isPresent()) {
            DetalleCompra elim = existenteOpt.get();
            Integer usuarioCompra = compraRepo.findById(elim.getCompraId())
                    .map(Compra::getUsuarioId)
                    .orElse(null);

            if (elim.getCantidad() != null && elim.getCantidad().compareTo(BigDecimal.ZERO) > 0) {
                inventarioService.ajustarStockPorDelta(
                        elim.getProductoId(),
                        elim.getCantidad().negate(),
                        "COMPRA",
                        elim.getCompraId(),
                        usuarioCompra,
                        "Reverso por eliminación de línea en compra #" + elim.getCompraId()
                );
            }
            recalcularTotalesCompra(elim.getCompraId());
        }
    }

    /**
     * Recalcula automáticamente subtotal, impuesto y total de la Compra a partir de sus líneas.
     */
    @Transactional
    public void recalcularTotalesCompra(int compraId) {
        Optional<Compra> compraOpt = compraRepo.findById(compraId);
        if (compraOpt.isEmpty()) {
            return;
        }

        List<DetalleCompra> lineas = data.findByCompraId(compraId);
        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal impuesto = BigDecimal.ZERO;
        BigDecimal total = BigDecimal.ZERO;

        for (DetalleCompra l : lineas) {
            BigDecimal cant = l.getCantidad() != null ? l.getCantidad() : BigDecimal.ZERO;
            BigDecimal costo = l.getCostoUnitario() != null ? l.getCostoUnitario() : BigDecimal.ZERO;
            BigDecimal imp = l.getImpuesto() != null ? l.getImpuesto() : BigDecimal.ZERO;
            BigDecimal subLinea = cant.multiply(costo);
            BigDecimal totLinea = l.getTotalLinea() != null ? l.getTotalLinea() : subLinea.add(imp);

            subtotal = subtotal.add(subLinea);
            impuesto = impuesto.add(imp);
            total = total.add(totLinea);
        }

        Compra compra = compraOpt.get();
        compra.setSubtotal(subtotal);
        compra.setImpuesto(impuesto);
        compra.setTotal(total);
        compraRepo.save(compra);
    }
}
