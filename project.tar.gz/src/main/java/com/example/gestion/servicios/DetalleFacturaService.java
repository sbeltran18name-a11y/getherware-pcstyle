package com.example.gestion.servicios;

import com.example.gestion.interfaces.IdetalleFactura;
import com.example.gestion.interfaces.IfacturaVenta;
import com.example.gestion.iservicio.IDetalleFacturaService;
import com.example.gestion.modelo.DetalleFactura;
import com.example.gestion.modelo.FacturaVenta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class DetalleFacturaService implements IDetalleFacturaService {

    @Autowired
    private IdetalleFactura data;

    @Autowired
    private IfacturaVenta facturaRepo;

    @Autowired
    private InventarioService inventarioService;

    @Override
    public List<DetalleFactura> listar() {
        return (List<DetalleFactura>) data.findAll();
    }

    public List<DetalleFactura> listarPorFactura(int facturaId) {
        return data.findByFacturaId(facturaId);
    }

    @Override
    public Optional<DetalleFactura> listarId(int id) {
        return data.findById(id);
    }

    @Override
    @Transactional
    public int save(DetalleFactura detalle) {

        BigDecimal cantidad = detalle.getCantidad() != null ? detalle.getCantidad() : BigDecimal.ZERO;
        BigDecimal precio = detalle.getPrecioUnitario() != null ? detalle.getPrecioUnitario() : BigDecimal.ZERO;
        BigDecimal impuesto = detalle.getImpuesto() != null ? detalle.getImpuesto() : BigDecimal.ZERO;

        detalle.setCantidad(cantidad);
        detalle.setPrecioUnitario(precio);
        detalle.setImpuesto(impuesto);

        Integer usuarioFactura = facturaRepo.findById(detalle.getFacturaId())
                .map(FacturaVenta::getUsuarioId)
                .orElse(null);

        if (detalle.getId() == 0) {
            // Si el producto ya existe en esta misma factura, sumamos la cantidad a esa línea
            Optional<DetalleFactura> lineaMismoProducto = data.findByFacturaId(detalle.getFacturaId())
                    .stream()
                    .filter(d -> d.getProductoId() == detalle.getProductoId())
                    .findFirst();

            if (lineaMismoProducto.isPresent()) {
                DetalleFactura existente = lineaMismoProducto.get();
                BigDecimal cantidadAcumulada = existente.getCantidad().add(cantidad);
                BigDecimal impuestoAcumulado = (existente.getImpuesto() != null ? existente.getImpuesto() : BigDecimal.ZERO).add(impuesto);

                detalle.setId(existente.getId());
                detalle.setCantidad(cantidadAcumulada);
                detalle.setImpuesto(impuestoAcumulado);
                detalle.setTotalLinea(cantidadAcumulada.multiply(precio).add(impuestoAcumulado));

                DetalleFactura guardado = data.save(detalle);
                inventarioService.ajustarStockPorDelta(
                        detalle.getProductoId(),
                        cantidad.negate(),
                        "FACTURA",
                        detalle.getFacturaId(),
                        usuarioFactura,
                        "Salida por factura de venta #" + detalle.getFacturaId()
                );
                recalcularTotalesFactura(detalle.getFacturaId());
                return guardado != null ? 1 : 0;
            }

            detalle.setTotalLinea(cantidad.multiply(precio).add(impuesto));
            DetalleFactura guardado = data.save(detalle);

            inventarioService.ajustarStockPorDelta(
                    detalle.getProductoId(),
                    cantidad.negate(),
                    "FACTURA",
                    detalle.getFacturaId(),
                    usuarioFactura,
                    "Salida por factura de venta #" + detalle.getFacturaId()
            );
            recalcularTotalesFactura(detalle.getFacturaId());
            return guardado != null ? 1 : 0;
        }

        // Edición de una línea existente
        Optional<DetalleFactura> anteriorOpt = data.findById(detalle.getId());
        int prodAnterior = anteriorOpt.map(DetalleFactura::getProductoId).orElse(detalle.getProductoId());
        int facturaAnterior = anteriorOpt.map(DetalleFactura::getFacturaId).orElse(detalle.getFacturaId());
        BigDecimal cantAnterior = anteriorOpt.map(DetalleFactura::getCantidad).orElse(BigDecimal.ZERO);

        detalle.setTotalLinea(cantidad.multiply(precio).add(impuesto));
        DetalleFactura detalleGuardado = data.save(detalle);

        if (prodAnterior == detalle.getProductoId()) {
            // Si aumentó la cantidad vendida, restamos más stock; si disminuyó, devolvemos stock
            BigDecimal deltaVenta = cantidad.subtract(cantAnterior);
            if (deltaVenta.compareTo(BigDecimal.ZERO) != 0) {
                inventarioService.ajustarStockPorDelta(
                        detalle.getProductoId(),
                        deltaVenta.negate(),
                        "FACTURA",
                        detalle.getFacturaId(),
                        usuarioFactura,
                        "Ajuste en detalle de factura #" + detalle.getFacturaId()
                );
            }
        } else {
            // Devolvemos el stock al producto anterior y descontamos del nuevo
            inventarioService.ajustarStockPorDelta(
                    prodAnterior,
                    cantAnterior,
                    "FACTURA",
                    facturaAnterior,
                    usuarioFactura,
                    "Devolución por cambio de producto en factura #" + facturaAnterior
            );
            inventarioService.ajustarStockPorDelta(
                    detalle.getProductoId(),
                    cantidad.negate(),
                    "FACTURA",
                    detalle.getFacturaId(),
                    usuarioFactura,
                    "Salida por factura de venta #" + detalle.getFacturaId()
            );
        }

        if (facturaAnterior != detalle.getFacturaId()) {
            recalcularTotalesFactura(facturaAnterior);
        }
        recalcularTotalesFactura(detalle.getFacturaId());

        return detalleGuardado != null ? 1 : 0;
    }

    @Override
    @Transactional
    public void delete(int id) {
        Optional<DetalleFactura> existenteOpt = data.findById(id);
        data.deleteById(id);

        if (existenteOpt.isPresent()) {
            DetalleFactura elim = existenteOpt.get();
            Integer usuarioFactura = facturaRepo.findById(elim.getFacturaId())
                    .map(FacturaVenta::getUsuarioId)
                    .orElse(null);

            if (elim.getCantidad() != null && elim.getCantidad().compareTo(BigDecimal.ZERO) > 0) {
                inventarioService.ajustarStockPorDelta(
                        elim.getProductoId(),
                        elim.getCantidad(),
                        "FACTURA",
                        elim.getFacturaId(),
                        usuarioFactura,
                        "Devolución a inventario por eliminación de línea en factura #" + elim.getFacturaId()
                );
            }
            recalcularTotalesFactura(elim.getFacturaId());
        }
    }

    /**
     * Recalcula automáticamente subtotal, impuesto y total de la FacturaVenta a partir de sus líneas.
     */
    @Transactional
    public void recalcularTotalesFactura(int facturaId) {
        Optional<FacturaVenta> facturaOpt = facturaRepo.findById(facturaId);
        if (facturaOpt.isEmpty()) {
            return;
        }

        List<DetalleFactura> lineas = data.findByFacturaId(facturaId);
        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal impuesto = BigDecimal.ZERO;
        BigDecimal total = BigDecimal.ZERO;

        for (DetalleFactura l : lineas) {
            BigDecimal cant = l.getCantidad() != null ? l.getCantidad() : BigDecimal.ZERO;
            BigDecimal precio = l.getPrecioUnitario() != null ? l.getPrecioUnitario() : BigDecimal.ZERO;
            BigDecimal imp = l.getImpuesto() != null ? l.getImpuesto() : BigDecimal.ZERO;
            BigDecimal subLinea = cant.multiply(precio);
            BigDecimal totLinea = l.getTotalLinea() != null ? l.getTotalLinea() : subLinea.add(imp);

            subtotal = subtotal.add(subLinea);
            impuesto = impuesto.add(imp);
            total = total.add(totLinea);
        }

        FacturaVenta factura = facturaOpt.get();
        factura.setSubtotal(subtotal);
        factura.setImpuesto(impuesto);
        factura.setTotal(total);
        facturaRepo.save(factura);
    }
}