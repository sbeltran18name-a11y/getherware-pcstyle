package com.example.gestion.servicios;
import com.example.gestion.interfaces.Iauditoria;
import com.example.gestion.iservicio.IAuditoriaService;
import com.example.gestion.modelo.Auditoria;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditoriaService implements IAuditoriaService {

    @Autowired
    private Iauditoria data;

    @Override
    public List<Auditoria> listar() {
        return (List<Auditoria>) data.findAll();
    }
}