package com.example.gestion.servicios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

@Service
public class LicenciaService {

    private final Path archivoConfig = Paths.get("config", "licencia_getherware.properties").toAbsolutePath().normalize();

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static final Map<String, String> CATALOGO_MODULOS = new LinkedHashMap<>();

    static {
        CATALOGO_MODULOS.put("Producto", "Catálogo de Productos");
        CATALOGO_MODULOS.put("Categoria", "Categorías de Productos");
        CATALOGO_MODULOS.put("Inventario", "Inventario y Movimientos de Kárdex");
        CATALOGO_MODULOS.put("AlertaInventario", "Alertas de Bajo Stock");
        CATALOGO_MODULOS.put("Proveedor", "Directorio de Proveedores");
        CATALOGO_MODULOS.put("Compra", "Órdenes de Compra y Abastecimiento");
        CATALOGO_MODULOS.put("Cliente", "Directorio de Clientes");
        CATALOGO_MODULOS.put("FacturaVenta", "Facturación Electrónica de Ventas");
        CATALOGO_MODULOS.put("Pago", "Pagos y Recaudos");
        CATALOGO_MODULOS.put("CuentaContable", "Plan Único de Cuentas (PUC)");
        CATALOGO_MODULOS.put("OperacionContable", "Operaciones y Asientos Contables");
        CATALOGO_MODULOS.put("Usuario", "Gestión de Usuarios");
        CATALOGO_MODULOS.put("Rol", "Roles del Sistema");
        CATALOGO_MODULOS.put("Permiso", "Permisos de Acceso");
        CATALOGO_MODULOS.put("RolPermiso", "Asignación de Roles y Permisos");
        CATALOGO_MODULOS.put("Auditoria", "Bitácora Inmutable de Auditoría");
    }

    private String nombreEmpresaCliente = "PCStyle S.A.S.";
    private String nitEmpresaCliente = "901.452.890-1";
    private String planContratado = "PLAN ENTERPRISE FULL";
    private String estadoMembresia = "ACTIVA"; // ACTIVA, SOLO_LECTURA, SUSPENDIDA
    private String fechaVencimiento = "2026-12-31";
    private String mensajeSuspension = "El acceso a esta funcionalidad se encuentra temporalmente pausado por estado de membresía o alcance del plan contratado. El 100% de la información histórica de su empresa permanece intacta y protegida en la base de datos.";
    private final Map<String, Boolean> modulosActivos = new LinkedHashMap<>();

    public LicenciaService() {
        for (String clave : CATALOGO_MODULOS.keySet()) {
            modulosActivos.put(clave, true);
        }
        cargarConfiguracion();
    }

    public synchronized void cargarConfiguracion() {
        if (!Files.exists(archivoConfig)) {
            guardarConfiguracion();
            return;
        }
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(archivoConfig)) {
            props.load(in);
            nombreEmpresaCliente = props.getProperty("empresa.nombre", nombreEmpresaCliente);
            nitEmpresaCliente = props.getProperty("empresa.nit", nitEmpresaCliente);
            planContratado = props.getProperty("membresia.plan", planContratado);
            estadoMembresia = props.getProperty("membresia.estado", estadoMembresia);
            fechaVencimiento = props.getProperty("membresia.vencimiento", fechaVencimiento);
            mensajeSuspension = props.getProperty("membresia.mensaje", mensajeSuspension);

            for (String clave : CATALOGO_MODULOS.keySet()) {
                boolean activo = Boolean.parseBoolean(props.getProperty("modulo." + clave, "true"));
                modulosActivos.put(clave, activo);
            }
        } catch (IOException ignored) {
        }
    }

    public synchronized void guardarConfiguracion() {
        try {
            Files.createDirectories(archivoConfig.getParent());
            Properties props = new Properties();
            props.setProperty("empresa.nombre", nombreEmpresaCliente != null ? nombreEmpresaCliente : "PCStyle S.A.S.");
            props.setProperty("empresa.nit", nitEmpresaCliente != null ? nitEmpresaCliente : "901.452.890-1");
            props.setProperty("membresia.plan", planContratado != null ? planContratado : "PLAN ENTERPRISE FULL");
            props.setProperty("membresia.estado", estadoMembresia != null ? estadoMembresia : "ACTIVA");
            props.setProperty("membresia.vencimiento", fechaVencimiento != null ? fechaVencimiento : "2026-12-31");
            props.setProperty("membresia.mensaje", mensajeSuspension != null ? mensajeSuspension : "");

            for (Map.Entry<String, Boolean> entry : modulosActivos.entrySet()) {
                props.setProperty("modulo." + entry.getKey(), String.valueOf(entry.getValue()));
            }
            try (OutputStream out = Files.newOutputStream(archivoConfig)) {
                props.store(out, "Configuracion SaaS de Licencias y Membresia - Getherware");
            }
        } catch (IOException ignored) {
        }
    }

    public synchronized void actualizarLicencia(
            String nombreEmpresa,
            String nitEmpresa,
            String plan,
            String estado,
            String vencimiento,
            String mensaje,
            List<String> modulosSeleccionados) {

        if (nombreEmpresa != null && !nombreEmpresa.isBlank()) {
            this.nombreEmpresaCliente = nombreEmpresa.trim();
        }
        if (nitEmpresa != null && !nitEmpresa.isBlank()) {
            this.nitEmpresaCliente = nitEmpresa.trim();
        }
        if (plan != null && !plan.isBlank()) {
            this.planContratado = plan.trim();
        }
        if (estado != null && !estado.isBlank()) {
            this.estadoMembresia = estado.trim();
        }
        if (vencimiento != null && !vencimiento.isBlank()) {
            this.fechaVencimiento = vencimiento.trim();
        }
        if (mensaje != null && !mensaje.isBlank()) {
            this.mensajeSuspension = mensaje.trim();
        }

        for (String clave : CATALOGO_MODULOS.keySet()) {
            boolean habilitado = modulosSeleccionados != null && modulosSeleccionados.contains(clave);
            modulosActivos.put(clave, habilitado);
        }
        guardarConfiguracion();
    }

    public synchronized void aplicarPreset(String preset) {
        if ("FULL".equalsIgnoreCase(preset)) {
            this.estadoMembresia = "ACTIVA";
            this.planContratado = "PLAN ENTERPRISE FULL";
            for (String clave : CATALOGO_MODULOS.keySet()) {
                modulosActivos.put(clave, true);
            }
        } else if ("COMERCIAL".equalsIgnoreCase(preset)) {
            this.estadoMembresia = "ACTIVA";
            this.planContratado = "PLAN COMERCIAL PYME";
            for (String clave : CATALOGO_MODULOS.keySet()) {
                boolean esContableOSeguridad = clave.equals("CuentaContable")
                        || clave.equals("OperacionContable")
                        || clave.equals("Auditoria")
                        || clave.equals("Permiso")
                        || clave.equals("RolPermiso");
                modulosActivos.put(clave, !esContableOSeguridad);
            }
        } else if ("MORA".equalsIgnoreCase(preset)) {
            this.estadoMembresia = "SOLO_LECTURA";
        } else if ("SUSPENDER".equalsIgnoreCase(preset)) {
            this.estadoMembresia = "SUSPENDIDA";
        }
        guardarConfiguracion();
    }

    public boolean esSuperAdmin(String email, String nombreRol) {
        if (email == null) {
            return false;
        }
        return email.equalsIgnoreCase("sbeltran18.name@gmail.com")
                || (nombreRol != null && nombreRol.toLowerCase().contains("super"));
    }

    public String obtenerPermisoRequerido(String modulo) {
        String clave = normalizarModulo(modulo);
        return switch (clave) {
            case "Producto", "Categoria" -> "GESTION_CATALOGO";
            case "Inventario", "AlertaInventario" -> "CONTROL_INVENTARIO";
            case "Proveedor", "Compra" -> "GESTION_COMPRAS";
            case "Cliente", "FacturaVenta", "Pago" -> "FACTURACION_VENTAS";
            case "CuentaContable", "OperacionContable" -> "CONTABILIDAD_GENERAL";
            case "Usuario", "Rol", "Permiso", "RolPermiso", "Auditoria" -> "SEGURIDAD_Y_AUDITORIA";
            default -> "ACCESO_GENERAL";
        };
    }

    public Map<String, Boolean> obtenerModulosPermitidosPorRol(Integer rolId, String email, String nombreRol) {
        Map<String, Boolean> permitidos = new LinkedHashMap<>();
        if (esSuperAdmin(email, nombreRol)) {
            for (String clave : CATALOGO_MODULOS.keySet()) {
                permitidos.put(clave, true);
            }
            return permitidos;
        }

        List<String> permisosDelRol = List.of();
        if (rolId != null && rolId > 0) {
            try {
                permisosDelRol = jdbcTemplate.queryForList(
                        "SELECT UPPER(p.nombre) FROM rol_permiso rp "
                        + "JOIN permisos p ON p.id = rp.permiso_id "
                        + "WHERE rp.rol_id = ? AND p.estado = 'ACTIVO'",
                        String.class, rolId);
            } catch (Exception ignored) {
            }
        }

        for (String clave : CATALOGO_MODULOS.keySet()) {
            String permReq = obtenerPermisoRequerido(clave);
            boolean tiene = permisosDelRol.contains(permReq);
            permitidos.put(clave, tiene);
        }
        return permitidos;
    }

    public List<String> listarNombresPermisosDeRol(Integer rolId) {
        if (rolId == null || rolId <= 0) {
            return List.of();
        }
        try {
            return jdbcTemplate.queryForList(
                    "SELECT CONCAT(p.nombre, ' (', p.modulo, ')') FROM rol_permiso rp "
                    + "JOIN permisos p ON p.id = rp.permiso_id "
                    + "WHERE rp.rol_id = ? AND p.estado = 'ACTIVO'",
                    String.class, rolId);
        } catch (Exception e) {
            return List.of();
        }
    }

    public boolean usuarioTienePermisoModulo(Integer rolId, String email, String nombreRol, String modulo) {
        String clave = normalizarModulo(modulo);
        if (!CATALOGO_MODULOS.containsKey(clave)) {
            return true;
        }
        Map<String, Boolean> mapa = obtenerModulosPermitidosPorRol(rolId, email, nombreRol);
        return Boolean.TRUE.equals(mapa.get(clave));
    }

    public String normalizarModulo(String modulo) {
        if (modulo == null) {
            return "Dashboard";
        }
        return switch (modulo) {
            case "DetalleCompra", "verCompra" -> "Compra";
            case "DetalleFactura", "verFacturaVenta" -> "FacturaVenta";
            case "DetalleOperacionContable" -> "OperacionContable";
            case "MovimientoInventario" -> "Inventario";
            default -> modulo;
        };
    }

    public synchronized boolean estaModuloActivo(String modulo) {
        String clave = normalizarModulo(modulo);
        if (!CATALOGO_MODULOS.containsKey(clave)) {
            return true;
        }
        return Boolean.TRUE.equals(modulosActivos.get(clave));
    }

    public String obtenerNombreAmigableModulo(String modulo) {
        String clave = normalizarModulo(modulo);
        return CATALOGO_MODULOS.getOrDefault(clave, clave);
    }

    public Map<String, Integer> obtenerConteoRegistrosProtegidos() {
        Map<String, Integer> conteos = new LinkedHashMap<>();
        conteos.put("Producto", contarTabla("productos"));
        conteos.put("Categoria", contarTabla("categorias_producto"));
        conteos.put("Inventario", contarTabla("inventario"));
        conteos.put("AlertaInventario", contarTabla("alertas_inventario"));
        conteos.put("Proveedor", contarTabla("proveedores"));
        conteos.put("Compra", contarTabla("compras"));
        conteos.put("Cliente", contarTabla("clientes"));
        conteos.put("FacturaVenta", contarTabla("facturas_venta"));
        conteos.put("Pago", contarTabla("pagos"));
        conteos.put("CuentaContable", contarTabla("cuentas_contables"));
        conteos.put("OperacionContable", contarTabla("operaciones_contables"));
        conteos.put("Usuario", contarTabla("usuarios"));
        conteos.put("Rol", contarTabla("roles"));
        conteos.put("Permiso", contarTabla("permisos"));
        conteos.put("RolPermiso", contarTabla("rol_permiso"));
        conteos.put("Auditoria", contarTabla("auditoria"));
        return conteos;
    }

    private int contarTabla(String tabla) {
        try {
            Integer c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM " + tabla, Integer.class);
            return c != null ? c : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public synchronized Map<String, Boolean> getModulosActivos() {
        return new LinkedHashMap<>(modulosActivos);
    }

    public synchronized long contarModulosActivos() {
        return modulosActivos.values().stream().filter(Boolean::booleanValue).count();
    }

    public String getNombreEmpresaCliente() {
        return nombreEmpresaCliente;
    }

    public String getNitEmpresaCliente() {
        return nitEmpresaCliente;
    }

    public String getPlanContratado() {
        return planContratado;
    }

    public String getEstadoMembresia() {
        return estadoMembresia;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public String getMensajeSuspension() {
        return mensajeSuspension;
    }
}
