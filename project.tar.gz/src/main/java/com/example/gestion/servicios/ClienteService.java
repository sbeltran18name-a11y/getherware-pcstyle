package com.example.gestion.servicios;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.gestion.interfaces.Icliente;
import com.example.gestion.iservicio.IclienteService;
import com.example.gestion.modelo.Cliente;
import com.example.gestion.modelo.Estado;

@Service
public class ClienteService implements IclienteService {

    @Autowired
    private Icliente data;

    @Override
    public List<Cliente> listar() {
        return (List<Cliente>) data.findAll();
    }

    @Override
    public Optional<Cliente> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Cliente cliente) {

        if (cliente.getEstado() == null) {
            cliente.setEstado(Estado.ACTIVO);
        }

        if (cliente.getCreadoEn() == null) {
            cliente.setCreadoEn(LocalDateTime.now());
        }

        Cliente clientes = data.save(cliente);

        if (clientes != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}