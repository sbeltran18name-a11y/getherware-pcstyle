package com.example.gestion.servicios;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.gestion.interfaces.Iproveedor;
import com.example.gestion.iservicio.IproveedorService;
import com.example.gestion.modelo.Estado;
import com.example.gestion.modelo.Proveedor;

@Service
public class ProveedorService implements IproveedorService {

    @Autowired
    private Iproveedor data;

    @Override
    public List<Proveedor> listar() {
        return (List<Proveedor>) data.findAll();
    }

    @Override
    public Optional<Proveedor> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Proveedor proveedor) {

        if (proveedor.getEstado() == null) {
            proveedor.setEstado(Estado.ACTIVO);
        }

        if (proveedor.getCreadoEn() == null) {
            proveedor.setCreadoEn(LocalDateTime.now());
        }

        Proveedor proveedores = data.save(proveedor);

        if (proveedores != null) {
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}