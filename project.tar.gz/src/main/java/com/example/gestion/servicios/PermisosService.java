package com.example.gestion.servicios;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.gestion.modelo.Estado;
import com.example.gestion.modelo.Permisos;
import com.example.gestion.interfaces.Ipermisos;
import com.example.gestion.iservicio.IpermisosService;


@Service 
public class PermisosService implements IpermisosService {

     @Autowired
    private Ipermisos data;

      @Override
    public List<Permisos> listar() {
        return (List<Permisos>) data.findAll();
    }

    @Override
    public Optional<Permisos> listarId(int id) {
        return data.findById(id);
    }


 @Override
public int save(Permisos p) {

    if (p.getEstado() == null) {
        p.setEstado(Estado.ACTIVO);
    }

    Permisos permiso = data.save(p);

    if (permiso != null) {
        return 1;
    }

    return 0;
}
    @Override
    public void delete(int id) {
        data.deleteById(id);
    }

}
