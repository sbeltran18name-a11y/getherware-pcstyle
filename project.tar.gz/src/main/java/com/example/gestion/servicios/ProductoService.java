package com.example.gestion.servicios;

import com.example.gestion.iservicio.IproductoService;
import com.example.gestion.modelo.Producto;
import com.example.gestion.interfaces.Iproducto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductoService implements IproductoService {

    @Autowired
    private Iproducto data;

    @Autowired
    private InventarioService inventarioService;

    @Autowired
    private ProductoImagenService productoImagenService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Producto> listar() {
        return (List<Producto>) data.findAll();
    }

    @Override
    public Optional<Producto> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Producto producto) {

        if (producto.getCreadoEn() == null) {
            producto.setCreadoEn(LocalDateTime.now());
        }
        producto.setActualizadoEn(LocalDateTime.now());

        Producto productoGuardado = data.save(producto);

        if (productoGuardado != null) {
            producto.setId(productoGuardado.getId());
            inventarioService.asegurarInventarioYAlerta(productoGuardado);
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        Integer enFacturas = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM detalle_factura WHERE producto_id = ?", Integer.class, id);
        Integer enCompras = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM detalle_compra WHERE producto_id = ?", Integer.class, id);
        Integer enMovimientos = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM movimientos_inventario WHERE producto_id = ?", Integer.class, id);

        if ((enFacturas == null || enFacturas == 0)
                && (enCompras == null || enCompras == 0)
                && (enMovimientos == null || enMovimientos == 0)) {
            jdbcTemplate.update("DELETE FROM alertas_inventario WHERE producto_id = ?", id);
            jdbcTemplate.update("DELETE FROM inventario WHERE producto_id = ?", id);
        }

        data.deleteById(id);
        productoImagenService.eliminarImagen(id);
    }

    @Override
    public List<Producto> filtrar(
            String busqueda,
            Integer categoriaId,
            String estado) {

        List<Producto> productos = new ArrayList<>(listar());

        // Filtro por nombre o código
        if (busqueda != null && !busqueda.trim().isEmpty()) {

            String termino = busqueda.trim().toLowerCase();

            productos = productos.stream()
                    .filter(producto ->
                            (producto.getNombre() != null
                                    && producto.getNombre()
                                    .toLowerCase()
                                    .contains(termino))
                            ||
                            (producto.getCodigo() != null
                                    && producto.getCodigo()
                                    .toLowerCase()
                                    .contains(termino))
                    )
                    .collect(Collectors.toList());
        }

        // Filtro por categoría
        if (categoriaId != null && categoriaId > 0) {

            productos = productos.stream()
                    .filter(producto ->
                            producto.getCategoriaId() == categoriaId)
                    .collect(Collectors.toList());
        }

        // Filtro por estado
        if (estado != null && !estado.trim().isEmpty()) {

            if ("ACTIVO".equalsIgnoreCase(estado)) {

                productos = productos.stream()
                        .filter(producto -> producto.isActivo())
                        .collect(Collectors.toList());

            } else if ("INACTIVO".equalsIgnoreCase(estado)) {

                productos = productos.stream()
                        .filter(producto -> !producto.isActivo())
                        .collect(Collectors.toList());
            }
        }

        return productos;
    }
}