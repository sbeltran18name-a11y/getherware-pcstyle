package com.example.gestion.servicios;
import com.example.gestion.interfaces.IfacturaVenta;
import com.example.gestion.iservicio.IFacturaVentaService;
import com.example.gestion.modelo.EstadoFactura;
import com.example.gestion.modelo.FacturaVenta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class FacturaVentaService implements IFacturaVentaService {

    @Autowired
    private IfacturaVenta data;

    @Override
    public List<FacturaVenta> listar() {
        return (List<FacturaVenta>) data.findAll();
    }

    @Override
    public Optional<FacturaVenta> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(FacturaVenta factura) {

        if (factura.getFechaEmision() == null) {
            factura.setFechaEmision(LocalDateTime.now());
        }

        if (factura.getEstado() == null) {
            factura.setEstado(EstadoFactura.BORRADOR);
        }

        if (factura.getSubtotal() == null) {
            factura.setSubtotal(BigDecimal.ZERO);
        }

        if (factura.getImpuesto() == null) {
            factura.setImpuesto(BigDecimal.ZERO);
        }

        if (factura.getTotal() == null) {
            factura.setTotal(BigDecimal.ZERO);
        }

        FacturaVenta facturaGuardada = data.save(factura);

        if (facturaGuardada != null) {
            factura.setId(facturaGuardada.getId());
            return 1;
        }

        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
}