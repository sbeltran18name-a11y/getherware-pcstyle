package com.example.gestion.servicios;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.gestion.interfaces.Iusuario;
import com.example.gestion.iservicio.IusuarioService;
import com.example.gestion.modelo.EstadoUsuario;
import com.example.gestion.modelo.Usuario;

@Service
public class UsuarioService implements IusuarioService {

    private static final BCryptPasswordEncoder BCRYPT = new BCryptPasswordEncoder();

    @Autowired
    private Iusuario data;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Usuario> listar() {
        return (List<Usuario>) data.findAll();
    }

    @Override
    public Optional<Usuario> listarId(int id) {
        return data.findById(id);
    }

    public Optional<Usuario> buscarPorEmail(String email) {
        if (email == null || email.isBlank()) {
            return Optional.empty();
        }
        return data.findByEmailIgnoreCase(email.trim());
    }

    @Override
    public int save(Usuario usuario) {

        if (usuario.getId() > 0) {
            Optional<Usuario> existenteOpt = data.findById(usuario.getId());
            if (existenteOpt.isPresent()) {
                Usuario existente = existenteOpt.get();
                if (usuario.getCreadoEn() == null) {
                    usuario.setCreadoEn(existente.getCreadoEn());
                }
                if (usuario.getUltimoAcceso() == null) {
                    usuario.setUltimoAcceso(existente.getUltimoAcceso());
                }
                if (usuario.getPasswordHash() == null || usuario.getPasswordHash().isBlank()) {
                    usuario.setPasswordHash(existente.getPasswordHash());
                }
            }
        }

        if (usuario.getPasswordHash() != null
                && !usuario.getPasswordHash().isBlank()
                && !esHashBcrypt(usuario.getPasswordHash())) {
            usuario.setPasswordHash(BCRYPT.encode(usuario.getPasswordHash()));
        }

        if (usuario.getEstado() == null) {
            usuario.setEstado(EstadoUsuario.ACTIVO);
        }

        if (usuario.getCreadoEn() == null) {
            usuario.setCreadoEn(LocalDateTime.now());
        }

        usuario.setActualizadoEn(LocalDateTime.now());

        Usuario guardado = data.save(usuario);

        return guardado != null ? 1 : 0;
    }

    @Override
    @Transactional
    public void delete(int id) {
        jdbcTemplate.execute("SET FOREIGN_KEY_CHECKS = 0");
        try {
            jdbcTemplate.update("DELETE FROM usuarios WHERE id = ?", id);
        } finally {
            jdbcTemplate.execute("SET FOREIGN_KEY_CHECKS = 1");
        }
    }

    public static boolean esHashBcrypt(String texto) {
        return texto != null
                && (texto.startsWith("$2a$") || texto.startsWith("$2b$") || texto.startsWith("$2y$"));
    }
}
