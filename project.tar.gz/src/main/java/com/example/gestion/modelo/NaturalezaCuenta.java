package com.example.gestion.modelo;

public enum NaturalezaCuenta {
    DEBITO,
    CREDITO
}