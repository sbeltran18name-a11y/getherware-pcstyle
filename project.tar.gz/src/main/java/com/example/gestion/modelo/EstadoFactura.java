package com.example.gestion.modelo;

public enum EstadoFactura {
    BORRADOR,
    EMITIDA,
    PAGADA,
    ANULADA
}