package com.example.gestion.modelo;
import java.time.LocalDateTime;

import jakarta.persistence.*;



@Entity
@Table(name = "roles")
public class Rol {
 
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nombre;
    private String descripcion;

     @Enumerated(EnumType.STRING)
    private Estado estado;

     private LocalDateTime creadoEn;

      public Rol() {
    }

     public Rol(int id, String nombre, String descripcion, Estado estado, LocalDateTime creadoEn) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.estado = estado;
        this.creadoEn = creadoEn;
     }

     public int getId() {
         return id;
     }

     public void setId(int id) {
         this.id = id;
     }

     public String getNombre() {
         return nombre;
     }

     public void setNombre(String nombre) {
         this.nombre = nombre;
     }

     public String getDescripcion() {
         return descripcion;
     }

     public void setDescripcion(String descripcion) {
         this.descripcion = descripcion;
     }

     public Estado getEstado() {
         return estado;
     }

     public void setEstado(Estado estado) {
         this.estado = estado;
     }

     public LocalDateTime getCreadoEn() {
         return creadoEn;
     }

     public void setCreadoEn(LocalDateTime creadoEn) {
         this.creadoEn = creadoEn;
     }
     
}