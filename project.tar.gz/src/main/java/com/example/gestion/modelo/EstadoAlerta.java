package com.example.gestion.modelo;

public enum EstadoAlerta {
    PENDIENTE,
    ATENDIDA
}
