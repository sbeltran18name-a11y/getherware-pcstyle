package com.example.gestion.modelo;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "alertas_inventario")
public class AlertaInventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int productoId;

    private BigDecimal stockDetectado;

    private BigDecimal stockMinimo;

    @Enumerated(EnumType.STRING)
    private EstadoAlerta estado;

    private LocalDateTime generadaEn;

    private LocalDateTime atendidaEn;

    public AlertaInventario() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductoId() {
        return productoId;
    }

    public void setProductoId(int productoId) {
        this.productoId = productoId;
    }

    public BigDecimal getStockDetectado() {
        return stockDetectado;
    }

    public void setStockDetectado(BigDecimal stockDetectado) {
        this.stockDetectado = stockDetectado;
    }

    public BigDecimal getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(BigDecimal stockMinimo) {
        this.stockMinimo = stockMinimo;
    }

    public EstadoAlerta getEstado() {
        return estado;
    }

    public void setEstado(EstadoAlerta estado) {
        this.estado = estado;
    }

    public LocalDateTime getGeneradaEn() {
        return generadaEn;
    }

    public void setGeneradaEn(LocalDateTime generadaEn) {
        this.generadaEn = generadaEn;
    }

    public LocalDateTime getAtendidaEn() {
        return atendidaEn;
    }

    public void setAtendidaEn(LocalDateTime atendidaEn) {
        this.atendidaEn = atendidaEn;
    }
}