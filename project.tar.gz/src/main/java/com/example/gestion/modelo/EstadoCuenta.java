package com.example.gestion.modelo;

public enum EstadoCuenta {
    ACTIVA,
    INACTIVA
}