package com.example.gestion.modelo;

public enum TipoOperacion {
    COMPRA,
    VENTA,
    AJUSTE,
    OTRA
}