package com.example.gestion.modelo;

public enum EstadoCompra {
    BORRADOR,
    CONFIRMADA,
    ANULADA
}
