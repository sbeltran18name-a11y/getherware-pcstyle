package com.example.gestion.modelo;

public enum TipoCuenta {
    ACTIVO,
    PASIVO,
    PATRIMONIO,
    INGRESO,
    GASTO,
    COSTO
}