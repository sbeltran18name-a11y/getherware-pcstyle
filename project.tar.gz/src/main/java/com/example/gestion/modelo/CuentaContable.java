package com.example.gestion.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "cuentas_contables")
public class CuentaContable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private Integer cuentaPadreId;

    private String codigo;

    private String nombre;

    @Enumerated(EnumType.STRING)
    private TipoCuenta tipo;

    @Enumerated(EnumType.STRING)
    private NaturalezaCuenta naturaleza;

    @Enumerated(EnumType.STRING)
    private EstadoCuenta estado;

    public CuentaContable() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getCuentaPadreId() {
        return cuentaPadreId;
    }

    public void setCuentaPadreId(Integer cuentaPadreId) {
        this.cuentaPadreId = cuentaPadreId;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoCuenta getTipo() {
        return tipo;
    }

    public void setTipo(TipoCuenta tipo) {
        this.tipo = tipo;
    }

    public NaturalezaCuenta getNaturaleza() {
        return naturaleza;
    }

    public void setNaturaleza(NaturalezaCuenta naturaleza) {
        this.naturaleza = naturaleza;
    }

    public EstadoCuenta getEstado() {
        return estado;
    }

    public void setEstado(EstadoCuenta estado) {
        this.estado = estado;
    }
}