package com.example.gestion.modelo;

public enum EstadoOperacion {
    REGISTRADA,
    ANULADA
}
