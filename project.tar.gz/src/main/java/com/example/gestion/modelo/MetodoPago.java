package com.example.gestion.modelo;

public enum MetodoPago {
    EFECTIVO,
    TRANSFERENCIA,
    TARJETA,
    EPAYCO,
    OTRO
}
