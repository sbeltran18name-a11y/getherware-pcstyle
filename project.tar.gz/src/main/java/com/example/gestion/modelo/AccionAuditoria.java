package com.example.gestion.modelo;

public enum AccionAuditoria {
    CREAR,
    CONSULTAR,
    ACTUALIZAR,
    ELIMINAR,
    LOGIN,
    LOGOUT,
    OTRA
}
