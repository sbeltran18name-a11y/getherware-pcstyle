package com.example.gestion.modelo;

public enum EstadoPago {
    PENDIENTE,
    APROBADO,
    RECHAZADO,
    ANULADO
}
