package com.example.gestion.modelo;

public enum EstadoUsuario {
    ACTIVO,
    INACTIVO,
    BLOQUEADO
}
