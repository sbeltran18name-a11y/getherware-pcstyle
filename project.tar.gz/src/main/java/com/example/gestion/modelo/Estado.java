package com.example.gestion.modelo;

public enum Estado {
    ACTIVO,
    INACTIVO
}

