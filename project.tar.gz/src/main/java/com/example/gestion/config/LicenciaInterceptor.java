package com.example.gestion.config;

import com.example.gestion.interfaces.Irol;
import com.example.gestion.interfaces.Iusuario;
import com.example.gestion.modelo.Rol;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.LicenciaService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.FlashMap;
import org.springframework.web.servlet.FlashMapManager;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.support.RequestContextUtils;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Component
public class LicenciaInterceptor implements HandlerInterceptor {

    private static final String[] PREFIJOS_ACCION = {"new", "save", "edit", "delete", "ver"};

    @Autowired
    private LicenciaService licenciaService;

    @Autowired
    private Iusuario usuarioRepo;

    @Autowired
    private Irol rolRepo;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String uri = request.getRequestURI();
        String ctx = request.getContextPath();
        String ruta = uri.substring(ctx.length());

        // Rutas públicas y de infraestructura siempre permitidas
        if (ruta.isEmpty()
                || ruta.equals("/")
                || ruta.startsWith("/Dashboard")
                || ruta.startsWith("/MembresiaSuspendida")
                || ruta.startsWith("/login")
                || ruta.startsWith("/logout")
                || ruta.startsWith("/registro")
                || ruta.startsWith("/verificar-codigo")
                || ruta.startsWith("/reenviar-codigo")
                || ruta.startsWith("/producto-imagen")
                || ruta.startsWith("/css/")
                || ruta.startsWith("/js/")
                || ruta.startsWith("/images/")
                || ruta.startsWith("/error")) {
            return true;
        }

        // Identificar usuario y rol actual
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Usuario usuarioActual = null;
        String nombreRol = "Usuario";
        boolean esSuperAdmin = false;

        if (auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken)) {
            Optional<Usuario> uOpt = usuarioRepo.findByEmailIgnoreCase(auth.getName());
            if (uOpt.isPresent()) {
                usuarioActual = uOpt.get();
                nombreRol = rolRepo.findById(usuarioActual.getRolId()).map(Rol::getNombre).orElse("Usuario");
                esSuperAdmin = licenciaService.esSuperAdmin(usuarioActual.getEmail(), nombreRol);
            }
        }

        // 0. Protección exclusiva del panel /SuperAdmin
        if (ruta.startsWith("/SuperAdmin")) {
            if (!esSuperAdmin) {
                response.sendRedirect(ctx + "/MembresiaSuspendida?motivo=ROL&modulo=SuperAdmin");
                return false;
            }
            return true;
        }

        String moduloBase = extraerModuloBase(ruta);
        String estadoMembresia = licenciaService.getEstadoMembresia();

        // 1. Si la membresía de la empresa está SUSPENDIDA por falta de pago
        if ("SUSPENDIDA".equalsIgnoreCase(estadoMembresia)) {
            String destino = ctx + "/MembresiaSuspendida?motivo=SUSPENDIDA&modulo="
                    + URLEncoder.encode(moduloBase, StandardCharsets.UTF_8);
            response.sendRedirect(destino);
            return false;
        }

        // 2. Si el Super Admin desactivó este módulo específico en la licencia de la empresa
        if (!licenciaService.estaModuloActivo(moduloBase)) {
            String destino = ctx + "/MembresiaSuspendida?motivo=MODULO&modulo="
                    + URLEncoder.encode(moduloBase, StandardCharsets.UTF_8);
            response.sendRedirect(destino);
            return false;
        }

        // 3. Control de permisos por Rol (tabla rol_permiso en MySQL) para usuarios no SuperAdmin
        if (usuarioActual != null && !licenciaService.usuarioTienePermisoModulo(
                usuarioActual.getRolId(), usuarioActual.getEmail(), nombreRol, moduloBase)) {
            String destino = ctx + "/MembresiaSuspendida?motivo=ROL&modulo="
                    + URLEncoder.encode(moduloBase, StandardCharsets.UTF_8);
            response.sendRedirect(destino);
            return false;
        }

        // 4. Si la membresía está en MODO SOLO LECTURA (Mora parcial), permite ver tablas pero bloquea crear/editar/eliminar
        if ("SOLO_LECTURA".equalsIgnoreCase(estadoMembresia) && esAccionDeEscritura(ruta)) {
            FlashMap flashMap = new FlashMap();
            flashMap.put("mensajeError",
                    "🔒 Membresía en Modo Solo Consulta: " + licenciaService.getNombreEmpresaCliente()
                    + " puede consultar toda su información histórica, pero la creación, edición y eliminación están pausadas temporalmente hasta renovar la membresía con Getherware.");
            FlashMapManager manager = RequestContextUtils.getFlashMapManager(request);
            if (manager != null) {
                manager.saveOutputFlashMap(flashMap, request, response);
            }
            response.sendRedirect(ctx + "/" + licenciaService.normalizarModulo(moduloBase));
            return false;
        }

        return true;
    }

    private boolean esAccionDeEscritura(String ruta) {
        String limpia = ruta.startsWith("/") ? ruta.substring(1) : ruta;
        return limpia.startsWith("new")
                || limpia.startsWith("save")
                || limpia.startsWith("edit")
                || limpia.startsWith("delete")
                || limpia.startsWith("atenderAlerta");
    }

    private String extraerModuloBase(String ruta) {
        String limpia = ruta.startsWith("/") ? ruta.substring(1) : ruta;
        int barra = limpia.indexOf('/');
        if (barra >= 0) {
            limpia = limpia.substring(0, barra);
        }
        if (limpia.equals("atenderAlerta")) {
            return "AlertaInventario";
        }
        for (String prefijo : PREFIJOS_ACCION) {
            if (limpia.length() > prefijo.length()
                    && limpia.startsWith(prefijo)
                    && Character.isUpperCase(limpia.charAt(prefijo.length()))) {
                return limpia.substring(prefijo.length());
            }
        }
        return limpia;
    }
}
