package com.example.gestion.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
@Profile("cloud")
public class CloudDataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(CloudDataInitializer.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) {
        try {
            Integer countUsuarios = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM usuarios", Integer.class);
            if (countUsuarios != null && countUsuarios > 0) {
                log.info("Base de datos Cloud ya inicializada ({} usuarios).", countUsuarios);
                return;
            }

            log.info("Inicializando datos empresariales Getherware · PCStyle en la nube...");

            // 1. Roles
            jdbcTemplate.update("INSERT INTO roles (id, nombre, descripcion, estado, creado_en) VALUES "
                    + "(3, 'Administrador General', 'Control total de los módulos comerciales, inventario, finanzas, seguridad y auditoría de Getherware.', 'ACTIVO', '2026-10-01 08:00:00'),"
                    + "(4, 'Ejecutivo Comercial y Facturación', 'Gestión de clientes corporativos, facturación electrónica DIAN y control de pagos.', 'ACTIVO', '2026-10-01 08:05:00'),"
                    + "(5, 'Coordinador de Almacén y Compras', 'Administración del catálogo de productos, órdenes de compra a proveedores y alertas de stock.', 'ACTIVO', '2026-10-01 08:10:00'),"
                    + "(6, 'Contador y Auditor Financiero', 'Gestión del Plan Único de Cuentas (PUC), asientos contables y supervisión de auditoría.', 'ACTIVO', '2026-10-01 08:15:00')");

            // 2. Permisos
            jdbcTemplate.update("INSERT INTO permisos (id, nombre, modulo, descripcion, estado) VALUES "
                    + "(1, 'GESTION_CATALOGO', 'Productos', 'Crear, editar y administrar el catálogo de hardware y fotografías de productos.', 'ACTIVO'),"
                    + "(2, 'CONTROL_INVENTARIO', 'Inventario', 'Supervisar existencias en bodega, movimientos de kardex y alertas de stock mínimo.', 'ACTIVO'),"
                    + "(3, 'GESTION_COMPRAS', 'Compras', 'Registrar proveedores mayoristas y emitir órdenes de abastecimiento.', 'ACTIVO'),"
                    + "(4, 'FACTURACION_VENTAS', 'Facturación', 'Emitir facturas de venta electrónicas, gestionar clientes y aprobar recaudos.', 'ACTIVO'),"
                    + "(5, 'CONTABILIDAD_GENERAL', 'Contabilidad', 'Administrar cuentas contables y registrar comprobantes de partida doble.', 'ACTIVO'),"
                    + "(6, 'SEGURIDAD_Y_AUDITORIA', 'Administración', 'Gestionar usuarios, roles, matriz de permisos y bitácora inmutable de auditoría.', 'ACTIVO')");

            // 3. Rol - Permiso
            jdbcTemplate.update("INSERT INTO rol_permiso (id, rol_id, permiso_id, asignado_en) VALUES "
                    + "(1, 3, 1, '2026-10-01 08:20:00'),(2, 3, 2, '2026-10-01 08:20:00'),(3, 3, 3, '2026-10-01 08:20:00'),"
                    + "(4, 3, 4, '2026-10-01 08:20:00'),(5, 3, 5, '2026-10-01 08:20:00'),(6, 3, 6, '2026-10-01 08:20:00'),"
                    + "(7, 4, 1, '2026-10-01 08:25:00'),(8, 4, 4, '2026-10-01 08:25:00'),"
                    + "(9, 5, 1, '2026-10-01 08:30:00'),(10, 5, 2, '2026-10-01 08:30:00'),(11, 5, 3, '2026-10-01 08:30:00'),"
                    + "(12, 6, 5, '2026-10-01 08:35:00'),(13, 6, 6, '2026-10-01 08:35:00')");

            // 4. Usuarios
            jdbcTemplate.update("INSERT INTO usuarios (id, rol_id, nombres, apellidos, email, password_hash, cargo, estado, ultimo_acceso, creado_en, actualizado_en) VALUES "
                    + "(10, 3, 'Sebastián', 'Beltrán', 'sbeltran18.name@gmail.com', '$2a$10$Yn9gowZ8V3N.FsVCAc/Z..UVyGL8QheVpZ.SdVeBCFojjgnNzv9cG', 'Director General · Administrador', 'ACTIVO', '2026-11-10 17:00:00', '2026-10-01 08:30:00', '2026-11-10 17:00:00'),"
                    + "(12, 4, 'Johan', 'Polentino', 'johan73024@gmail.com', '$2a$10$sGwshhUgVHUFDW26i.J3QuOoyF.nJbpv65KGyPa738ueXln5cUtGS', 'Coordinador Comercial y Ventas', 'ACTIVO', '2026-11-10 16:45:00', '2026-10-05 09:00:00', '2026-11-10 16:45:00'),"
                    + "(13, 6, 'Laura Sofía', 'Gómez Rojas', 'contabilidad@pcstyle.com.co', '$2a$10$Yn9gowZ8V3N.FsVCAc/Z..UVyGL8QheVpZ.SdVeBCFojjgnNzv9cG', 'Contadora General y Auditora', 'ACTIVO', '2026-11-09 14:20:00', '2026-10-05 09:30:00', '2026-11-09 14:20:00')");

            // 5. Categorías
            jdbcTemplate.update("INSERT INTO categorias_producto (id, nombre, descripcion, estado) VALUES "
                    + "(1, 'Procesadores y Motherboards', 'Procesadores AMD Ryzen, Intel Core y placas base ATX de alto rendimiento.', 'ACTIVO'),"
                    + "(2, 'Tarjetas Gráficas (GPU)', 'Aceleradoras gráficas NVIDIA GeForce RTX y AMD Radeon para gaming, IA y renderizado 3D.', 'ACTIVO'),"
                    + "(3, 'Memoria RAM y Almacenamiento SSD', 'Módulos DDR5 de baja latencia y unidades de estado sólido NVMe M.2 PCIe 4.0.', 'ACTIVO'),"
                    + "(4, 'Monitores y Periféricos Pro', 'Monitores QHD/4K de alta tasa de refresco, teclados mecánicos ópticos y mouses inalámbricos.', 'ACTIVO'),"
                    + "(5, 'Portátiles y Estaciones de Trabajo', 'Equipos portátiles corporativos, laptops gamer y workstations ensambladas PCStyle.', 'ACTIVO'),"
                    + "(6, 'Fuentes, Chasis y Refrigeración', 'Fuentes certificadas 80 Plus Gold ATX 3.0, gabinetes de flujo de aire y refrigeración líquida.', 'ACTIVO')");

            // 6. Productos
            jdbcTemplate.update("INSERT INTO productos (id, categoria_id, codigo, nombre, descripcion, precio_compra, precio_venta, stock_minimo, activo, creado_en, actualizado_en) VALUES "
                    + "(1, 1, 'PRO-RYZ7800', 'Procesador AMD Ryzen 7 7800X3D 5.0GHz Socket AM5', 'Procesador de 8 núcleos y 16 hilos con tecnología AMD 3D V-Cache de 96MB L3, ideal para estaciones de alto desempeño.', 1580000.00, 1950000.00, 5.00, 1, '2026-10-02 10:00:00', '2026-11-10 10:00:00'),"
                    + "(2, 2, 'GPU-RTX4070S', 'Tarjeta Gráfica ASUS Dual GeForce RTX 4070 Super 12GB GDDR6X', 'Arquitectura NVIDIA Ada Lovelace con DLSS 3, trazado de rayos de 3ra generación y doble ventilador Axial-tech.', 2650000.00, 3290000.00, 4.00, 1, '2026-10-02 10:10:00', '2026-11-10 10:10:00'),"
                    + "(3, 3, 'SSD-SAM990-2T', 'Unidad SSD NVMe Samsung 990 PRO 2TB PCIe 4.0 M.2', 'Velocidad de lectura secuencial de hasta 7,450 MB/s y escritura de 6,900 MB/s con control térmico inteligente.', 640000.00, 850000.00, 8.00, 1, '2026-10-02 10:20:00', '2026-11-10 10:20:00'),"
                    + "(4, 3, 'RAM-COR32-D5', 'Kit Memoria RAM Corsair Vengeance RGB 32GB (2x16GB) DDR5 6000MHz', 'Módulos DDR5 optimizados para perfiles AMD EXPO e Intel XMP 3.0 con disipador de aluminio anodizado.', 460000.00, 620000.00, 10.00, 1, '2026-10-02 10:30:00', '2026-11-10 10:30:00'),"
                    + "(5, 4, 'MON-LG27-QHD', 'Monitor LG UltraGear 27\" QHD Nano IPS 180Hz 1ms G-Sync', 'Panel QHD (2560x1440) con cobertura de color DCI-P3 del 98%, HDR400 y soporte ergonómico ajustable.', 1050000.00, 1380000.00, 5.00, 1, '2026-10-02 10:40:00', '2026-11-10 10:40:00'),"
                    + "(6, 5, 'LAP-ROG-G16', 'Portátil ASUS ROG Strix G16 Intel Core i9 14900HX 32GB RTX 4070', 'Equipo portátil de alto rendimiento con pantalla Nebula Display 16\" 240Hz, SSD 1TB NVMe y chasis metálico.', 6400000.00, 7890000.00, 3.00, 1, '2026-10-02 10:50:00', '2026-11-10 10:50:00'),"
                    + "(7, 6, 'PSU-COR850E', 'Fuente de Poder Corsair RM850e 850W 80 Plus Gold Full Modular', 'Certificación 80 Plus Gold, compatible con estándar ATX 3.0 y PCIe 5.0 12VHPWR de bajo nivel de ruido.', 480000.00, 650000.00, 6.00, 1, '2026-10-02 11:00:00', '2026-11-10 11:00:00'),"
                    + "(8, 4, 'PER-LOG-GPX2', 'Mouse Inalámbrico Logitech G PRO X Superlight 2 32000 DPI', 'Sensor óptico HERO 2 de grado competitivo, switches híbridos LIGHTFORCE y peso ultraligero de 60 gramos.', 490000.00, 680000.00, 8.00, 1, '2026-10-02 11:10:00', '2026-11-10 11:10:00')");

            // 7. Inventario y Alertas
            jdbcTemplate.update("INSERT INTO inventario (id, producto_id, stock_actual, actualizado_en) VALUES "
                    + "(1, 1, 14.00, '2026-11-10 15:00:00'),(2, 2, 3.00, '2026-11-10 15:00:00'),(3, 3, 22.00, '2026-11-10 15:00:00'),"
                    + "(4, 4, 18.00, '2026-11-10 15:00:00'),(5, 5, 9.00, '2026-11-10 15:00:00'),(6, 6, 2.00, '2026-11-10 15:00:00'),"
                    + "(7, 7, 12.00, '2026-11-10 15:00:00'),(8, 8, 15.00, '2026-11-10 15:00:00')");

            jdbcTemplate.update("INSERT INTO alertas_inventario (id, producto_id, stock_detectado, stock_minimo, estado, generada_en, atendida_en) VALUES "
                    + "(1, 2, 3.00, 4.00, 'PENDIENTE', '2026-11-09 16:30:00', NULL),"
                    + "(2, 6, 2.00, 3.00, 'PENDIENTE', '2026-11-10 11:15:00', NULL),"
                    + "(3, 1, 4.00, 5.00, 'ATENDIDA', '2026-10-25 09:10:00', '2026-10-26 14:00:00')");

            // 8. Proveedores y Clientes
            jdbcTemplate.update("INSERT INTO proveedores (id, nit, razon_social, contacto, telefono, email, direccion, estado, creado_en) VALUES "
                    + "(1, '900458120-3', 'Mayorista Tecnológico de Colombia S.A.S. (Mayortec)', 'Carlos Eduardo Vargas', '6017458890', 'ventas.corporativas@mayortec.com.co', 'Parque Empresarial San Cayetano Bodega 14, Bogotá', 'ACTIVO', '2026-10-01 09:00:00'),"
                    + "(2, '830114902-7', 'Ingram Micro Colombia S.A.S.', 'Diana Marcela Pineda', '6016582200', 'pedidos.colombia@ingrammicro.com', 'Av. El Dorado # 68C-61 Torre Central Of. 801, Bogotá', 'ACTIVO', '2026-10-01 09:15:00'),"
                    + "(3, '901289441-1', 'Importadora Global Hardware & Gaming Ltda.', 'Andrés Felipe Ríos', '3158904412', 'comercial@globalhardware.co', 'Centro Empresarial Las Palmas Of. 402, Medellín', 'ACTIVO', '2026-10-01 09:30:00'),"
                    + "(4, '890903418-5', 'Soluciones y Componentes Digitales S.A.', 'María Fernanda Ospina', '3104459821', 'logistica@componentesdigitales.com.co', 'Zona Franca del Pacífico Bodega 8, Cali', 'ACTIVO', '2026-10-01 09:45:00')");

            jdbcTemplate.update("INSERT INTO clientes (id, tipo_documento, numero_documento, nombre_razon_social, telefono, email, direccion, estado, creado_en) VALUES "
                    + "(1, 'NIT', '901342890-4', 'Arquitectura y Diseño Digital Studio S.A.S.', '3145678910', 'compras@arquitecturadigital.co', 'Calle 93B # 13-45 Edificio Atrium Of. 501, Bogotá', 'ACTIVO', '2026-10-03 10:00:00'),"
                    + "(2, 'NIT', '900781234-1', 'Clínica Médica San Rafael S.A.', '6014329900', 'infraestructura.ti@clinicasanrafael.org.co', 'Carrera 15 # 104-30 Sede Administrativa, Bogotá', 'ACTIVO', '2026-10-04 11:20:00'),"
                    + "(3, 'CC', '1091968386', 'Sebastián Beltrán Corporativo', '3106888502', 'sbeltran18.name@gmail.com', 'Av. Los Libertadores # 15-80 Centro Empresarial, Cúcuta', 'ACTIVO', '2026-10-05 14:15:00'),"
                    + "(4, 'NIT', '800198432-9', 'Universidad Tecnológica Santander (Laboratorios TI)', '6076458800', 'adquisiciones.ti@uts.edu.co', 'Ciudadela Universitaria Edificio de Ingeniería, Bucaramanga', 'ACTIVO', '2026-10-06 09:40:00'),"
                    + "(5, 'CC', '1020845912', 'Camilo Andrés Montoya Salazar', '3007894512', 'camilo.montoya@devstudio.co', 'Carrera 43A # 14-50 El Poblado, Medellín', 'ACTIVO', '2026-10-08 16:00:00')");

            // 9. Compras y Detalles
            jdbcTemplate.update("INSERT INTO compras (id, proveedor_id, usuario_id, numero_compra, fecha, subtotal, impuesto, total, estado, observaciones) VALUES "
                    + "(1, 1, 10, 'CMP-001', '2026-10-18 10:30:00', 18400000.00, 3496000.00, 21896000.00, 'CONFIRMADA', 'Abastecimiento inicial de procesadores Ryzen 7 y unidades SSD NVMe Samsung.'),"
                    + "(2, 2, 10, 'CMP-002', '2026-10-28 14:15:00', 26050000.00, 4949500.00, 30999500.00, 'CONFIRMADA', 'Importación de tarjetas gráficas RTX 4070 Super y portátiles ASUS ROG Strix G16.'),"
                    + "(3, 3, 12, 'CMP-003', '2026-11-06 09:45:00', 11920000.00, 2264800.00, 14184800.00, 'CONFIRMADA', 'Reposición de monitores LG UltraGear QHD y kits de memoria RAM DDR5 Corsair.')");

            jdbcTemplate.update("INSERT INTO detalle_compra (id, compra_id, producto_id, cantidad, costo_unitario, impuesto, total_linea) VALUES "
                    + "(1, 1, 1, 8.00, 1580000.00, 2401600.00, 15041600.00),"
                    + "(2, 1, 3, 9.00, 640000.00, 1094400.00, 6854400.00),"
                    + "(3, 2, 2, 5.00, 2650000.00, 2517500.00, 15767500.00),"
                    + "(4, 2, 6, 2.00, 6400000.00, 2432000.00, 15232000.00),"
                    + "(5, 3, 5, 5.00, 1050000.00, 997500.00, 6247500.00),"
                    + "(6, 3, 4, 5.00, 460000.00, 437000.00, 2737000.00),"
                    + "(7, 3, 7, 4.00, 480000.00, 364800.00, 2284800.00),"
                    + "(8, 3, 8, 5.00, 490000.00, 465500.00, 2915500.00)");

            // 10. Facturas, Detalles y Pagos
            jdbcTemplate.update("INSERT INTO facturas_venta (id, cliente_id, usuario_id, numero_factura, fecha_emision, subtotal, impuesto, total, estado, referencia_dian, observaciones) VALUES "
                    + "(1, 1, 10, 'FV-0001', '2026-10-22 11:20:00', 11060000.00, 2101400.00, 13161400.00, 'PAGADA', 'FE-DIAN-98401', 'Dotación de estaciones de renderizado 3D para estudio de arquitectura.'),"
                    + "(2, 4, 12, 'FV-0002', '2026-11-02 15:40:00', 12070000.00, 2293300.00, 14363300.00, 'PAGADA', 'FE-DIAN-98402', 'Equipos de cómputo y almacenamiento NVMe para laboratorio de ingeniería.'),"
                    + "(3, 2, 10, 'FV-0003', '2026-11-07 10:15:00', 6100000.00, 1159000.00, 7259000.00, 'PAGADA', 'FE-DIAN-98403', 'Actualización de monitores de diagnóstico QHD y fuentes certificadas.'),"
                    + "(4, 5, 12, 'FV-0004', '2026-11-10 12:30:00', 3970000.00, 754300.00, 4724300.00, 'EMITIDA', 'FE-DIAN-98404', 'Venta de tarjeta gráfica RTX 4070 Super y periféricos profesionales.')");

            jdbcTemplate.update("INSERT INTO detalle_factura (id, factura_id, producto_id, cantidad, precio_unitario, impuesto, total_linea) VALUES "
                    + "(1, 1, 1, 2.00, 1950000.00, 741000.00, 4641000.00),"
                    + "(2, 1, 2, 2.00, 3290000.00, 1250200.00, 7830200.00),"
                    + "(3, 1, 4, 1.00, 580000.00, 110200.00, 690200.00),"
                    + "(4, 2, 6, 1.00, 7890000.00, 1499100.00, 9389100.00),"
                    + "(5, 2, 3, 3.00, 850000.00, 484500.00, 3034500.00),"
                    + "(6, 2, 4, 2.00, 815000.00, 309700.00, 1939700.00),"
                    + "(7, 3, 5, 3.00, 1380000.00, 786600.00, 4926600.00),"
                    + "(8, 3, 7, 2.00, 650000.00, 247000.00, 1547000.00),"
                    + "(9, 3, 8, 1.00, 660000.00, 125400.00, 785400.00),"
                    + "(10, 4, 2, 1.00, 3290000.00, 625100.00, 3915100.00),"
                    + "(11, 4, 8, 1.00, 680000.00, 129200.00, 809200.00)");

            jdbcTemplate.update("INSERT INTO pagos (id, factura_id, metodo_pago, monto, referencia_transaccion, estado, fecha_pago) VALUES "
                    + "(1, 1, 'TRANSFERENCIA', 13161400.00, 'BANCOL-TRX-8849201', 'APROBADO', '2026-10-22 14:10:00'),"
                    + "(2, 2, 'TRANSFERENCIA', 14363300.00, 'DAVIV-ACH-4410928', 'APROBADO', '2026-11-03 09:25:00'),"
                    + "(3, 3, 'TARJETA', 7259000.00, 'POS-VISA-7731904', 'APROBADO', '2026-11-07 10:25:00'),"
                    + "(4, 4, 'EPAYCO', 2000000.00, 'EPAYCO-9920145', 'APROBADO', '2026-11-10 13:00:00')");

            // 11. Movimientos de Inventario
            jdbcTemplate.update("INSERT INTO movimientos_inventario (id, producto_id, usuario_id, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, observacion, fecha) VALUES "
                    + "(1, 1, 10, 'ENTRADA', 8.00, 8.00, 16.00, 'COMPRA', 1, 'Ingreso a bodega por orden de compra CMP-001', '2026-10-18 10:35:00'),"
                    + "(2, 3, 10, 'ENTRADA', 9.00, 16.00, 25.00, 'COMPRA', 1, 'Ingreso a bodega por orden de compra CMP-001', '2026-10-18 10:36:00'),"
                    + "(3, 1, 10, 'SALIDA', 2.00, 16.00, 14.00, 'FACTURA', 1, 'Despacho por factura de venta FV-0001', '2026-10-22 11:25:00'),"
                    + "(4, 2, 10, 'ENTRADA', 5.00, 1.00, 6.00, 'COMPRA', 2, 'Ingreso a bodega por orden de compra CMP-002', '2026-10-28 14:20:00'),"
                    + "(5, 6, 10, 'ENTRADA', 2.00, 1.00, 3.00, 'COMPRA', 2, 'Ingreso a bodega por orden de compra CMP-002', '2026-10-28 14:21:00'),"
                    + "(6, 6, 12, 'SALIDA', 1.00, 3.00, 2.00, 'FACTURA', 2, 'Despacho por factura de venta FV-0002', '2026-11-02 15:45:00'),"
                    + "(7, 3, 12, 'SALIDA', 3.00, 25.00, 22.00, 'FACTURA', 2, 'Despacho por factura de venta FV-0002', '2026-11-02 15:46:00'),"
                    + "(8, 5, 10, 'SALIDA', 3.00, 12.00, 9.00, 'FACTURA', 3, 'Despacho por factura de venta FV-0003', '2026-11-07 10:20:00'),"
                    + "(9, 2, 12, 'SALIDA', 1.00, 4.00, 3.00, 'FACTURA', 4, 'Despacho por factura de venta FV-0004 (genera alerta de stock)', '2026-11-10 12:35:00')");

            // 12. Plan de Cuentas y Operaciones Contables
            jdbcTemplate.update("INSERT INTO cuentas_contables (id, cuenta_padre_id, codigo, nombre, tipo, naturaleza, estado) VALUES "
                    + "(1, NULL, '110505', 'Caja General Principal', 'ACTIVO', 'DEBITO', 'ACTIVA'),"
                    + "(2, NULL, '111005', 'Bancos Nacionales - Cuenta Empresarial Bancolombia', 'ACTIVO', 'DEBITO', 'ACTIVA'),"
                    + "(3, NULL, '130505', 'Clientes Nacionales Corporativos', 'ACTIVO', 'DEBITO', 'ACTIVA'),"
                    + "(4, NULL, '143501', 'Inventario de Mercancías - Hardware y Equipos', 'ACTIVO', 'DEBITO', 'ACTIVA'),"
                    + "(5, NULL, '220505', 'Proveedores Nacionales de Tecnología', 'PASIVO', 'CREDITO', 'ACTIVA'),"
                    + "(6, NULL, '240801', 'Impuesto sobre las Ventas (IVA Generado 19%)', 'PASIVO', 'CREDITO', 'ACTIVA'),"
                    + "(7, NULL, '240802', 'IVA Descontable en Compras 19%', 'ACTIVO', 'DEBITO', 'ACTIVA'),"
                    + "(8, NULL, '311505', 'Aportes Sociales - Capital PCStyle S.A.S.', 'PATRIMONIO', 'CREDITO', 'ACTIVA'),"
                    + "(9, NULL, '413536', 'Venta de Equipos de Informática y Periféricos', 'INGRESO', 'CREDITO', 'ACTIVA'),"
                    + "(10, NULL, '613536', 'Costo de Ventas - Equipos y Componentes', 'COSTO', 'DEBITO', 'ACTIVA')");

            jdbcTemplate.update("INSERT INTO operaciones_contables (id, usuario_id, fecha, concepto, tipo_operacion, referencia_id, estado) VALUES "
                    + "(1, 13, '2026-10-18 11:00:00', 'Causación de orden de compra mayorista CMP-001 (Mayortec S.A.S.)', 'COMPRA', 1, 'REGISTRADA'),"
                    + "(2, 13, '2026-10-22 14:30:00', 'Reconocimiento de ingreso y recaudo bancario Factura FV-0001', 'VENTA', 1, 'REGISTRADA'),"
                    + "(3, 13, '2026-11-02 16:15:00', 'Reconocimiento de venta corporativa Factura FV-0002 (Universidad Tecnológica)', 'VENTA', 2, 'REGISTRADA'),"
                    + "(4, 10, '2026-11-07 11:00:00', 'Contabilización de venta y pago con tarjeta Factura FV-0003 (Clínica San Rafael)', 'VENTA', 3, 'REGISTRADA')");

            jdbcTemplate.update("INSERT INTO detalle_operacion_contable (id, operacion_id, cuenta_id, descripcion, debito, credito) VALUES "
                    + "(1, 1, 4, 'Ingreso de procesadores y SSD a inventario (CMP-001)', 18400000.00, 0.00),"
                    + "(2, 1, 7, 'IVA descontable 19% en compra CMP-001', 3496000.00, 0.00),"
                    + "(3, 1, 5, 'Cuenta por pagar a proveedor Mayortec S.A.S.', 0.00, 21896000.00),"
                    + "(4, 2, 2, 'Ingreso en cuenta empresarial Bancolombia (FV-0001)', 13161400.00, 0.00),"
                    + "(5, 2, 9, 'Ingresos operacionales por venta de hardware (FV-0001)', 0.00, 11060000.00),"
                    + "(6, 2, 6, 'IVA generado 19% en factura FV-0001', 0.00, 2101400.00),"
                    + "(7, 3, 2, 'Transferencia bancaria recibida de Universidad Tecnológica (FV-0002)', 14363300.00, 0.00),"
                    + "(8, 3, 9, 'Ingresos por venta de portátil ROG Strix y SSDs (FV-0002)', 0.00, 12070000.00),"
                    + "(9, 3, 6, 'IVA generado 19% en factura FV-0002', 0.00, 2293300.00),"
                    + "(10, 4, 2, 'Recaudo POS Tarjeta Empresarial Clínica San Rafael (FV-0003)', 7259000.00, 0.00),"
                    + "(11, 4, 9, 'Venta de monitores LG UltraGear y fuentes Corsair (FV-0003)', 0.00, 6100000.00),"
                    + "(12, 4, 6, 'IVA generado 19% en factura FV-0003', 0.00, 1159000.00)");

            // 13. Auditoría
            jdbcTemplate.update("INSERT INTO auditoria (id, usuario_id, modulo, accion, registro_id, descripcion, datos_anteriores, datos_nuevos, ip, fecha_exacta) VALUES "
                    + "(1, 10, 'Autenticación', 'LOGIN', 10, 'Inicio de sesión exitoso de Sebastián Beltrán (Director General)', NULL, '{\"email\":\"sbeltran18.name@gmail.com\",\"rol\":\"Administrador General\"}', '127.0.0.1', '2026-11-10 08:00:12'),"
                    + "(2, 10, 'Productos', 'CREAR', 1, 'Registro del catálogo oficial de hardware PCStyle (8 productos activos)', NULL, '{\"catalogo\":\"PCStyle Hardware\",\"productos\":8}', '127.0.0.1', '2026-11-10 08:15:30'),"
                    + "(3, 10, 'Compras', 'CREAR', 2, 'Confirmación de orden de compra CMP-002 a Ingram Micro Colombia S.A.S.', NULL, '{\"numeroCompra\":\"CMP-002\",\"total\":30999500.00}', '127.0.0.1', '2026-11-10 09:20:45'),"
                    + "(4, 12, 'Facturas de venta', 'CREAR', 4, 'Emisión de factura electrónica FV-0004 (FE-DIAN-98404) por $4,724,300 COP', NULL, '{\"numeroFactura\":\"FV-0004\",\"total\":4724300.00}', '127.0.0.1', '2026-11-10 12:30:10'),"
                    + "(5, 13, 'Operaciones contables', 'CREAR', 4, 'Registro de asiento contable de partida doble para factura FV-0003', NULL, '{\"operacionId\":4,\"debito\":7259000.00,\"credito\":7259000.00}', '127.0.0.1', '2026-11-10 14:10:00')");

            // Ajustar contadores AUTO_INCREMENT en H2 para que nuevos registros que cree la profesora no choquen con los IDs existentes
            String[] tablasConSecuencia = {
                "roles", "permisos", "rol_permiso", "usuarios", "categorias_producto", "productos",
                "inventario", "alertas_inventario", "proveedores", "clientes", "compras", "detalle_compra",
                "facturas_venta", "detalle_factura", "pagos", "movimientos_inventario",
                "cuentas_contables", "operaciones_contables", "detalle_operacion_contable", "auditoria"
            };
            for (String tabla : tablasConSecuencia) {
                try {
                    jdbcTemplate.execute("ALTER TABLE " + tabla + " ALTER COLUMN id RESTART WITH 100");
                } catch (Exception ignored) {
                }
            }

            log.info("Base de datos Cloud Getherware · PCStyle cargada exitosamente con todos los datos empresariales.");
        } catch (Exception e) {
            log.warn("Aviso al inicializar datos cloud: {}", e.getMessage());
        }
    }
}
