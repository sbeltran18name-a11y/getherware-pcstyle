package com.example.gestion.config;

import com.example.gestion.interfaces.Iauditoria;
import com.example.gestion.interfaces.Ipermisos;
import com.example.gestion.interfaces.Irol;
import com.example.gestion.interfaces.IrolPermiso;
import com.example.gestion.interfaces.Iusuario;
import com.example.gestion.modelo.AccionAuditoria;
import com.example.gestion.modelo.Auditoria;
import com.example.gestion.modelo.EstadoUsuario;
import com.example.gestion.modelo.Permisos;
import com.example.gestion.modelo.Rol;
import com.example.gestion.modelo.RolPermiso;
import com.example.gestion.modelo.Usuario;
import com.example.gestion.servicios.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();

    @Autowired
    private Iusuario usuarioRepo;

    @Autowired
    private Irol rolRepo;

    @Autowired
    private IrolPermiso rolPermisoRepo;

    @Autowired
    private Ipermisos permisosRepo;

    @Autowired
    private Iauditoria auditoriaRepo;

    /**
     * PasswordEncoder compatible con BCrypt y con contraseñas antiguas en texto plano
     * que ya estaban guardadas en la base de datos.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new PasswordEncoder() {
            @Override
            public String encode(CharSequence rawPassword) {
                return bcrypt.encode(rawPassword);
            }

            @Override
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
                if (rawPassword == null || encodedPassword == null) {
                    return false;
                }
                if (UsuarioService.esHashBcrypt(encodedPassword)) {
                    return bcrypt.matches(rawPassword, encodedPassword);
                }
                return encodedPassword.equals(rawPassword.toString());
            }
        };
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> {
            Usuario usuario = usuarioRepo.findByEmailIgnoreCase(username.trim())
                    .orElseThrow(() -> new UsernameNotFoundException("No existe un usuario con ese correo."));

            List<GrantedAuthority> autoridades = new ArrayList<>();

            Optional<Rol> rolOpt = rolRepo.findById(usuario.getRolId());
            String nombreRol = rolOpt.map(Rol::getNombre).orElse("USUARIO");
            autoridades.add(new SimpleGrantedAuthority("ROLE_" + nombreRol.trim().toUpperCase().replace(' ', '_')));

            List<RolPermiso> relaciones = rolPermisoRepo.findByRolId(usuario.getRolId());
            for (RolPermiso rp : relaciones) {
                Optional<Permisos> permOpt = permisosRepo.findById(rp.getPermisoId());
                permOpt.ifPresent(p -> autoridades.add(
                        new SimpleGrantedAuthority("PERM_" + p.getNombre().trim().toUpperCase().replace(' ', '_'))
                ));
            }

            boolean activo = usuario.getEstado() == EstadoUsuario.ACTIVO;
            boolean noBloqueado = usuario.getEstado() != EstadoUsuario.BLOQUEADO;

            return User.builder()
                    .username(usuario.getEmail())
                    .password(usuario.getPasswordHash())
                    .disabled(!activo)
                    .accountLocked(!noBloqueado)
                    .authorities(autoridades)
                    .build();
        };
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                        "/login",
                        "/registro",
                        "/verificar-codigo",
                        "/reenviar-codigo",
                        "/css/**",
                        "/js/**",
                        "/images/**"
                ).permitAll()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .usernameParameter("email")
                .passwordParameter("password")
                .successHandler((request, response, authentication) -> {
                    String email = authentication.getName();
                    usuarioRepo.findByEmailIgnoreCase(email).ifPresent(u -> {
                        u.setUltimoAcceso(LocalDateTime.now());
                        String rawPass = request.getParameter("password");
                        if (rawPass != null && !UsuarioService.esHashBcrypt(u.getPasswordHash())) {
                            u.setPasswordHash(bcrypt.encode(rawPass));
                        }
                        usuarioRepo.save(u);
                        registrarAuditoria(u.getId(), AccionAuditoria.LOGIN,
                                "Inicio de sesión exitoso de " + u.getEmail(), request.getRemoteAddr());
                    });
                    response.sendRedirect(request.getContextPath() + "/Dashboard");
                })
                .failureHandler((request, response, exception) -> {
                    String email = request.getParameter("email");
                    if (exception instanceof DisabledException && email != null && !email.isBlank()) {
                        String mailParam = URLEncoder.encode(email.trim(), StandardCharsets.UTF_8);
                        response.sendRedirect(request.getContextPath() + "/verificar-codigo?email=" + mailParam + "&pendiente=true");
                        return;
                    }
                    if (exception instanceof LockedException) {
                        response.sendRedirect(request.getContextPath() + "/login?bloqueado=true");
                        return;
                    }
                    response.sendRedirect(request.getContextPath() + "/login?error=true");
                })
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .addLogoutHandler((request, response, authentication) -> {
                    if (authentication != null) {
                        usuarioRepo.findByEmailIgnoreCase(authentication.getName()).ifPresent(u ->
                                registrarAuditoria(u.getId(), AccionAuditoria.LOGOUT,
                                        "Cierre de sesión de " + u.getEmail(), request.getRemoteAddr())
                        );
                    }
                })
                .logoutSuccessUrl("/login?logout=true")
                .permitAll()
            );

        return http.build();
    }

    private void registrarAuditoria(int usuarioId, AccionAuditoria accion, String descripcion, String ip) {
        try {
            Auditoria a = new Auditoria();
            a.setUsuarioId((long) usuarioId);
            a.setModulo("Autenticación");
            a.setAccion(accion);
            a.setRegistroId((long) usuarioId);
            a.setDescripcion(descripcion);
            a.setIp(ip);
            a.setFechaExacta(LocalDateTime.now());
            auditoriaRepo.save(a);
        } catch (Exception ignored) {
        }
    }
}
