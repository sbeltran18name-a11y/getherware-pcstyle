package com.example.gestion.config;

import com.example.gestion.interfaces.Iauditoria;
import com.example.gestion.interfaces.Iusuario;
import com.example.gestion.modelo.AccionAuditoria;
import com.example.gestion.modelo.Auditoria;
import com.example.gestion.modelo.Usuario;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.support.RequestContextUtils;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.StringJoiner;

/**
 * Interceptor que registra automáticamente en la tabla de auditoría cualquier
 * creación (/save...), actualización (/save... con id > 0) o eliminación (/delete.../{id})
 * realizada en cualquiera de los módulos del sistema.
 */
@Component
public class AuditoriaInterceptor implements HandlerInterceptor {

    private static final String ATTR_ACCION = "auditoria_accion";
    private static final String ATTR_MODULO = "auditoria_modulo";
    private static final String ATTR_REGISTRO_ID = "auditoria_registro_id";
    private static final String ATTR_RESUMEN = "auditoria_resumen";

    private static final Map<String, String> NOMBRES_MODULO = Map.ofEntries(
            Map.entry("Producto", "Productos"),
            Map.entry("Categoria", "Categorías"),
            Map.entry("Inventario", "Inventario"),
            Map.entry("AlertaInventario", "Alertas de inventario"),
            Map.entry("Proveedor", "Proveedores"),
            Map.entry("Compra", "Compras"),
            Map.entry("DetalleCompra", "Detalle de compras"),
            Map.entry("Cliente", "Clientes"),
            Map.entry("FacturaVenta", "Facturas de venta"),
            Map.entry("DetalleFactura", "Detalle de facturas"),
            Map.entry("Pago", "Pagos"),
            Map.entry("CuentaContable", "Plan de cuentas"),
            Map.entry("OperacionContable", "Operaciones contables"),
            Map.entry("DetalleOperacionContable", "Detalle contable"),
            Map.entry("Usuario", "Usuarios"),
            Map.entry("Rol", "Roles"),
            Map.entry("Permiso", "Permisos"),
            Map.entry("RolPermiso", "Roles y permisos")
    );

    @Autowired
    private Iauditoria auditoriaRepo;

    @Autowired
    private Iusuario usuarioRepo;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {

        if (!"POST".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String uri = request.getRequestURI().substring(request.getContextPath().length());

        if (uri.startsWith("/save") && uri.length() > 5) {
            String claveModulo = uri.substring(5);
            int barra = claveModulo.indexOf('/');
            if (barra >= 0) {
                claveModulo = claveModulo.substring(0, barra);
            }

            String idParam = request.getParameter("id");
            long idNum = parsearId(idParam);

            AccionAuditoria accion = (idNum > 0) ? AccionAuditoria.ACTUALIZAR : AccionAuditoria.CREAR;
            String nombreModulo = NOMBRES_MODULO.getOrDefault(claveModulo, claveModulo);

            request.setAttribute(ATTR_ACCION, accion);
            request.setAttribute(ATTR_MODULO, nombreModulo);
            if (idNum > 0) {
                request.setAttribute(ATTR_REGISTRO_ID, idNum);
            }
            request.setAttribute(ATTR_RESUMEN, construirResumenParametros(request));

        } else if (uri.startsWith("/delete") && uri.length() > 7) {
            String resto = uri.substring(7);
            int barra = resto.indexOf('/');
            String claveModulo = barra >= 0 ? resto.substring(0, barra) : resto;
            String idTexto = barra >= 0 ? resto.substring(barra + 1) : "";
            long idNum = parsearId(idTexto);

            String nombreModulo = NOMBRES_MODULO.getOrDefault(claveModulo, claveModulo);

            request.setAttribute(ATTR_ACCION, AccionAuditoria.ELIMINAR);
            request.setAttribute(ATTR_MODULO, nombreModulo);
            if (idNum > 0) {
                request.setAttribute(ATTR_REGISTRO_ID, idNum);
            }
        }

        return true;
    }

    @Override
    public void afterCompletion(
            HttpServletRequest request,
            HttpServletResponse response,
            Object handler,
            Exception ex) {

        if (ex != null) {
            return;
        }

        AccionAuditoria accion = (AccionAuditoria) request.getAttribute(ATTR_ACCION);
        String modulo = (String) request.getAttribute(ATTR_MODULO);
        if (accion == null || modulo == null) {
            return;
        }

        // Si el manejador de excepciones puso un mensaje de error en el FlashMap, no registramos éxito
        Map<String, ?> flashMap = RequestContextUtils.getOutputFlashMap(request);
        if (flashMap != null && flashMap.containsKey("mensajeError")) {
            return;
        }

        try {
            Long usuarioId = obtenerUsuarioActualId();
            if (usuarioId == null || usuarioId <= 0) {
                return;
            }

            Long registroId = (Long) request.getAttribute(ATTR_REGISTRO_ID);
            String resumen = (String) request.getAttribute(ATTR_RESUMEN);

            String descripcion;
            if (accion == AccionAuditoria.CREAR) {
                descripcion = "Se creó un nuevo registro en " + modulo
                        + (resumen != null && !resumen.isEmpty() ? " (" + resumen + ")" : "");
            } else if (accion == AccionAuditoria.ACTUALIZAR) {
                descripcion = "Se actualizó el registro"
                        + (registroId != null ? " #" + registroId : "")
                        + " en " + modulo
                        + (resumen != null && !resumen.isEmpty() ? " (" + resumen + ")" : "");
            } else {
                descripcion = "Se eliminó el registro"
                        + (registroId != null ? " #" + registroId : "")
                        + " en " + modulo;
            }

            if (descripcion.length() > 490) {
                descripcion = descripcion.substring(0, 490);
            }

            Auditoria a = new Auditoria();
            a.setUsuarioId(usuarioId);
            a.setModulo(modulo);
            a.setAccion(accion);
            a.setRegistroId(registroId);
            a.setDescripcion(descripcion);
            a.setIp(request.getRemoteAddr());
            a.setFechaExacta(LocalDateTime.now());

            auditoriaRepo.save(a);
        } catch (Exception ignored) {
        }
    }

    private String construirResumenParametros(HttpServletRequest request) {
        String[] camposClave = {
                "nombre", "nombres", "nombreRazonSocial", "razonSocial",
                "codigo", "numeroDocumento", "nit", "numeroFactura", "numeroCompra",
                "email", "concepto", "monto", "total", "stockActual"
        };

        StringJoiner joiner = new StringJoiner(", ");
        for (String campo : camposClave) {
            String val = request.getParameter(campo);
            if (val != null && !val.isBlank()) {
                joiner.add(campo + ": " + val.trim());
            }
        }
        return joiner.toString();
    }

    private long parsearId(String texto) {
        if (texto == null || texto.isBlank()) {
            return 0L;
        }
        try {
            return Long.parseLong(texto.trim());
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    private Long obtenerUsuarioActualId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken)) {
            Optional<Usuario> uOpt = usuarioRepo.findByEmailIgnoreCase(auth.getName());
            if (uOpt.isPresent()) {
                return (long) uOpt.get().getId();
            }
        }
        for (Usuario u : usuarioRepo.findAll()) {
            return (long) u.getId();
        }
        return null;
    }
}
